#!/usr/bin/env python
#
# Copyright 2007 Google Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#



from google.net.proto import ProtocolBuffer
import array
import base64
import dummy_thread as thread
try:
  from google3.net.proto import _net_proto___parse__python
except ImportError:
  _net_proto___parse__python = None

__pychecker__ = """maxreturns=0 maxbranches=0 no-callinit
                   unusednames=printElemNumber,debug_strs no-special"""

class RetryParameters(ProtocolBuffer.ProtocolMessage):
  has_retry_limit_ = 0
  retry_limit_ = 0
  has_age_limit_sec_ = 0
  age_limit_sec_ = 0
  has_min_backoff_sec_ = 0
  min_backoff_sec_ = 0.1
  has_max_backoff_sec_ = 0
  max_backoff_sec_ = 3600.0
  has_max_doublings_ = 0
  max_doublings_ = 16

  def __init__(self, contents=None):
    if contents is not None: self.MergeFromString(contents)

  def retry_limit(self): return self.retry_limit_

  def set_retry_limit(self, x):
    self.has_retry_limit_ = 1
    self.retry_limit_ = x

  def clear_retry_limit(self):
    if self.has_retry_limit_:
      self.has_retry_limit_ = 0
      self.retry_limit_ = 0

  def has_retry_limit(self): return self.has_retry_limit_

  def age_limit_sec(self): return self.age_limit_sec_

  def set_age_limit_sec(self, x):
    self.has_age_limit_sec_ = 1
    self.age_limit_sec_ = x

  def clear_age_limit_sec(self):
    if self.has_age_limit_sec_:
      self.has_age_limit_sec_ = 0
      self.age_limit_sec_ = 0

  def has_age_limit_sec(self): return self.has_age_limit_sec_

  def min_backoff_sec(self): return self.min_backoff_sec_

  def set_min_backoff_sec(self, x):
    self.has_min_backoff_sec_ = 1
    self.min_backoff_sec_ = x

  def clear_min_backoff_sec(self):
    if self.has_min_backoff_sec_:
      self.has_min_backoff_sec_ = 0
      self.min_backoff_sec_ = 0.1

  def has_min_backoff_sec(self): return self.has_min_backoff_sec_

  def max_backoff_sec(self): return self.max_backoff_sec_

  def set_max_backoff_sec(self, x):
    self.has_max_backoff_sec_ = 1
    self.max_backoff_sec_ = x

  def clear_max_backoff_sec(self):
    if self.has_max_backoff_sec_:
      self.has_max_backoff_sec_ = 0
      self.max_backoff_sec_ = 3600.0

  def has_max_backoff_sec(self): return self.has_max_backoff_sec_

  def max_doublings(self): return self.max_doublings_

  def set_max_doublings(self, x):
    self.has_max_doublings_ = 1
    self.max_doublings_ = x

  def clear_max_doublings(self):
    if self.has_max_doublings_:
      self.has_max_doublings_ = 0
      self.max_doublings_ = 16

  def has_max_doublings(self): return self.has_max_doublings_


  def MergeFrom(self, x):
    assert x is not self
    if (x.has_retry_limit()): self.set_retry_limit(x.retry_limit())
    if (x.has_age_limit_sec()): self.set_age_limit_sec(x.age_limit_sec())
    if (x.has_min_backoff_sec()): self.set_min_backoff_sec(x.min_backoff_sec())
    if (x.has_max_backoff_sec()): self.set_max_backoff_sec(x.max_backoff_sec())
    if (x.has_max_doublings()): self.set_max_doublings(x.max_doublings())

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.RetryParameters', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.RetryParameters')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.RetryParameters')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.RetryParameters', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.RetryParameters', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.RetryParameters', s)


  def Equals(self, x):
    if x is self: return 1
    if self.has_retry_limit_ != x.has_retry_limit_: return 0
    if self.has_retry_limit_ and self.retry_limit_ != x.retry_limit_: return 0
    if self.has_age_limit_sec_ != x.has_age_limit_sec_: return 0
    if self.has_age_limit_sec_ and self.age_limit_sec_ != x.age_limit_sec_: return 0
    if self.has_min_backoff_sec_ != x.has_min_backoff_sec_: return 0
    if self.has_min_backoff_sec_ and self.min_backoff_sec_ != x.min_backoff_sec_: return 0
    if self.has_max_backoff_sec_ != x.has_max_backoff_sec_: return 0
    if self.has_max_backoff_sec_ and self.max_backoff_sec_ != x.max_backoff_sec_: return 0
    if self.has_max_doublings_ != x.has_max_doublings_: return 0
    if self.has_max_doublings_ and self.max_doublings_ != x.max_doublings_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    if (not self.has_min_backoff_sec_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: min_backoff_sec not set.')
    if (not self.has_max_backoff_sec_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: max_backoff_sec not set.')
    return initialized

  def ByteSize(self):
    n = 0
    if (self.has_retry_limit_): n += 1 + self.lengthVarInt64(self.retry_limit_)
    if (self.has_age_limit_sec_): n += 1 + self.lengthVarInt64(self.age_limit_sec_)
    if (self.has_max_doublings_): n += 1 + self.lengthVarInt64(self.max_doublings_)
    return n + 18

  def ByteSizePartial(self):
    n = 0
    if (self.has_retry_limit_): n += 1 + self.lengthVarInt64(self.retry_limit_)
    if (self.has_age_limit_sec_): n += 1 + self.lengthVarInt64(self.age_limit_sec_)
    if (self.has_min_backoff_sec_):
      n += 9
    if (self.has_max_backoff_sec_):
      n += 9
    if (self.has_max_doublings_): n += 1 + self.lengthVarInt64(self.max_doublings_)
    return n

  def Clear(self):
    self.clear_retry_limit()
    self.clear_age_limit_sec()
    self.clear_min_backoff_sec()
    self.clear_max_backoff_sec()
    self.clear_max_doublings()

  def OutputUnchecked(self, out):
    if (self.has_retry_limit_):
      out.putVarInt32(8)
      out.putVarInt32(self.retry_limit_)
    if (self.has_age_limit_sec_):
      out.putVarInt32(16)
      out.putVarInt64(self.age_limit_sec_)
    out.putVarInt32(25)
    out.putDouble(self.min_backoff_sec_)
    out.putVarInt32(33)
    out.putDouble(self.max_backoff_sec_)
    if (self.has_max_doublings_):
      out.putVarInt32(40)
      out.putVarInt32(self.max_doublings_)

  def OutputPartial(self, out):
    if (self.has_retry_limit_):
      out.putVarInt32(8)
      out.putVarInt32(self.retry_limit_)
    if (self.has_age_limit_sec_):
      out.putVarInt32(16)
      out.putVarInt64(self.age_limit_sec_)
    if (self.has_min_backoff_sec_):
      out.putVarInt32(25)
      out.putDouble(self.min_backoff_sec_)
    if (self.has_max_backoff_sec_):
      out.putVarInt32(33)
      out.putDouble(self.max_backoff_sec_)
    if (self.has_max_doublings_):
      out.putVarInt32(40)
      out.putVarInt32(self.max_doublings_)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 8:
        self.set_retry_limit(d.getVarInt32())
        continue
      if tt == 16:
        self.set_age_limit_sec(d.getVarInt64())
        continue
      if tt == 25:
        self.set_min_backoff_sec(d.getDouble())
        continue
      if tt == 33:
        self.set_max_backoff_sec(d.getDouble())
        continue
      if tt == 40:
        self.set_max_doublings(d.getVarInt32())
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    if self.has_retry_limit_: res+=prefix+("retry_limit: %s\n" % self.DebugFormatInt32(self.retry_limit_))
    if self.has_age_limit_sec_: res+=prefix+("age_limit_sec: %s\n" % self.DebugFormatInt64(self.age_limit_sec_))
    if self.has_min_backoff_sec_: res+=prefix+("min_backoff_sec: %s\n" % self.DebugFormat(self.min_backoff_sec_))
    if self.has_max_backoff_sec_: res+=prefix+("max_backoff_sec: %s\n" % self.DebugFormat(self.max_backoff_sec_))
    if self.has_max_doublings_: res+=prefix+("max_doublings: %s\n" % self.DebugFormatInt32(self.max_doublings_))
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  kretry_limit = 1
  kage_limit_sec = 2
  kmin_backoff_sec = 3
  kmax_backoff_sec = 4
  kmax_doublings = 5

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "retry_limit",
    2: "age_limit_sec",
    3: "min_backoff_sec",
    4: "max_backoff_sec",
    5: "max_doublings",
  }, 5)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.NUMERIC,
    2: ProtocolBuffer.Encoder.NUMERIC,
    3: ProtocolBuffer.Encoder.DOUBLE,
    4: ProtocolBuffer.Encoder.DOUBLE,
    5: ProtocolBuffer.Encoder.NUMERIC,
  }, 5, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("Wh9hcHBob3N0aW5nL2V4ZWN1dG9yL3JldHJ5LnByb3RvChphcHBob3N0aW5nLlJldHJ5UGFyYW1ldGVycxMaC3JldHJ5X2xpbWl0IAEoADAFOAEUExoNYWdlX2xpbWl0X3NlYyACKAAwAzgBFBMaD21pbl9iYWNrb2ZmX3NlYyADKAEwATgCQgMwLjGjAaoBB2RlZmF1bHSyAQMwLjGkARQTGg9tYXhfYmFja29mZl9zZWMgBCgBMAE4AkIGMzYwMC4wowGqAQdkZWZhdWx0sgEGMzYwMC4wpAEUExoNbWF4X2RvdWJsaW5ncyAFKAAwBTgBQgIxNqMBqgEHZGVmYXVsdLIBAjE2pAEUugHtAQofYXBwaG9zdGluZy9leGVjdXRvci9yZXRyeS5wcm90bxIKYXBwaG9zdGluZyKVAQoPUmV0cnlQYXJhbWV0ZXJzEhMKC3JldHJ5X2xpbWl0GAEgASgFEhUKDWFnZV9saW1pdF9zZWMYAiABKAMSHAoPbWluX2JhY2tvZmZfc2VjGAMgAigBOgMwLjESHQoPbWF4X2JhY2tvZmZfc2VjGAQgAigBOgQzNjAwEhkKDW1heF9kb3VibGluZ3MYBSABKAU6AjE2QiYKHmNvbS5nb29nbGUuYXBwaG9zdGluZy5leGVjdXRvchABIAEoAQ=="))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())


__all__ = ['RetryParameters']
