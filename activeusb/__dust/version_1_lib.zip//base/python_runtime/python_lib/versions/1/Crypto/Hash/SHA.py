
# Just use the SHA module from the Python standard library

__revision__ = "$Id: SHA.py,v 1.4 2002/07/11 14:31:19 akuchling Exp $"

import hashlib

digest_size = 20
blocksize = 1
new = hashlib.sha1
