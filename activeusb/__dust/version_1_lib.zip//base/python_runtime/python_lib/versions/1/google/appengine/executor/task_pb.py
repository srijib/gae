#!/usr/bin/env python
#
# Copyright 2007 Google Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#



from google.net.proto import ProtocolBuffer
import array
import base64
import dummy_thread as thread
try:
  from google3.net.proto import _net_proto___parse__python
except ImportError:
  _net_proto___parse__python = None

__pychecker__ = """maxreturns=0 maxbranches=0 no-callinit
                   unusednames=printElemNumber,debug_strs no-special"""

from google.appengine.executor.queue_pb import *
import google.appengine.executor.queue_pb
from google.appengine.executor.retry_pb import *
import google.appengine.executor.retry_pb
from google.net.proto.message_set import MessageSet
class TaskRef(ProtocolBuffer.ProtocolMessage):
  has_queue_ref_ = 0
  has_name_ = 0
  name_ = ""

  def __init__(self, contents=None):
    self.queue_ref_ = google.appengine.executor.queue_pb.QueueRef()
    if contents is not None: self.MergeFromString(contents)

  def queue_ref(self): return self.queue_ref_

  def mutable_queue_ref(self): self.has_queue_ref_ = 1; return self.queue_ref_

  def clear_queue_ref(self):self.has_queue_ref_ = 0; self.queue_ref_.Clear()

  def has_queue_ref(self): return self.has_queue_ref_

  def name(self): return self.name_

  def set_name(self, x):
    self.has_name_ = 1
    self.name_ = x

  def clear_name(self):
    if self.has_name_:
      self.has_name_ = 0
      self.name_ = ""

  def has_name(self): return self.has_name_


  def MergeFrom(self, x):
    assert x is not self
    if (x.has_queue_ref()): self.mutable_queue_ref().MergeFrom(x.queue_ref())
    if (x.has_name()): self.set_name(x.name())

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.TaskRef', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.TaskRef')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.TaskRef')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.TaskRef', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.TaskRef', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.TaskRef', s)


  def Equals(self, x):
    if x is self: return 1
    if self.has_queue_ref_ != x.has_queue_ref_: return 0
    if self.has_queue_ref_ and self.queue_ref_ != x.queue_ref_: return 0
    if self.has_name_ != x.has_name_: return 0
    if self.has_name_ and self.name_ != x.name_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    if (not self.has_queue_ref_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: queue_ref not set.')
    elif not self.queue_ref_.IsInitialized(debug_strs): initialized = 0
    if (not self.has_name_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: name not set.')
    return initialized

  def ByteSize(self):
    n = 0
    n += self.lengthString(self.queue_ref_.ByteSize())
    n += self.lengthString(len(self.name_))
    return n + 2

  def ByteSizePartial(self):
    n = 0
    if (self.has_queue_ref_):
      n += 1
      n += self.lengthString(self.queue_ref_.ByteSizePartial())
    if (self.has_name_):
      n += 1
      n += self.lengthString(len(self.name_))
    return n

  def Clear(self):
    self.clear_queue_ref()
    self.clear_name()

  def OutputUnchecked(self, out):
    out.putVarInt32(10)
    out.putVarInt32(self.queue_ref_.ByteSize())
    self.queue_ref_.OutputUnchecked(out)
    out.putVarInt32(18)
    out.putPrefixedString(self.name_)

  def OutputPartial(self, out):
    if (self.has_queue_ref_):
      out.putVarInt32(10)
      out.putVarInt32(self.queue_ref_.ByteSizePartial())
      self.queue_ref_.OutputPartial(out)
    if (self.has_name_):
      out.putVarInt32(18)
      out.putPrefixedString(self.name_)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 10:
        length = d.getVarInt32()
        tmp = ProtocolBuffer.Decoder(d.buffer(), d.pos(), d.pos() + length)
        d.skip(length)
        self.mutable_queue_ref().TryMerge(tmp)
        continue
      if tt == 18:
        self.set_name(d.getPrefixedString())
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    if self.has_queue_ref_:
      res+=prefix+"queue_ref <\n"
      res+=self.queue_ref_.__str__(prefix + "  ", printElemNumber)
      res+=prefix+">\n"
    if self.has_name_: res+=prefix+("name: %s\n" % self.DebugFormatString(self.name_))
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  kqueue_ref = 1
  kname = 2

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "queue_ref",
    2: "name",
  }, 2)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.STRING,
    2: ProtocolBuffer.Encoder.STRING,
  }, 2, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("Wh5hcHBob3N0aW5nL2V4ZWN1dG9yL3Rhc2sucHJvdG8KEmFwcGhvc3RpbmcuVGFza1JlZhMaCXF1ZXVlX3JlZiABKAIwCzgCShNhcHBob3N0aW5nLlF1ZXVlUmVmFBMaBG5hbWUgAigCMAk4AhS6AeQcCh5hcHBob3N0aW5nL2V4ZWN1dG9yL3Rhc2sucHJvdG8SCmFwcGhvc3RpbmcaH2FwcGhvc3RpbmcvZXhlY3V0b3IvcXVldWUucHJvdG8aH2FwcGhvc3RpbmcvZXhlY3V0b3IvcmV0cnkucHJvdG8iQAoHVGFza1JlZhInCglxdWV1ZV9yZWYYASACKAsyFC5hcHBob3N0aW5nLlF1ZXVlUmVmEgwKBG5hbWUYAiACKAwiWgoPVGFza0V0YUluZGV4UmVmEicKCXF1ZXVlX3JlZhgBIAIoCzIULmFwcGhvc3RpbmcuUXVldWVSZWYSEAoIZXRhX3VzZWMYAiACKAMSDAoEbmFtZRgDIAIoDCIZCglUYXNrUmFuZ2UqCAhkEICAgIACOgIIASIvCg1UYXNrRXRhQm9yZGVyEhAKCGV0YV91c2VjGAEgAigDEgwKBG5hbWUYAiABKAwiqgEKDlRhc2tSYW5nZUJ5RXRhEigKBXN0YXJ0GAEgASgLMhkuYXBwaG9zdGluZy5UYXNrRXRhQm9yZGVyEigKBWxpbWl0GAIgASgLMhkuYXBwaG9zdGluZy5UYXNrRXRhQm9yZGVyMkQKCXJhbmdlX2RlZhIVLmFwcGhvc3RpbmcuVGFza1JhbmdlGGQgASgLMhouYXBwaG9zdGluZy5UYXNrUmFuZ2VCeUV0YSJ2Cg9UYXNrUmFuZ2VCeU5hbWUSDQoFc3RhcnQYASABKAwSDQoFbGltaXQYAiABKAwyRQoJcmFuZ2VfZGVmEhUuYXBwaG9zdGluZy5UYXNrUmFuZ2UYZSABKAsyGy5hcHBob3N0aW5nLlRhc2tSYW5nZUJ5TmFtZSIfCg5UYXNrUnVubmVySW5mbyoJCMgBEICAgIACOgIIASJ2ChJIdHRwVGFza1J1bm5lckluZm8SFQoNcmVzcG9uc2VfY29kZRgBIAIoAzJJCgRpbmZvEhouYXBwaG9zdGluZy5UYXNrUnVubmVySW5mbxjIASABKAsyHi5hcHBob3N0aW5nLkh0dHBUYXNrUnVubmVySW5mbyJ8Cg9UYXNrUnVubmVyU3RhdHMSFwoPZGlzcGF0Y2hlZF91c2VjGAEgAigDEhAKCGxhZ191c2VjGAIgAigDEhQKDGVsYXBzZWRfdXNlYxgDIAIoAxIoCgRpbmZvGAQgASgLMhouYXBwaG9zdGluZy5UYXNrUnVubmVySW5mbyIhChFUYXNrUnVubmVyUGF5bG9hZCoICAoQgICAgAI6AggBIvgCChVIdHRwVGFza1J1bm5lclBheWxvYWQSRQoGbWV0aG9kGAEgASgOMi8uYXBwaG9zdGluZy5IdHRwVGFza1J1bm5lclBheWxvYWQuUmVxdWVzdE1ldGhvZDoEUE9TVBILCgN1cmwYAiACKAwSOAoGaGVhZGVyGAMgAygKMiguYXBwaG9zdGluZy5IdHRwVGFza1J1bm5lclBheWxvYWQuSGVhZGVyEhAKBGJvZHkYBiABKAxCAggBGiQKBkhlYWRlchILCgNrZXkYBCACKAwSDQoFdmFsdWUYBSACKAwiQQoNUmVxdWVzdE1ldGhvZBIHCgNHRVQQARIICgRQT1NUEAISCAoESEVBRBADEgcKA1BVVBAEEgoKBkRFTEVURRAFMlYKDGh0dHBfcGF5bG9hZBIdLmFwcGhvc3RpbmcuVGFza1J1bm5lclBheWxvYWQYCiABKAsyIS5hcHBob3N0aW5nLkh0dHBUYXNrUnVubmVyUGF5bG9hZCLqAQoVQ3JvblRhc2tSdW5uZXJQYXlsb2FkEhAKCHNjaGVkdWxlGAEgAigJEhAKCHRpbWV6b25lGAIgAigJEjgKEWRlbGVnYXRlZF9wYXlsb2FkGAMgAigLMh0uYXBwaG9zdGluZy5UYXNrUnVubmVyUGF5bG9hZBIbChNza2lwX251bV9pdGVyYXRpb25zGAQgASgDMlYKDGNyb25fcGF5bG9hZBIdLmFwcGhvc3RpbmcuVGFza1J1bm5lclBheWxvYWQYCyABKAsyIS5hcHBob3N0aW5nLkNyb25UYXNrUnVubmVyUGF5bG9hZCL9CgoXU3R1YmJ5VGFza1J1bm5lclBheWxvYWQSQgoHY2hhbm5lbBgBIAIoCzIxLmFwcGhvc3RpbmcuU3R1YmJ5VGFza1J1bm5lclBheWxvYWQuU3R1YmJ5Q2hhbm5lbBIOCgZtZXRob2QYAiACKAkSEwoHcmVxdWVzdBgDIAIoDEICCAESQwoLcnBjX29wdGlvbnMYBCABKAsyLi5hcHBob3N0aW5nLlN0dWJieVRhc2tSdW5uZXJQYXlsb2FkLlJwY09wdGlvbnMSJgoXcmVxdWVzdF90YXNrX2RlZmluaXRpb24YBSABKAg6BWZhbHNlGoMFCg1TdHViYnlDaGFubmVsEgwKBGhvc3QYASACKAkScgoVbG9hZF9iYWxhbmNpbmdfcG9saWN5GAIgASgOMkUuYXBwaG9zdGluZy5TdHViYnlUYXNrUnVubmVyUGF5bG9hZC5TdHViYnlDaGFubmVsLkxvYWRCYWxhbmNpbmdQb2xpY3k6DExFQVNUX0xPQURFRBIfChFzZWN1cml0eV9wcm90b2NvbBgDIAEoCToEbG9hcxIaChJtaW5fc2VjdXJpdHlfbGV2ZWwYBCABKAUScwoXdGFyZ2V0X3NlbGVjdGlvbl9wb2xpY3kYBSABKA4yRy5hcHBob3N0aW5nLlN0dWJieVRhc2tSdW5uZXJQYXlsb2FkLlN0dWJieUNoYW5uZWwuVGFyZ2V0U2VsZWN0aW9uUG9saWN5OglOT19GSUxURVISFgoLbWF4X3RhcmdldHMYBiABKAU6ATUSHAoUbWF4X291dHN0YW5kaW5nX3JwY3MYByABKAUiuQEKE0xvYWRCYWxhbmNpbmdQb2xpY3kSEAoMTEVBU1RfTE9BREVEEAESDwoLUk9VTkRfUk9CSU4QAhITCg9GSVJTVF9SRUFDSEFCTEUQAxIXChNBRkZJTklUWV9TQ0hFRFVMSU5HEAQSEQoNRVJST1JfQURWRVJTRRAFEhYKEkZJUlNUX0xFQVNUX0xPQURFRBAGEg8KC0lOVkVSU0VfUlRUEAcSFQoRTEFURU5DWV9EUklWRU5fUlIQCCJMChVUYXJnZXRTZWxlY3Rpb25Qb2xpY3kSDQoJTk9fRklMVEVSEAESEQoNUkFORE9NX1NVQlNFVBACEhEKDU5FVFdPUktfQVdBUkUQAxqpAwoKUnBjT3B0aW9ucxIQCghkZWFkbGluZRgBIAEoARIRCglmYWlsX2Zhc3QYAiABKAgSHQoVZHVwbGljYXRlX3N1cHByZXNzaW9uGAMgASgIEhcKD3NjaGVkdWxpbmdfaGFzaBgEIAEoBBJMCghwcm90b2NvbBgFIAEoDjI6LmFwcGhvc3RpbmcuU3R1YmJ5VGFza1J1bm5lclBheWxvYWQuUnBjT3B0aW9ucy5SUENQcm90b2NvbBJOCg9yZXNwb25zZV9mb3JtYXQYBiABKA4yNS5hcHBob3N0aW5nLlN0dWJieVRhc2tSdW5uZXJQYXlsb2FkLlJwY09wdGlvbnMuRm9ybWF0Ek0KDnJlcXVlc3RfZm9ybWF0GAcgASgOMjUuYXBwaG9zdGluZy5TdHViYnlUYXNrUnVubmVyUGF5bG9hZC5ScGNPcHRpb25zLkZvcm1hdCIfCgtSUENQcm90b2NvbBIHCgNUQ1AQABIHCgNVRFAQASIwCgZGb3JtYXQSEAoMVU5DT01QUkVTU0VEEAASFAoQWklQUFlfQ09NUFJFU1NFRBABMloKDnN0dWJieV9wYXlsb2FkEh0uYXBwaG9zdGluZy5UYXNrUnVubmVyUGF5bG9hZBgMIAEoCzIjLmFwcGhvc3RpbmcuU3R1YmJ5VGFza1J1bm5lclBheWxvYWQipQEKFFN0dWJieVRhc2tSdW5uZXJJbmZvEg4KBnN0YXR1cxgBIAIoAxIZChFhcHBsaWNhdGlvbl9lcnJvchgCIAEoAxIVCg1lcnJvcl9tZXNzYWdlGAMgASgMMksKBGluZm8SGi5hcHBob3N0aW5nLlRhc2tSdW5uZXJJbmZvGMkBIAEoCzIgLmFwcGhvc3RpbmcuU3R1YmJ5VGFza1J1bm5lckluZm8ieAoPUHVsbFRhc2tQYXlsb2FkEhMKB2NvbnRlbnQYASACKAxCAggBMlAKDHB1bGxfcGF5bG9hZBIdLmFwcGhvc3RpbmcuVGFza1J1bm5lclBheWxvYWQYDSABKAsyGy5hcHBob3N0aW5nLlB1bGxUYXNrUGF5bG9hZCLKAgoOVGFza0RlZmluaXRpb24SJQoIdGFza19yZWYYASACKAsyEy5hcHBob3N0aW5nLlRhc2tSZWYSEAoIZXRhX3VzZWMYAiACKAMSLgoHcGF5bG9hZBgDIAIoCzIdLmFwcGhvc3RpbmcuVGFza1J1bm5lclBheWxvYWQSFgoLcmV0cnlfY291bnQYBCABKAM6ATASFwoPc3RvcmVfdGltZXN0YW1wGAUgASgDEjoKFWxhc3RfaW52b2NhdGlvbl9zdGF0cxgGIAEoCzIbLmFwcGhvc3RpbmcuVGFza1J1bm5lclN0YXRzEhMKC2Rlc2NyaXB0aW9uGAcgASgMEjUKEHJldHJ5X3BhcmFtZXRlcnMYCCABKAsyGy5hcHBob3N0aW5nLlJldHJ5UGFyYW1ldGVycxIWCg5maXJzdF90cnlfdXNlYxgJIAEoAyIsChFUYXNrR29sZGVuVmVyc2lvbhIXCg9zdG9yZV90aW1lc3RhbXAYASACKANCJgoeY29tLmdvb2dsZS5hcHBob3N0aW5nLmV4ZWN1dG9yEAEgASgB"))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class TaskEtaIndexRef(ProtocolBuffer.ProtocolMessage):
  has_queue_ref_ = 0
  has_eta_usec_ = 0
  eta_usec_ = 0
  has_name_ = 0
  name_ = ""

  def __init__(self, contents=None):
    self.queue_ref_ = google.appengine.executor.queue_pb.QueueRef()
    if contents is not None: self.MergeFromString(contents)

  def queue_ref(self): return self.queue_ref_

  def mutable_queue_ref(self): self.has_queue_ref_ = 1; return self.queue_ref_

  def clear_queue_ref(self):self.has_queue_ref_ = 0; self.queue_ref_.Clear()

  def has_queue_ref(self): return self.has_queue_ref_

  def eta_usec(self): return self.eta_usec_

  def set_eta_usec(self, x):
    self.has_eta_usec_ = 1
    self.eta_usec_ = x

  def clear_eta_usec(self):
    if self.has_eta_usec_:
      self.has_eta_usec_ = 0
      self.eta_usec_ = 0

  def has_eta_usec(self): return self.has_eta_usec_

  def name(self): return self.name_

  def set_name(self, x):
    self.has_name_ = 1
    self.name_ = x

  def clear_name(self):
    if self.has_name_:
      self.has_name_ = 0
      self.name_ = ""

  def has_name(self): return self.has_name_


  def MergeFrom(self, x):
    assert x is not self
    if (x.has_queue_ref()): self.mutable_queue_ref().MergeFrom(x.queue_ref())
    if (x.has_eta_usec()): self.set_eta_usec(x.eta_usec())
    if (x.has_name()): self.set_name(x.name())

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.TaskEtaIndexRef', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.TaskEtaIndexRef')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.TaskEtaIndexRef')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.TaskEtaIndexRef', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.TaskEtaIndexRef', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.TaskEtaIndexRef', s)


  def Equals(self, x):
    if x is self: return 1
    if self.has_queue_ref_ != x.has_queue_ref_: return 0
    if self.has_queue_ref_ and self.queue_ref_ != x.queue_ref_: return 0
    if self.has_eta_usec_ != x.has_eta_usec_: return 0
    if self.has_eta_usec_ and self.eta_usec_ != x.eta_usec_: return 0
    if self.has_name_ != x.has_name_: return 0
    if self.has_name_ and self.name_ != x.name_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    if (not self.has_queue_ref_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: queue_ref not set.')
    elif not self.queue_ref_.IsInitialized(debug_strs): initialized = 0
    if (not self.has_eta_usec_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: eta_usec not set.')
    if (not self.has_name_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: name not set.')
    return initialized

  def ByteSize(self):
    n = 0
    n += self.lengthString(self.queue_ref_.ByteSize())
    n += self.lengthVarInt64(self.eta_usec_)
    n += self.lengthString(len(self.name_))
    return n + 3

  def ByteSizePartial(self):
    n = 0
    if (self.has_queue_ref_):
      n += 1
      n += self.lengthString(self.queue_ref_.ByteSizePartial())
    if (self.has_eta_usec_):
      n += 1
      n += self.lengthVarInt64(self.eta_usec_)
    if (self.has_name_):
      n += 1
      n += self.lengthString(len(self.name_))
    return n

  def Clear(self):
    self.clear_queue_ref()
    self.clear_eta_usec()
    self.clear_name()

  def OutputUnchecked(self, out):
    out.putVarInt32(10)
    out.putVarInt32(self.queue_ref_.ByteSize())
    self.queue_ref_.OutputUnchecked(out)
    out.putVarInt32(16)
    out.putVarInt64(self.eta_usec_)
    out.putVarInt32(26)
    out.putPrefixedString(self.name_)

  def OutputPartial(self, out):
    if (self.has_queue_ref_):
      out.putVarInt32(10)
      out.putVarInt32(self.queue_ref_.ByteSizePartial())
      self.queue_ref_.OutputPartial(out)
    if (self.has_eta_usec_):
      out.putVarInt32(16)
      out.putVarInt64(self.eta_usec_)
    if (self.has_name_):
      out.putVarInt32(26)
      out.putPrefixedString(self.name_)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 10:
        length = d.getVarInt32()
        tmp = ProtocolBuffer.Decoder(d.buffer(), d.pos(), d.pos() + length)
        d.skip(length)
        self.mutable_queue_ref().TryMerge(tmp)
        continue
      if tt == 16:
        self.set_eta_usec(d.getVarInt64())
        continue
      if tt == 26:
        self.set_name(d.getPrefixedString())
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    if self.has_queue_ref_:
      res+=prefix+"queue_ref <\n"
      res+=self.queue_ref_.__str__(prefix + "  ", printElemNumber)
      res+=prefix+">\n"
    if self.has_eta_usec_: res+=prefix+("eta_usec: %s\n" % self.DebugFormatInt64(self.eta_usec_))
    if self.has_name_: res+=prefix+("name: %s\n" % self.DebugFormatString(self.name_))
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  kqueue_ref = 1
  keta_usec = 2
  kname = 3

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "queue_ref",
    2: "eta_usec",
    3: "name",
  }, 3)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.STRING,
    2: ProtocolBuffer.Encoder.NUMERIC,
    3: ProtocolBuffer.Encoder.STRING,
  }, 3, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("Wh5hcHBob3N0aW5nL2V4ZWN1dG9yL3Rhc2sucHJvdG8KGmFwcGhvc3RpbmcuVGFza0V0YUluZGV4UmVmExoJcXVldWVfcmVmIAEoAjALOAJKE2FwcGhvc3RpbmcuUXVldWVSZWYUExoIZXRhX3VzZWMgAigAMAM4AhQTGgRuYW1lIAMoAjAJOAIUwgESYXBwaG9zdGluZy5UYXNrUmVm"))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class TaskEtaBorder(ProtocolBuffer.ProtocolMessage):
  has_eta_usec_ = 0
  eta_usec_ = 0
  has_name_ = 0
  name_ = ""

  def __init__(self, contents=None):
    if contents is not None: self.MergeFromString(contents)

  def eta_usec(self): return self.eta_usec_

  def set_eta_usec(self, x):
    self.has_eta_usec_ = 1
    self.eta_usec_ = x

  def clear_eta_usec(self):
    if self.has_eta_usec_:
      self.has_eta_usec_ = 0
      self.eta_usec_ = 0

  def has_eta_usec(self): return self.has_eta_usec_

  def name(self): return self.name_

  def set_name(self, x):
    self.has_name_ = 1
    self.name_ = x

  def clear_name(self):
    if self.has_name_:
      self.has_name_ = 0
      self.name_ = ""

  def has_name(self): return self.has_name_


  def MergeFrom(self, x):
    assert x is not self
    if (x.has_eta_usec()): self.set_eta_usec(x.eta_usec())
    if (x.has_name()): self.set_name(x.name())

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.TaskEtaBorder', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.TaskEtaBorder')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.TaskEtaBorder')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.TaskEtaBorder', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.TaskEtaBorder', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.TaskEtaBorder', s)


  def Equals(self, x):
    if x is self: return 1
    if self.has_eta_usec_ != x.has_eta_usec_: return 0
    if self.has_eta_usec_ and self.eta_usec_ != x.eta_usec_: return 0
    if self.has_name_ != x.has_name_: return 0
    if self.has_name_ and self.name_ != x.name_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    if (not self.has_eta_usec_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: eta_usec not set.')
    return initialized

  def ByteSize(self):
    n = 0
    n += self.lengthVarInt64(self.eta_usec_)
    if (self.has_name_): n += 1 + self.lengthString(len(self.name_))
    return n + 1

  def ByteSizePartial(self):
    n = 0
    if (self.has_eta_usec_):
      n += 1
      n += self.lengthVarInt64(self.eta_usec_)
    if (self.has_name_): n += 1 + self.lengthString(len(self.name_))
    return n

  def Clear(self):
    self.clear_eta_usec()
    self.clear_name()

  def OutputUnchecked(self, out):
    out.putVarInt32(8)
    out.putVarInt64(self.eta_usec_)
    if (self.has_name_):
      out.putVarInt32(18)
      out.putPrefixedString(self.name_)

  def OutputPartial(self, out):
    if (self.has_eta_usec_):
      out.putVarInt32(8)
      out.putVarInt64(self.eta_usec_)
    if (self.has_name_):
      out.putVarInt32(18)
      out.putPrefixedString(self.name_)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 8:
        self.set_eta_usec(d.getVarInt64())
        continue
      if tt == 18:
        self.set_name(d.getPrefixedString())
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    if self.has_eta_usec_: res+=prefix+("eta_usec: %s\n" % self.DebugFormatInt64(self.eta_usec_))
    if self.has_name_: res+=prefix+("name: %s\n" % self.DebugFormatString(self.name_))
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  keta_usec = 1
  kname = 2

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "eta_usec",
    2: "name",
  }, 2)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.NUMERIC,
    2: ProtocolBuffer.Encoder.STRING,
  }, 2, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("Wh5hcHBob3N0aW5nL2V4ZWN1dG9yL3Rhc2sucHJvdG8KGGFwcGhvc3RpbmcuVGFza0V0YUJvcmRlchMaCGV0YV91c2VjIAEoADADOAIUExoEbmFtZSACKAIwCTgBFMIBEmFwcGhvc3RpbmcuVGFza1JlZg=="))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class TaskRangeByEta(ProtocolBuffer.ProtocolMessage):


  MESSAGE_TYPE_ID =  100

  _TypeId_NAMES = {
    100: "MESSAGE_TYPE_ID",
  }

  def TypeId_Name(cls, x): return cls._TypeId_NAMES.get(x, "")
  TypeId_Name = classmethod(TypeId_Name)

  has_start_ = 0
  start_ = None
  has_limit_ = 0
  limit_ = None

  def __init__(self, contents=None):
    self.lazy_init_lock_ = thread.allocate_lock()
    if contents is not None: self.MergeFromString(contents)

  def start(self):
    if self.start_ is None:
      self.lazy_init_lock_.acquire()
      try:
        if self.start_ is None: self.start_ = TaskEtaBorder()
      finally:
        self.lazy_init_lock_.release()
    return self.start_

  def mutable_start(self): self.has_start_ = 1; return self.start()

  def clear_start(self):

    if self.has_start_:
      self.has_start_ = 0;
      if self.start_ is not None: self.start_.Clear()

  def has_start(self): return self.has_start_

  def limit(self):
    if self.limit_ is None:
      self.lazy_init_lock_.acquire()
      try:
        if self.limit_ is None: self.limit_ = TaskEtaBorder()
      finally:
        self.lazy_init_lock_.release()
    return self.limit_

  def mutable_limit(self): self.has_limit_ = 1; return self.limit()

  def clear_limit(self):

    if self.has_limit_:
      self.has_limit_ = 0;
      if self.limit_ is not None: self.limit_.Clear()

  def has_limit(self): return self.has_limit_


  def MergeFrom(self, x):
    assert x is not self
    if (x.has_start()): self.mutable_start().MergeFrom(x.start())
    if (x.has_limit()): self.mutable_limit().MergeFrom(x.limit())

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.TaskRangeByEta', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.TaskRangeByEta')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.TaskRangeByEta')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.TaskRangeByEta', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.TaskRangeByEta', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.TaskRangeByEta', s)


  def Equals(self, x):
    if x is self: return 1
    if self.has_start_ != x.has_start_: return 0
    if self.has_start_ and self.start_ != x.start_: return 0
    if self.has_limit_ != x.has_limit_: return 0
    if self.has_limit_ and self.limit_ != x.limit_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    if (self.has_start_ and not self.start_.IsInitialized(debug_strs)): initialized = 0
    if (self.has_limit_ and not self.limit_.IsInitialized(debug_strs)): initialized = 0
    return initialized

  def ByteSize(self):
    n = 0
    if (self.has_start_): n += 1 + self.lengthString(self.start_.ByteSize())
    if (self.has_limit_): n += 1 + self.lengthString(self.limit_.ByteSize())
    return n

  def ByteSizePartial(self):
    n = 0
    if (self.has_start_): n += 1 + self.lengthString(self.start_.ByteSizePartial())
    if (self.has_limit_): n += 1 + self.lengthString(self.limit_.ByteSizePartial())
    return n

  def Clear(self):
    self.clear_start()
    self.clear_limit()

  def OutputUnchecked(self, out):
    if (self.has_start_):
      out.putVarInt32(10)
      out.putVarInt32(self.start_.ByteSize())
      self.start_.OutputUnchecked(out)
    if (self.has_limit_):
      out.putVarInt32(18)
      out.putVarInt32(self.limit_.ByteSize())
      self.limit_.OutputUnchecked(out)

  def OutputPartial(self, out):
    if (self.has_start_):
      out.putVarInt32(10)
      out.putVarInt32(self.start_.ByteSizePartial())
      self.start_.OutputPartial(out)
    if (self.has_limit_):
      out.putVarInt32(18)
      out.putVarInt32(self.limit_.ByteSizePartial())
      self.limit_.OutputPartial(out)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 10:
        length = d.getVarInt32()
        tmp = ProtocolBuffer.Decoder(d.buffer(), d.pos(), d.pos() + length)
        d.skip(length)
        self.mutable_start().TryMerge(tmp)
        continue
      if tt == 18:
        length = d.getVarInt32()
        tmp = ProtocolBuffer.Decoder(d.buffer(), d.pos(), d.pos() + length)
        d.skip(length)
        self.mutable_limit().TryMerge(tmp)
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    if self.has_start_:
      res+=prefix+"start <\n"
      res+=self.start_.__str__(prefix + "  ", printElemNumber)
      res+=prefix+">\n"
    if self.has_limit_:
      res+=prefix+"limit <\n"
      res+=self.limit_.__str__(prefix + "  ", printElemNumber)
      res+=prefix+">\n"
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  kstart = 1
  klimit = 2

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "start",
    2: "limit",
  }, 2)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.STRING,
    2: ProtocolBuffer.Encoder.STRING,
  }, 2, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("Wh5hcHBob3N0aW5nL2V4ZWN1dG9yL3Rhc2sucHJvdG8KGWFwcGhvc3RpbmcuVGFza1JhbmdlQnlFdGETGgVzdGFydCABKAIwCzgBShhhcHBob3N0aW5nLlRhc2tFdGFCb3JkZXIUExoFbGltaXQgAigCMAs4AUoYYXBwaG9zdGluZy5UYXNrRXRhQm9yZGVyFHN6BlR5cGVJZIsBkgEPTUVTU0FHRV9UWVBFX0lEmAFkjAF0wgESYXBwaG9zdGluZy5UYXNrUmVm"))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class TaskRangeByName(ProtocolBuffer.ProtocolMessage):


  MESSAGE_TYPE_ID =  101

  _TypeId_NAMES = {
    101: "MESSAGE_TYPE_ID",
  }

  def TypeId_Name(cls, x): return cls._TypeId_NAMES.get(x, "")
  TypeId_Name = classmethod(TypeId_Name)

  has_start_ = 0
  start_ = ""
  has_limit_ = 0
  limit_ = ""

  def __init__(self, contents=None):
    if contents is not None: self.MergeFromString(contents)

  def start(self): return self.start_

  def set_start(self, x):
    self.has_start_ = 1
    self.start_ = x

  def clear_start(self):
    if self.has_start_:
      self.has_start_ = 0
      self.start_ = ""

  def has_start(self): return self.has_start_

  def limit(self): return self.limit_

  def set_limit(self, x):
    self.has_limit_ = 1
    self.limit_ = x

  def clear_limit(self):
    if self.has_limit_:
      self.has_limit_ = 0
      self.limit_ = ""

  def has_limit(self): return self.has_limit_


  def MergeFrom(self, x):
    assert x is not self
    if (x.has_start()): self.set_start(x.start())
    if (x.has_limit()): self.set_limit(x.limit())

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.TaskRangeByName', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.TaskRangeByName')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.TaskRangeByName')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.TaskRangeByName', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.TaskRangeByName', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.TaskRangeByName', s)


  def Equals(self, x):
    if x is self: return 1
    if self.has_start_ != x.has_start_: return 0
    if self.has_start_ and self.start_ != x.start_: return 0
    if self.has_limit_ != x.has_limit_: return 0
    if self.has_limit_ and self.limit_ != x.limit_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    return initialized

  def ByteSize(self):
    n = 0
    if (self.has_start_): n += 1 + self.lengthString(len(self.start_))
    if (self.has_limit_): n += 1 + self.lengthString(len(self.limit_))
    return n

  def ByteSizePartial(self):
    n = 0
    if (self.has_start_): n += 1 + self.lengthString(len(self.start_))
    if (self.has_limit_): n += 1 + self.lengthString(len(self.limit_))
    return n

  def Clear(self):
    self.clear_start()
    self.clear_limit()

  def OutputUnchecked(self, out):
    if (self.has_start_):
      out.putVarInt32(10)
      out.putPrefixedString(self.start_)
    if (self.has_limit_):
      out.putVarInt32(18)
      out.putPrefixedString(self.limit_)

  def OutputPartial(self, out):
    if (self.has_start_):
      out.putVarInt32(10)
      out.putPrefixedString(self.start_)
    if (self.has_limit_):
      out.putVarInt32(18)
      out.putPrefixedString(self.limit_)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 10:
        self.set_start(d.getPrefixedString())
        continue
      if tt == 18:
        self.set_limit(d.getPrefixedString())
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    if self.has_start_: res+=prefix+("start: %s\n" % self.DebugFormatString(self.start_))
    if self.has_limit_: res+=prefix+("limit: %s\n" % self.DebugFormatString(self.limit_))
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  kstart = 1
  klimit = 2

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "start",
    2: "limit",
  }, 2)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.STRING,
    2: ProtocolBuffer.Encoder.STRING,
  }, 2, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("Wh5hcHBob3N0aW5nL2V4ZWN1dG9yL3Rhc2sucHJvdG8KGmFwcGhvc3RpbmcuVGFza1JhbmdlQnlOYW1lExoFc3RhcnQgASgCMAk4ARQTGgVsaW1pdCACKAIwCTgBFHN6BlR5cGVJZIsBkgEPTUVTU0FHRV9UWVBFX0lEmAFljAF0wgESYXBwaG9zdGluZy5UYXNrUmVm"))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class HttpTaskRunnerInfo(ProtocolBuffer.ProtocolMessage):


  MESSAGE_TYPE_ID =  200

  _TypeId_NAMES = {
    200: "MESSAGE_TYPE_ID",
  }

  def TypeId_Name(cls, x): return cls._TypeId_NAMES.get(x, "")
  TypeId_Name = classmethod(TypeId_Name)

  has_response_code_ = 0
  response_code_ = 0

  def __init__(self, contents=None):
    if contents is not None: self.MergeFromString(contents)

  def response_code(self): return self.response_code_

  def set_response_code(self, x):
    self.has_response_code_ = 1
    self.response_code_ = x

  def clear_response_code(self):
    if self.has_response_code_:
      self.has_response_code_ = 0
      self.response_code_ = 0

  def has_response_code(self): return self.has_response_code_


  def MergeFrom(self, x):
    assert x is not self
    if (x.has_response_code()): self.set_response_code(x.response_code())

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.HttpTaskRunnerInfo', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.HttpTaskRunnerInfo')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.HttpTaskRunnerInfo')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.HttpTaskRunnerInfo', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.HttpTaskRunnerInfo', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.HttpTaskRunnerInfo', s)


  def Equals(self, x):
    if x is self: return 1
    if self.has_response_code_ != x.has_response_code_: return 0
    if self.has_response_code_ and self.response_code_ != x.response_code_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    if (not self.has_response_code_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: response_code not set.')
    return initialized

  def ByteSize(self):
    n = 0
    n += self.lengthVarInt64(self.response_code_)
    return n + 1

  def ByteSizePartial(self):
    n = 0
    if (self.has_response_code_):
      n += 1
      n += self.lengthVarInt64(self.response_code_)
    return n

  def Clear(self):
    self.clear_response_code()

  def OutputUnchecked(self, out):
    out.putVarInt32(8)
    out.putVarInt64(self.response_code_)

  def OutputPartial(self, out):
    if (self.has_response_code_):
      out.putVarInt32(8)
      out.putVarInt64(self.response_code_)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 8:
        self.set_response_code(d.getVarInt64())
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    if self.has_response_code_: res+=prefix+("response_code: %s\n" % self.DebugFormatInt64(self.response_code_))
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  kresponse_code = 1

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "response_code",
  }, 1)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.NUMERIC,
  }, 1, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("Wh5hcHBob3N0aW5nL2V4ZWN1dG9yL3Rhc2sucHJvdG8KHWFwcGhvc3RpbmcuSHR0cFRhc2tSdW5uZXJJbmZvExoNcmVzcG9uc2VfY29kZSABKAAwAzgCFHN6BlR5cGVJZIsBkgEPTUVTU0FHRV9UWVBFX0lEmAHIAYwBdMIBEmFwcGhvc3RpbmcuVGFza1JlZg=="))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class TaskRunnerStats(ProtocolBuffer.ProtocolMessage):
  has_dispatched_usec_ = 0
  dispatched_usec_ = 0
  has_lag_usec_ = 0
  lag_usec_ = 0
  has_elapsed_usec_ = 0
  elapsed_usec_ = 0
  has_info_ = 0
  info_ = None

  def __init__(self, contents=None):
    self.lazy_init_lock_ = thread.allocate_lock()
    if contents is not None: self.MergeFromString(contents)

  def dispatched_usec(self): return self.dispatched_usec_

  def set_dispatched_usec(self, x):
    self.has_dispatched_usec_ = 1
    self.dispatched_usec_ = x

  def clear_dispatched_usec(self):
    if self.has_dispatched_usec_:
      self.has_dispatched_usec_ = 0
      self.dispatched_usec_ = 0

  def has_dispatched_usec(self): return self.has_dispatched_usec_

  def lag_usec(self): return self.lag_usec_

  def set_lag_usec(self, x):
    self.has_lag_usec_ = 1
    self.lag_usec_ = x

  def clear_lag_usec(self):
    if self.has_lag_usec_:
      self.has_lag_usec_ = 0
      self.lag_usec_ = 0

  def has_lag_usec(self): return self.has_lag_usec_

  def elapsed_usec(self): return self.elapsed_usec_

  def set_elapsed_usec(self, x):
    self.has_elapsed_usec_ = 1
    self.elapsed_usec_ = x

  def clear_elapsed_usec(self):
    if self.has_elapsed_usec_:
      self.has_elapsed_usec_ = 0
      self.elapsed_usec_ = 0

  def has_elapsed_usec(self): return self.has_elapsed_usec_

  def info(self):
    if self.info_ is None:
      self.lazy_init_lock_.acquire()
      try:
        if self.info_ is None: self.info_ = MessageSet()
      finally:
        self.lazy_init_lock_.release()
    return self.info_

  def mutable_info(self): self.has_info_ = 1; return self.info()

  def clear_info(self):

    if self.has_info_:
      self.has_info_ = 0;
      if self.info_ is not None: self.info_.Clear()

  def has_info(self): return self.has_info_


  def MergeFrom(self, x):
    assert x is not self
    if (x.has_dispatched_usec()): self.set_dispatched_usec(x.dispatched_usec())
    if (x.has_lag_usec()): self.set_lag_usec(x.lag_usec())
    if (x.has_elapsed_usec()): self.set_elapsed_usec(x.elapsed_usec())
    if (x.has_info()): self.mutable_info().MergeFrom(x.info())

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.TaskRunnerStats', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.TaskRunnerStats')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.TaskRunnerStats')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.TaskRunnerStats', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.TaskRunnerStats', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.TaskRunnerStats', s)


  def Equals(self, x):
    if x is self: return 1
    if self.has_dispatched_usec_ != x.has_dispatched_usec_: return 0
    if self.has_dispatched_usec_ and self.dispatched_usec_ != x.dispatched_usec_: return 0
    if self.has_lag_usec_ != x.has_lag_usec_: return 0
    if self.has_lag_usec_ and self.lag_usec_ != x.lag_usec_: return 0
    if self.has_elapsed_usec_ != x.has_elapsed_usec_: return 0
    if self.has_elapsed_usec_ and self.elapsed_usec_ != x.elapsed_usec_: return 0
    if self.has_info_ != x.has_info_: return 0
    if self.has_info_ and self.info_ != x.info_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    if (not self.has_dispatched_usec_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: dispatched_usec not set.')
    if (not self.has_lag_usec_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: lag_usec not set.')
    if (not self.has_elapsed_usec_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: elapsed_usec not set.')
    if (self.has_info_ and not self.info_.IsInitialized(debug_strs)): initialized = 0
    return initialized

  def ByteSize(self):
    n = 0
    n += self.lengthVarInt64(self.dispatched_usec_)
    n += self.lengthVarInt64(self.lag_usec_)
    n += self.lengthVarInt64(self.elapsed_usec_)
    if (self.has_info_): n += 1 + self.lengthString(self.info_.ByteSize())
    return n + 3

  def ByteSizePartial(self):
    n = 0
    if (self.has_dispatched_usec_):
      n += 1
      n += self.lengthVarInt64(self.dispatched_usec_)
    if (self.has_lag_usec_):
      n += 1
      n += self.lengthVarInt64(self.lag_usec_)
    if (self.has_elapsed_usec_):
      n += 1
      n += self.lengthVarInt64(self.elapsed_usec_)
    if (self.has_info_): n += 1 + self.lengthString(self.info_.ByteSizePartial())
    return n

  def Clear(self):
    self.clear_dispatched_usec()
    self.clear_lag_usec()
    self.clear_elapsed_usec()
    self.clear_info()

  def OutputUnchecked(self, out):
    out.putVarInt32(8)
    out.putVarInt64(self.dispatched_usec_)
    out.putVarInt32(16)
    out.putVarInt64(self.lag_usec_)
    out.putVarInt32(24)
    out.putVarInt64(self.elapsed_usec_)
    if (self.has_info_):
      out.putVarInt32(34)
      out.putVarInt32(self.info_.ByteSize())
      self.info_.OutputUnchecked(out)

  def OutputPartial(self, out):
    if (self.has_dispatched_usec_):
      out.putVarInt32(8)
      out.putVarInt64(self.dispatched_usec_)
    if (self.has_lag_usec_):
      out.putVarInt32(16)
      out.putVarInt64(self.lag_usec_)
    if (self.has_elapsed_usec_):
      out.putVarInt32(24)
      out.putVarInt64(self.elapsed_usec_)
    if (self.has_info_):
      out.putVarInt32(34)
      out.putVarInt32(self.info_.ByteSizePartial())
      self.info_.OutputPartial(out)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 8:
        self.set_dispatched_usec(d.getVarInt64())
        continue
      if tt == 16:
        self.set_lag_usec(d.getVarInt64())
        continue
      if tt == 24:
        self.set_elapsed_usec(d.getVarInt64())
        continue
      if tt == 34:
        length = d.getVarInt32()
        tmp = ProtocolBuffer.Decoder(d.buffer(), d.pos(), d.pos() + length)
        d.skip(length)
        self.mutable_info().TryMerge(tmp)
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    if self.has_dispatched_usec_: res+=prefix+("dispatched_usec: %s\n" % self.DebugFormatInt64(self.dispatched_usec_))
    if self.has_lag_usec_: res+=prefix+("lag_usec: %s\n" % self.DebugFormatInt64(self.lag_usec_))
    if self.has_elapsed_usec_: res+=prefix+("elapsed_usec: %s\n" % self.DebugFormatInt64(self.elapsed_usec_))
    if self.has_info_:
      res+=prefix+"info <\n"
      res+=self.info_.__str__(prefix + "  ", printElemNumber)
      res+=prefix+">\n"
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  kdispatched_usec = 1
  klag_usec = 2
  kelapsed_usec = 3
  kinfo = 4

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "dispatched_usec",
    2: "lag_usec",
    3: "elapsed_usec",
    4: "info",
  }, 4)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.NUMERIC,
    2: ProtocolBuffer.Encoder.NUMERIC,
    3: ProtocolBuffer.Encoder.NUMERIC,
    4: ProtocolBuffer.Encoder.STRING,
  }, 4, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("Wh5hcHBob3N0aW5nL2V4ZWN1dG9yL3Rhc2sucHJvdG8KGmFwcGhvc3RpbmcuVGFza1J1bm5lclN0YXRzExoPZGlzcGF0Y2hlZF91c2VjIAEoADADOAIUExoIbGFnX3VzZWMgAigAMAM4AhQTGgxlbGFwc2VkX3VzZWMgAygAMAM4AhQTGgRpbmZvIAQoAjALOAFKCk1lc3NhZ2VTZXQUwgESYXBwaG9zdGluZy5UYXNrUmVm"))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class HttpTaskRunnerPayload_Header(ProtocolBuffer.ProtocolMessage):
  has_key_ = 0
  key_ = ""
  has_value_ = 0
  value_ = ""

  def __init__(self, contents=None):
    if contents is not None: self.MergeFromString(contents)

  def key(self): return self.key_

  def set_key(self, x):
    self.has_key_ = 1
    self.key_ = x

  def clear_key(self):
    if self.has_key_:
      self.has_key_ = 0
      self.key_ = ""

  def has_key(self): return self.has_key_

  def value(self): return self.value_

  def set_value(self, x):
    self.has_value_ = 1
    self.value_ = x

  def clear_value(self):
    if self.has_value_:
      self.has_value_ = 0
      self.value_ = ""

  def has_value(self): return self.has_value_


  def MergeFrom(self, x):
    assert x is not self
    if (x.has_key()): self.set_key(x.key())
    if (x.has_value()): self.set_value(x.value())

  def Equals(self, x):
    if x is self: return 1
    if self.has_key_ != x.has_key_: return 0
    if self.has_key_ and self.key_ != x.key_: return 0
    if self.has_value_ != x.has_value_: return 0
    if self.has_value_ and self.value_ != x.value_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    if (not self.has_key_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: key not set.')
    if (not self.has_value_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: value not set.')
    return initialized

  def ByteSize(self):
    n = 0
    n += self.lengthString(len(self.key_))
    n += self.lengthString(len(self.value_))
    return n + 2

  def ByteSizePartial(self):
    n = 0
    if (self.has_key_):
      n += 1
      n += self.lengthString(len(self.key_))
    if (self.has_value_):
      n += 1
      n += self.lengthString(len(self.value_))
    return n

  def Clear(self):
    self.clear_key()
    self.clear_value()

  def OutputUnchecked(self, out):
    out.putVarInt32(34)
    out.putPrefixedString(self.key_)
    out.putVarInt32(42)
    out.putPrefixedString(self.value_)

  def OutputPartial(self, out):
    if (self.has_key_):
      out.putVarInt32(34)
      out.putPrefixedString(self.key_)
    if (self.has_value_):
      out.putVarInt32(42)
      out.putPrefixedString(self.value_)

  def TryMerge(self, d):
    while 1:
      tt = d.getVarInt32()
      if tt == 28: break
      if tt == 34:
        self.set_key(d.getPrefixedString())
        continue
      if tt == 42:
        self.set_value(d.getPrefixedString())
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    if self.has_key_: res+=prefix+("key: %s\n" % self.DebugFormatString(self.key_))
    if self.has_value_: res+=prefix+("value: %s\n" % self.DebugFormatString(self.value_))
    return res

class HttpTaskRunnerPayload(ProtocolBuffer.ProtocolMessage):


  MESSAGE_TYPE_ID =   10

  _TypeId_NAMES = {
    10: "MESSAGE_TYPE_ID",
  }

  def TypeId_Name(cls, x): return cls._TypeId_NAMES.get(x, "")
  TypeId_Name = classmethod(TypeId_Name)



  GET          =    1
  POST         =    2
  HEAD         =    3
  PUT          =    4
  DELETE       =    5

  _RequestMethod_NAMES = {
    1: "GET",
    2: "POST",
    3: "HEAD",
    4: "PUT",
    5: "DELETE",
  }

  def RequestMethod_Name(cls, x): return cls._RequestMethod_NAMES.get(x, "")
  RequestMethod_Name = classmethod(RequestMethod_Name)

  has_method_ = 0
  method_ = 2
  has_url_ = 0
  url_ = ""
  has_body_ = 0
  body_ = ""

  def __init__(self, contents=None):
    self.header_ = []
    if contents is not None: self.MergeFromString(contents)

  def method(self): return self.method_

  def set_method(self, x):
    self.has_method_ = 1
    self.method_ = x

  def clear_method(self):
    if self.has_method_:
      self.has_method_ = 0
      self.method_ = 2

  def has_method(self): return self.has_method_

  def url(self): return self.url_

  def set_url(self, x):
    self.has_url_ = 1
    self.url_ = x

  def clear_url(self):
    if self.has_url_:
      self.has_url_ = 0
      self.url_ = ""

  def has_url(self): return self.has_url_

  def header_size(self): return len(self.header_)
  def header_list(self): return self.header_

  def header(self, i):
    return self.header_[i]

  def mutable_header(self, i):
    return self.header_[i]

  def add_header(self):
    x = HttpTaskRunnerPayload_Header()
    self.header_.append(x)
    return x

  def clear_header(self):
    self.header_ = []
  def body(self): return self.body_

  def set_body(self, x):
    self.has_body_ = 1
    self.body_ = x

  def clear_body(self):
    if self.has_body_:
      self.has_body_ = 0
      self.body_ = ""

  def has_body(self): return self.has_body_


  def MergeFrom(self, x):
    assert x is not self
    if (x.has_method()): self.set_method(x.method())
    if (x.has_url()): self.set_url(x.url())
    for i in xrange(x.header_size()): self.add_header().CopyFrom(x.header(i))
    if (x.has_body()): self.set_body(x.body())

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.HttpTaskRunnerPayload', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.HttpTaskRunnerPayload')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.HttpTaskRunnerPayload')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.HttpTaskRunnerPayload', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.HttpTaskRunnerPayload', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.HttpTaskRunnerPayload', s)


  def Equals(self, x):
    if x is self: return 1
    if self.has_method_ != x.has_method_: return 0
    if self.has_method_ and self.method_ != x.method_: return 0
    if self.has_url_ != x.has_url_: return 0
    if self.has_url_ and self.url_ != x.url_: return 0
    if len(self.header_) != len(x.header_): return 0
    for e1, e2 in zip(self.header_, x.header_):
      if e1 != e2: return 0
    if self.has_body_ != x.has_body_: return 0
    if self.has_body_ and self.body_ != x.body_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    if (not self.has_url_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: url not set.')
    for p in self.header_:
      if not p.IsInitialized(debug_strs): initialized=0
    return initialized

  def ByteSize(self):
    n = 0
    if (self.has_method_): n += 1 + self.lengthVarInt64(self.method_)
    n += self.lengthString(len(self.url_))
    n += 2 * len(self.header_)
    for i in xrange(len(self.header_)): n += self.header_[i].ByteSize()
    if (self.has_body_): n += 1 + self.lengthString(len(self.body_))
    return n + 1

  def ByteSizePartial(self):
    n = 0
    if (self.has_method_): n += 1 + self.lengthVarInt64(self.method_)
    if (self.has_url_):
      n += 1
      n += self.lengthString(len(self.url_))
    n += 2 * len(self.header_)
    for i in xrange(len(self.header_)): n += self.header_[i].ByteSizePartial()
    if (self.has_body_): n += 1 + self.lengthString(len(self.body_))
    return n

  def Clear(self):
    self.clear_method()
    self.clear_url()
    self.clear_header()
    self.clear_body()

  def OutputUnchecked(self, out):
    if (self.has_method_):
      out.putVarInt32(8)
      out.putVarInt32(self.method_)
    out.putVarInt32(18)
    out.putPrefixedString(self.url_)
    for i in xrange(len(self.header_)):
      out.putVarInt32(27)
      self.header_[i].OutputUnchecked(out)
      out.putVarInt32(28)
    if (self.has_body_):
      out.putVarInt32(50)
      out.putPrefixedString(self.body_)

  def OutputPartial(self, out):
    if (self.has_method_):
      out.putVarInt32(8)
      out.putVarInt32(self.method_)
    if (self.has_url_):
      out.putVarInt32(18)
      out.putPrefixedString(self.url_)
    for i in xrange(len(self.header_)):
      out.putVarInt32(27)
      self.header_[i].OutputPartial(out)
      out.putVarInt32(28)
    if (self.has_body_):
      out.putVarInt32(50)
      out.putPrefixedString(self.body_)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 8:
        self.set_method(d.getVarInt32())
        continue
      if tt == 18:
        self.set_url(d.getPrefixedString())
        continue
      if tt == 27:
        self.add_header().TryMerge(d)
        continue
      if tt == 50:
        self.set_body(d.getPrefixedString())
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    if self.has_method_: res+=prefix+("method: %s\n" % self.DebugFormatInt32(self.method_))
    if self.has_url_: res+=prefix+("url: %s\n" % self.DebugFormatString(self.url_))
    cnt=0
    for e in self.header_:
      elm=""
      if printElemNumber: elm="(%d)" % cnt
      res+=prefix+("Header%s {\n" % elm)
      res+=e.__str__(prefix + "  ", printElemNumber)
      res+=prefix+"}\n"
      cnt+=1
    if self.has_body_: res+=prefix+("body: %s\n" % self.DebugFormatString(self.body_))
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  kmethod = 1
  kurl = 2
  kHeaderGroup = 3
  kHeaderkey = 4
  kHeadervalue = 5
  kbody = 6

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "method",
    2: "url",
    3: "Header",
    4: "key",
    5: "value",
    6: "body",
  }, 6)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.NUMERIC,
    2: ProtocolBuffer.Encoder.STRING,
    3: ProtocolBuffer.Encoder.STARTGROUP,
    4: ProtocolBuffer.Encoder.STRING,
    5: ProtocolBuffer.Encoder.STRING,
    6: ProtocolBuffer.Encoder.STRING,
  }, 6, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("Wh5hcHBob3N0aW5nL2V4ZWN1dG9yL3Rhc2sucHJvdG8KIGFwcGhvc3RpbmcuSHR0cFRhc2tSdW5uZXJQYXlsb2FkExoGbWV0aG9kIAEoADAFOAFCATJoAaMBqgEHZGVmYXVsdLIBBFBPU1SkARQTGgN1cmwgAigCMAk4AhQTGgZIZWFkZXIgAygDMAo4AxQTGgpIZWFkZXIua2V5IAQoAjAJOAJgAhQTGgxIZWFkZXIudmFsdWUgBSgCMAk4AmACFBMaBGJvZHkgBigCMAk4AaMBqgEFY3R5cGWyAQRDb3JkpAEUc3oGVHlwZUlkiwGSAQ9NRVNTQUdFX1RZUEVfSUSYAQqMAXRzeg1SZXF1ZXN0TWV0aG9kiwGSAQNHRVSYAQGMAYsBkgEEUE9TVJgBAowBiwGSAQRIRUFEmAEDjAGLAZIBA1BVVJgBBIwBiwGSAQZERUxFVEWYAQWMAXTCARJhcHBob3N0aW5nLlRhc2tSZWY="))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class CronTaskRunnerPayload(ProtocolBuffer.ProtocolMessage):


  MESSAGE_TYPE_ID =   11

  _TypeId_NAMES = {
    11: "MESSAGE_TYPE_ID",
  }

  def TypeId_Name(cls, x): return cls._TypeId_NAMES.get(x, "")
  TypeId_Name = classmethod(TypeId_Name)

  has_schedule_ = 0
  schedule_ = ""
  has_timezone_ = 0
  timezone_ = ""
  has_delegated_payload_ = 0
  has_skip_num_iterations_ = 0
  skip_num_iterations_ = 0

  def __init__(self, contents=None):
    self.delegated_payload_ = MessageSet()
    if contents is not None: self.MergeFromString(contents)

  def schedule(self): return self.schedule_

  def set_schedule(self, x):
    self.has_schedule_ = 1
    self.schedule_ = x

  def clear_schedule(self):
    if self.has_schedule_:
      self.has_schedule_ = 0
      self.schedule_ = ""

  def has_schedule(self): return self.has_schedule_

  def timezone(self): return self.timezone_

  def set_timezone(self, x):
    self.has_timezone_ = 1
    self.timezone_ = x

  def clear_timezone(self):
    if self.has_timezone_:
      self.has_timezone_ = 0
      self.timezone_ = ""

  def has_timezone(self): return self.has_timezone_

  def delegated_payload(self): return self.delegated_payload_

  def mutable_delegated_payload(self): self.has_delegated_payload_ = 1; return self.delegated_payload_

  def clear_delegated_payload(self):self.has_delegated_payload_ = 0; self.delegated_payload_.Clear()

  def has_delegated_payload(self): return self.has_delegated_payload_

  def skip_num_iterations(self): return self.skip_num_iterations_

  def set_skip_num_iterations(self, x):
    self.has_skip_num_iterations_ = 1
    self.skip_num_iterations_ = x

  def clear_skip_num_iterations(self):
    if self.has_skip_num_iterations_:
      self.has_skip_num_iterations_ = 0
      self.skip_num_iterations_ = 0

  def has_skip_num_iterations(self): return self.has_skip_num_iterations_


  def MergeFrom(self, x):
    assert x is not self
    if (x.has_schedule()): self.set_schedule(x.schedule())
    if (x.has_timezone()): self.set_timezone(x.timezone())
    if (x.has_delegated_payload()): self.mutable_delegated_payload().MergeFrom(x.delegated_payload())
    if (x.has_skip_num_iterations()): self.set_skip_num_iterations(x.skip_num_iterations())

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.CronTaskRunnerPayload', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.CronTaskRunnerPayload')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.CronTaskRunnerPayload')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.CronTaskRunnerPayload', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.CronTaskRunnerPayload', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.CronTaskRunnerPayload', s)


  def Equals(self, x):
    if x is self: return 1
    if self.has_schedule_ != x.has_schedule_: return 0
    if self.has_schedule_ and self.schedule_ != x.schedule_: return 0
    if self.has_timezone_ != x.has_timezone_: return 0
    if self.has_timezone_ and self.timezone_ != x.timezone_: return 0
    if self.has_delegated_payload_ != x.has_delegated_payload_: return 0
    if self.has_delegated_payload_ and self.delegated_payload_ != x.delegated_payload_: return 0
    if self.has_skip_num_iterations_ != x.has_skip_num_iterations_: return 0
    if self.has_skip_num_iterations_ and self.skip_num_iterations_ != x.skip_num_iterations_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    if (not self.has_schedule_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: schedule not set.')
    if (not self.has_timezone_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: timezone not set.')
    if (not self.has_delegated_payload_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: delegated_payload not set.')
    elif not self.delegated_payload_.IsInitialized(debug_strs): initialized = 0
    return initialized

  def ByteSize(self):
    n = 0
    n += self.lengthString(len(self.schedule_))
    n += self.lengthString(len(self.timezone_))
    n += self.lengthString(self.delegated_payload_.ByteSize())
    if (self.has_skip_num_iterations_): n += 1 + self.lengthVarInt64(self.skip_num_iterations_)
    return n + 3

  def ByteSizePartial(self):
    n = 0
    if (self.has_schedule_):
      n += 1
      n += self.lengthString(len(self.schedule_))
    if (self.has_timezone_):
      n += 1
      n += self.lengthString(len(self.timezone_))
    if (self.has_delegated_payload_):
      n += 1
      n += self.lengthString(self.delegated_payload_.ByteSizePartial())
    if (self.has_skip_num_iterations_): n += 1 + self.lengthVarInt64(self.skip_num_iterations_)
    return n

  def Clear(self):
    self.clear_schedule()
    self.clear_timezone()
    self.clear_delegated_payload()
    self.clear_skip_num_iterations()

  def OutputUnchecked(self, out):
    out.putVarInt32(10)
    out.putPrefixedString(self.schedule_)
    out.putVarInt32(18)
    out.putPrefixedString(self.timezone_)
    out.putVarInt32(26)
    out.putVarInt32(self.delegated_payload_.ByteSize())
    self.delegated_payload_.OutputUnchecked(out)
    if (self.has_skip_num_iterations_):
      out.putVarInt32(32)
      out.putVarInt64(self.skip_num_iterations_)

  def OutputPartial(self, out):
    if (self.has_schedule_):
      out.putVarInt32(10)
      out.putPrefixedString(self.schedule_)
    if (self.has_timezone_):
      out.putVarInt32(18)
      out.putPrefixedString(self.timezone_)
    if (self.has_delegated_payload_):
      out.putVarInt32(26)
      out.putVarInt32(self.delegated_payload_.ByteSizePartial())
      self.delegated_payload_.OutputPartial(out)
    if (self.has_skip_num_iterations_):
      out.putVarInt32(32)
      out.putVarInt64(self.skip_num_iterations_)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 10:
        self.set_schedule(d.getPrefixedString())
        continue
      if tt == 18:
        self.set_timezone(d.getPrefixedString())
        continue
      if tt == 26:
        length = d.getVarInt32()
        tmp = ProtocolBuffer.Decoder(d.buffer(), d.pos(), d.pos() + length)
        d.skip(length)
        self.mutable_delegated_payload().TryMerge(tmp)
        continue
      if tt == 32:
        self.set_skip_num_iterations(d.getVarInt64())
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    if self.has_schedule_: res+=prefix+("schedule: %s\n" % self.DebugFormatString(self.schedule_))
    if self.has_timezone_: res+=prefix+("timezone: %s\n" % self.DebugFormatString(self.timezone_))
    if self.has_delegated_payload_:
      res+=prefix+"delegated_payload <\n"
      res+=self.delegated_payload_.__str__(prefix + "  ", printElemNumber)
      res+=prefix+">\n"
    if self.has_skip_num_iterations_: res+=prefix+("skip_num_iterations: %s\n" % self.DebugFormatInt64(self.skip_num_iterations_))
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  kschedule = 1
  ktimezone = 2
  kdelegated_payload = 3
  kskip_num_iterations = 4

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "schedule",
    2: "timezone",
    3: "delegated_payload",
    4: "skip_num_iterations",
  }, 4)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.STRING,
    2: ProtocolBuffer.Encoder.STRING,
    3: ProtocolBuffer.Encoder.STRING,
    4: ProtocolBuffer.Encoder.NUMERIC,
  }, 4, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("Wh5hcHBob3N0aW5nL2V4ZWN1dG9yL3Rhc2sucHJvdG8KIGFwcGhvc3RpbmcuQ3JvblRhc2tSdW5uZXJQYXlsb2FkExoIc2NoZWR1bGUgASgCMAk4AhQTGgh0aW1lem9uZSACKAIwCTgCFBMaEWRlbGVnYXRlZF9wYXlsb2FkIAMoAjALOAJKCk1lc3NhZ2VTZXQUExoTc2tpcF9udW1faXRlcmF0aW9ucyAEKAAwAzgBFHN6BlR5cGVJZIsBkgEPTUVTU0FHRV9UWVBFX0lEmAELjAF0wgESYXBwaG9zdGluZy5UYXNrUmVm"))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class StubbyTaskRunnerPayload_StubbyChannel(ProtocolBuffer.ProtocolMessage):


  LEAST_LOADED =    1
  ROUND_ROBIN  =    2
  FIRST_REACHABLE =    3
  AFFINITY_SCHEDULING =    4
  ERROR_ADVERSE =    5
  FIRST_LEAST_LOADED =    6
  INVERSE_RTT  =    7
  LATENCY_DRIVEN_RR =    8

  _LoadBalancingPolicy_NAMES = {
    1: "LEAST_LOADED",
    2: "ROUND_ROBIN",
    3: "FIRST_REACHABLE",
    4: "AFFINITY_SCHEDULING",
    5: "ERROR_ADVERSE",
    6: "FIRST_LEAST_LOADED",
    7: "INVERSE_RTT",
    8: "LATENCY_DRIVEN_RR",
  }

  def LoadBalancingPolicy_Name(cls, x): return cls._LoadBalancingPolicy_NAMES.get(x, "")
  LoadBalancingPolicy_Name = classmethod(LoadBalancingPolicy_Name)



  NO_FILTER    =    1
  RANDOM_SUBSET =    2
  NETWORK_AWARE =    3

  _TargetSelectionPolicy_NAMES = {
    1: "NO_FILTER",
    2: "RANDOM_SUBSET",
    3: "NETWORK_AWARE",
  }

  def TargetSelectionPolicy_Name(cls, x): return cls._TargetSelectionPolicy_NAMES.get(x, "")
  TargetSelectionPolicy_Name = classmethod(TargetSelectionPolicy_Name)

  has_host_ = 0
  host_ = ""
  has_load_balancing_policy_ = 0
  load_balancing_policy_ = 1
  has_security_protocol_ = 0
  security_protocol_ = "loas"
  has_min_security_level_ = 0
  min_security_level_ = 0
  has_target_selection_policy_ = 0
  target_selection_policy_ = 1
  has_max_targets_ = 0
  max_targets_ = 5
  has_max_outstanding_rpcs_ = 0
  max_outstanding_rpcs_ = 0

  def __init__(self, contents=None):
    if contents is not None: self.MergeFromString(contents)

  def host(self): return self.host_

  def set_host(self, x):
    self.has_host_ = 1
    self.host_ = x

  def clear_host(self):
    if self.has_host_:
      self.has_host_ = 0
      self.host_ = ""

  def has_host(self): return self.has_host_

  def load_balancing_policy(self): return self.load_balancing_policy_

  def set_load_balancing_policy(self, x):
    self.has_load_balancing_policy_ = 1
    self.load_balancing_policy_ = x

  def clear_load_balancing_policy(self):
    if self.has_load_balancing_policy_:
      self.has_load_balancing_policy_ = 0
      self.load_balancing_policy_ = 1

  def has_load_balancing_policy(self): return self.has_load_balancing_policy_

  def security_protocol(self): return self.security_protocol_

  def set_security_protocol(self, x):
    self.has_security_protocol_ = 1
    self.security_protocol_ = x

  def clear_security_protocol(self):
    if self.has_security_protocol_:
      self.has_security_protocol_ = 0
      self.security_protocol_ = "loas"

  def has_security_protocol(self): return self.has_security_protocol_

  def min_security_level(self): return self.min_security_level_

  def set_min_security_level(self, x):
    self.has_min_security_level_ = 1
    self.min_security_level_ = x

  def clear_min_security_level(self):
    if self.has_min_security_level_:
      self.has_min_security_level_ = 0
      self.min_security_level_ = 0

  def has_min_security_level(self): return self.has_min_security_level_

  def target_selection_policy(self): return self.target_selection_policy_

  def set_target_selection_policy(self, x):
    self.has_target_selection_policy_ = 1
    self.target_selection_policy_ = x

  def clear_target_selection_policy(self):
    if self.has_target_selection_policy_:
      self.has_target_selection_policy_ = 0
      self.target_selection_policy_ = 1

  def has_target_selection_policy(self): return self.has_target_selection_policy_

  def max_targets(self): return self.max_targets_

  def set_max_targets(self, x):
    self.has_max_targets_ = 1
    self.max_targets_ = x

  def clear_max_targets(self):
    if self.has_max_targets_:
      self.has_max_targets_ = 0
      self.max_targets_ = 5

  def has_max_targets(self): return self.has_max_targets_

  def max_outstanding_rpcs(self): return self.max_outstanding_rpcs_

  def set_max_outstanding_rpcs(self, x):
    self.has_max_outstanding_rpcs_ = 1
    self.max_outstanding_rpcs_ = x

  def clear_max_outstanding_rpcs(self):
    if self.has_max_outstanding_rpcs_:
      self.has_max_outstanding_rpcs_ = 0
      self.max_outstanding_rpcs_ = 0

  def has_max_outstanding_rpcs(self): return self.has_max_outstanding_rpcs_


  def MergeFrom(self, x):
    assert x is not self
    if (x.has_host()): self.set_host(x.host())
    if (x.has_load_balancing_policy()): self.set_load_balancing_policy(x.load_balancing_policy())
    if (x.has_security_protocol()): self.set_security_protocol(x.security_protocol())
    if (x.has_min_security_level()): self.set_min_security_level(x.min_security_level())
    if (x.has_target_selection_policy()): self.set_target_selection_policy(x.target_selection_policy())
    if (x.has_max_targets()): self.set_max_targets(x.max_targets())
    if (x.has_max_outstanding_rpcs()): self.set_max_outstanding_rpcs(x.max_outstanding_rpcs())

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.StubbyTaskRunnerPayload_StubbyChannel', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.StubbyTaskRunnerPayload_StubbyChannel')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.StubbyTaskRunnerPayload_StubbyChannel')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.StubbyTaskRunnerPayload_StubbyChannel', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.StubbyTaskRunnerPayload_StubbyChannel', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.StubbyTaskRunnerPayload_StubbyChannel', s)


  def Equals(self, x):
    if x is self: return 1
    if self.has_host_ != x.has_host_: return 0
    if self.has_host_ and self.host_ != x.host_: return 0
    if self.has_load_balancing_policy_ != x.has_load_balancing_policy_: return 0
    if self.has_load_balancing_policy_ and self.load_balancing_policy_ != x.load_balancing_policy_: return 0
    if self.has_security_protocol_ != x.has_security_protocol_: return 0
    if self.has_security_protocol_ and self.security_protocol_ != x.security_protocol_: return 0
    if self.has_min_security_level_ != x.has_min_security_level_: return 0
    if self.has_min_security_level_ and self.min_security_level_ != x.min_security_level_: return 0
    if self.has_target_selection_policy_ != x.has_target_selection_policy_: return 0
    if self.has_target_selection_policy_ and self.target_selection_policy_ != x.target_selection_policy_: return 0
    if self.has_max_targets_ != x.has_max_targets_: return 0
    if self.has_max_targets_ and self.max_targets_ != x.max_targets_: return 0
    if self.has_max_outstanding_rpcs_ != x.has_max_outstanding_rpcs_: return 0
    if self.has_max_outstanding_rpcs_ and self.max_outstanding_rpcs_ != x.max_outstanding_rpcs_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    if (not self.has_host_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: host not set.')
    return initialized

  def ByteSize(self):
    n = 0
    n += self.lengthString(len(self.host_))
    if (self.has_load_balancing_policy_): n += 1 + self.lengthVarInt64(self.load_balancing_policy_)
    if (self.has_security_protocol_): n += 1 + self.lengthString(len(self.security_protocol_))
    if (self.has_min_security_level_): n += 1 + self.lengthVarInt64(self.min_security_level_)
    if (self.has_target_selection_policy_): n += 1 + self.lengthVarInt64(self.target_selection_policy_)
    if (self.has_max_targets_): n += 1 + self.lengthVarInt64(self.max_targets_)
    if (self.has_max_outstanding_rpcs_): n += 1 + self.lengthVarInt64(self.max_outstanding_rpcs_)
    return n + 1

  def ByteSizePartial(self):
    n = 0
    if (self.has_host_):
      n += 1
      n += self.lengthString(len(self.host_))
    if (self.has_load_balancing_policy_): n += 1 + self.lengthVarInt64(self.load_balancing_policy_)
    if (self.has_security_protocol_): n += 1 + self.lengthString(len(self.security_protocol_))
    if (self.has_min_security_level_): n += 1 + self.lengthVarInt64(self.min_security_level_)
    if (self.has_target_selection_policy_): n += 1 + self.lengthVarInt64(self.target_selection_policy_)
    if (self.has_max_targets_): n += 1 + self.lengthVarInt64(self.max_targets_)
    if (self.has_max_outstanding_rpcs_): n += 1 + self.lengthVarInt64(self.max_outstanding_rpcs_)
    return n

  def Clear(self):
    self.clear_host()
    self.clear_load_balancing_policy()
    self.clear_security_protocol()
    self.clear_min_security_level()
    self.clear_target_selection_policy()
    self.clear_max_targets()
    self.clear_max_outstanding_rpcs()

  def OutputUnchecked(self, out):
    out.putVarInt32(10)
    out.putPrefixedString(self.host_)
    if (self.has_load_balancing_policy_):
      out.putVarInt32(16)
      out.putVarInt32(self.load_balancing_policy_)
    if (self.has_security_protocol_):
      out.putVarInt32(26)
      out.putPrefixedString(self.security_protocol_)
    if (self.has_min_security_level_):
      out.putVarInt32(32)
      out.putVarInt32(self.min_security_level_)
    if (self.has_target_selection_policy_):
      out.putVarInt32(40)
      out.putVarInt32(self.target_selection_policy_)
    if (self.has_max_targets_):
      out.putVarInt32(48)
      out.putVarInt32(self.max_targets_)
    if (self.has_max_outstanding_rpcs_):
      out.putVarInt32(56)
      out.putVarInt32(self.max_outstanding_rpcs_)

  def OutputPartial(self, out):
    if (self.has_host_):
      out.putVarInt32(10)
      out.putPrefixedString(self.host_)
    if (self.has_load_balancing_policy_):
      out.putVarInt32(16)
      out.putVarInt32(self.load_balancing_policy_)
    if (self.has_security_protocol_):
      out.putVarInt32(26)
      out.putPrefixedString(self.security_protocol_)
    if (self.has_min_security_level_):
      out.putVarInt32(32)
      out.putVarInt32(self.min_security_level_)
    if (self.has_target_selection_policy_):
      out.putVarInt32(40)
      out.putVarInt32(self.target_selection_policy_)
    if (self.has_max_targets_):
      out.putVarInt32(48)
      out.putVarInt32(self.max_targets_)
    if (self.has_max_outstanding_rpcs_):
      out.putVarInt32(56)
      out.putVarInt32(self.max_outstanding_rpcs_)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 10:
        self.set_host(d.getPrefixedString())
        continue
      if tt == 16:
        self.set_load_balancing_policy(d.getVarInt32())
        continue
      if tt == 26:
        self.set_security_protocol(d.getPrefixedString())
        continue
      if tt == 32:
        self.set_min_security_level(d.getVarInt32())
        continue
      if tt == 40:
        self.set_target_selection_policy(d.getVarInt32())
        continue
      if tt == 48:
        self.set_max_targets(d.getVarInt32())
        continue
      if tt == 56:
        self.set_max_outstanding_rpcs(d.getVarInt32())
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    if self.has_host_: res+=prefix+("host: %s\n" % self.DebugFormatString(self.host_))
    if self.has_load_balancing_policy_: res+=prefix+("load_balancing_policy: %s\n" % self.DebugFormatInt32(self.load_balancing_policy_))
    if self.has_security_protocol_: res+=prefix+("security_protocol: %s\n" % self.DebugFormatString(self.security_protocol_))
    if self.has_min_security_level_: res+=prefix+("min_security_level: %s\n" % self.DebugFormatInt32(self.min_security_level_))
    if self.has_target_selection_policy_: res+=prefix+("target_selection_policy: %s\n" % self.DebugFormatInt32(self.target_selection_policy_))
    if self.has_max_targets_: res+=prefix+("max_targets: %s\n" % self.DebugFormatInt32(self.max_targets_))
    if self.has_max_outstanding_rpcs_: res+=prefix+("max_outstanding_rpcs: %s\n" % self.DebugFormatInt32(self.max_outstanding_rpcs_))
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  khost = 1
  kload_balancing_policy = 2
  ksecurity_protocol = 3
  kmin_security_level = 4
  ktarget_selection_policy = 5
  kmax_targets = 6
  kmax_outstanding_rpcs = 7

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "host",
    2: "load_balancing_policy",
    3: "security_protocol",
    4: "min_security_level",
    5: "target_selection_policy",
    6: "max_targets",
    7: "max_outstanding_rpcs",
  }, 7)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.STRING,
    2: ProtocolBuffer.Encoder.NUMERIC,
    3: ProtocolBuffer.Encoder.STRING,
    4: ProtocolBuffer.Encoder.NUMERIC,
    5: ProtocolBuffer.Encoder.NUMERIC,
    6: ProtocolBuffer.Encoder.NUMERIC,
    7: ProtocolBuffer.Encoder.NUMERIC,
  }, 7, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("Wh5hcHBob3N0aW5nL2V4ZWN1dG9yL3Rhc2sucHJvdG8KMGFwcGhvc3RpbmcuU3R1YmJ5VGFza1J1bm5lclBheWxvYWRfU3R1YmJ5Q2hhbm5lbBMaBGhvc3QgASgCMAk4AhQTGhVsb2FkX2JhbGFuY2luZ19wb2xpY3kgAigAMAU4AUIBMWgAowGqAQdkZWZhdWx0sgEMTEVBU1RfTE9BREVEpAEUExoRc2VjdXJpdHlfcHJvdG9jb2wgAygCMAk4AUIEbG9hc6MBqgEHZGVmYXVsdLIBBiJsb2FzIqQBFBMaEm1pbl9zZWN1cml0eV9sZXZlbCAEKAAwBTgBFBMaF3RhcmdldF9zZWxlY3Rpb25fcG9saWN5IAUoADAFOAFCATFoAaMBqgEHZGVmYXVsdLIBCU5PX0ZJTFRFUqQBFBMaC21heF90YXJnZXRzIAYoADAFOAFCATWjAaoBB2RlZmF1bHSyAQE1pAEUExoUbWF4X291dHN0YW5kaW5nX3JwY3MgBygAMAU4ARRzehNMb2FkQmFsYW5jaW5nUG9saWN5iwGSAQxMRUFTVF9MT0FERUSYAQGMAYsBkgELUk9VTkRfUk9CSU6YAQKMAYsBkgEPRklSU1RfUkVBQ0hBQkxFmAEDjAGLAZIBE0FGRklOSVRZX1NDSEVEVUxJTkeYAQSMAYsBkgENRVJST1JfQURWRVJTRZgBBYwBiwGSARJGSVJTVF9MRUFTVF9MT0FERUSYAQaMAYsBkgELSU5WRVJTRV9SVFSYAQeMAYsBkgERTEFURU5DWV9EUklWRU5fUlKYAQiMAXRzehVUYXJnZXRTZWxlY3Rpb25Qb2xpY3mLAZIBCU5PX0ZJTFRFUpgBAYwBiwGSAQ1SQU5ET01fU1VCU0VUmAECjAGLAZIBDU5FVFdPUktfQVdBUkWYAQOMAXTCARJhcHBob3N0aW5nLlRhc2tSZWbKATBhcHBob3N0aW5nLlN0dWJieVRhc2tSdW5uZXJQYXlsb2FkLlN0dWJieUNoYW5uZWw="))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class StubbyTaskRunnerPayload_RpcOptions(ProtocolBuffer.ProtocolMessage):


  TCP          =    0
  UDP          =    1

  _RPCProtocol_NAMES = {
    0: "TCP",
    1: "UDP",
  }

  def RPCProtocol_Name(cls, x): return cls._RPCProtocol_NAMES.get(x, "")
  RPCProtocol_Name = classmethod(RPCProtocol_Name)



  UNCOMPRESSED =    0
  ZIPPY_COMPRESSED =    1

  _Format_NAMES = {
    0: "UNCOMPRESSED",
    1: "ZIPPY_COMPRESSED",
  }

  def Format_Name(cls, x): return cls._Format_NAMES.get(x, "")
  Format_Name = classmethod(Format_Name)

  has_deadline_ = 0
  deadline_ = 0.0
  has_fail_fast_ = 0
  fail_fast_ = 0
  has_duplicate_suppression_ = 0
  duplicate_suppression_ = 0
  has_scheduling_hash_ = 0
  scheduling_hash_ = 0
  has_protocol_ = 0
  protocol_ = 0
  has_response_format_ = 0
  response_format_ = 0
  has_request_format_ = 0
  request_format_ = 0

  def __init__(self, contents=None):
    if contents is not None: self.MergeFromString(contents)

  def deadline(self): return self.deadline_

  def set_deadline(self, x):
    self.has_deadline_ = 1
    self.deadline_ = x

  def clear_deadline(self):
    if self.has_deadline_:
      self.has_deadline_ = 0
      self.deadline_ = 0.0

  def has_deadline(self): return self.has_deadline_

  def fail_fast(self): return self.fail_fast_

  def set_fail_fast(self, x):
    self.has_fail_fast_ = 1
    self.fail_fast_ = x

  def clear_fail_fast(self):
    if self.has_fail_fast_:
      self.has_fail_fast_ = 0
      self.fail_fast_ = 0

  def has_fail_fast(self): return self.has_fail_fast_

  def duplicate_suppression(self): return self.duplicate_suppression_

  def set_duplicate_suppression(self, x):
    self.has_duplicate_suppression_ = 1
    self.duplicate_suppression_ = x

  def clear_duplicate_suppression(self):
    if self.has_duplicate_suppression_:
      self.has_duplicate_suppression_ = 0
      self.duplicate_suppression_ = 0

  def has_duplicate_suppression(self): return self.has_duplicate_suppression_

  def scheduling_hash(self): return self.scheduling_hash_

  def set_scheduling_hash(self, x):
    self.has_scheduling_hash_ = 1
    self.scheduling_hash_ = x

  def clear_scheduling_hash(self):
    if self.has_scheduling_hash_:
      self.has_scheduling_hash_ = 0
      self.scheduling_hash_ = 0

  def has_scheduling_hash(self): return self.has_scheduling_hash_

  def protocol(self): return self.protocol_

  def set_protocol(self, x):
    self.has_protocol_ = 1
    self.protocol_ = x

  def clear_protocol(self):
    if self.has_protocol_:
      self.has_protocol_ = 0
      self.protocol_ = 0

  def has_protocol(self): return self.has_protocol_

  def response_format(self): return self.response_format_

  def set_response_format(self, x):
    self.has_response_format_ = 1
    self.response_format_ = x

  def clear_response_format(self):
    if self.has_response_format_:
      self.has_response_format_ = 0
      self.response_format_ = 0

  def has_response_format(self): return self.has_response_format_

  def request_format(self): return self.request_format_

  def set_request_format(self, x):
    self.has_request_format_ = 1
    self.request_format_ = x

  def clear_request_format(self):
    if self.has_request_format_:
      self.has_request_format_ = 0
      self.request_format_ = 0

  def has_request_format(self): return self.has_request_format_


  def MergeFrom(self, x):
    assert x is not self
    if (x.has_deadline()): self.set_deadline(x.deadline())
    if (x.has_fail_fast()): self.set_fail_fast(x.fail_fast())
    if (x.has_duplicate_suppression()): self.set_duplicate_suppression(x.duplicate_suppression())
    if (x.has_scheduling_hash()): self.set_scheduling_hash(x.scheduling_hash())
    if (x.has_protocol()): self.set_protocol(x.protocol())
    if (x.has_response_format()): self.set_response_format(x.response_format())
    if (x.has_request_format()): self.set_request_format(x.request_format())

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.StubbyTaskRunnerPayload_RpcOptions', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.StubbyTaskRunnerPayload_RpcOptions')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.StubbyTaskRunnerPayload_RpcOptions')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.StubbyTaskRunnerPayload_RpcOptions', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.StubbyTaskRunnerPayload_RpcOptions', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.StubbyTaskRunnerPayload_RpcOptions', s)


  def Equals(self, x):
    if x is self: return 1
    if self.has_deadline_ != x.has_deadline_: return 0
    if self.has_deadline_ and self.deadline_ != x.deadline_: return 0
    if self.has_fail_fast_ != x.has_fail_fast_: return 0
    if self.has_fail_fast_ and self.fail_fast_ != x.fail_fast_: return 0
    if self.has_duplicate_suppression_ != x.has_duplicate_suppression_: return 0
    if self.has_duplicate_suppression_ and self.duplicate_suppression_ != x.duplicate_suppression_: return 0
    if self.has_scheduling_hash_ != x.has_scheduling_hash_: return 0
    if self.has_scheduling_hash_ and self.scheduling_hash_ != x.scheduling_hash_: return 0
    if self.has_protocol_ != x.has_protocol_: return 0
    if self.has_protocol_ and self.protocol_ != x.protocol_: return 0
    if self.has_response_format_ != x.has_response_format_: return 0
    if self.has_response_format_ and self.response_format_ != x.response_format_: return 0
    if self.has_request_format_ != x.has_request_format_: return 0
    if self.has_request_format_ and self.request_format_ != x.request_format_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    return initialized

  def ByteSize(self):
    n = 0
    if (self.has_deadline_): n += 9
    if (self.has_fail_fast_): n += 2
    if (self.has_duplicate_suppression_): n += 2
    if (self.has_scheduling_hash_): n += 1 + self.lengthVarInt64(self.scheduling_hash_)
    if (self.has_protocol_): n += 1 + self.lengthVarInt64(self.protocol_)
    if (self.has_response_format_): n += 1 + self.lengthVarInt64(self.response_format_)
    if (self.has_request_format_): n += 1 + self.lengthVarInt64(self.request_format_)
    return n

  def ByteSizePartial(self):
    n = 0
    if (self.has_deadline_): n += 9
    if (self.has_fail_fast_): n += 2
    if (self.has_duplicate_suppression_): n += 2
    if (self.has_scheduling_hash_): n += 1 + self.lengthVarInt64(self.scheduling_hash_)
    if (self.has_protocol_): n += 1 + self.lengthVarInt64(self.protocol_)
    if (self.has_response_format_): n += 1 + self.lengthVarInt64(self.response_format_)
    if (self.has_request_format_): n += 1 + self.lengthVarInt64(self.request_format_)
    return n

  def Clear(self):
    self.clear_deadline()
    self.clear_fail_fast()
    self.clear_duplicate_suppression()
    self.clear_scheduling_hash()
    self.clear_protocol()
    self.clear_response_format()
    self.clear_request_format()

  def OutputUnchecked(self, out):
    if (self.has_deadline_):
      out.putVarInt32(9)
      out.putDouble(self.deadline_)
    if (self.has_fail_fast_):
      out.putVarInt32(16)
      out.putBoolean(self.fail_fast_)
    if (self.has_duplicate_suppression_):
      out.putVarInt32(24)
      out.putBoolean(self.duplicate_suppression_)
    if (self.has_scheduling_hash_):
      out.putVarInt32(32)
      out.putVarUint64(self.scheduling_hash_)
    if (self.has_protocol_):
      out.putVarInt32(40)
      out.putVarInt32(self.protocol_)
    if (self.has_response_format_):
      out.putVarInt32(48)
      out.putVarInt32(self.response_format_)
    if (self.has_request_format_):
      out.putVarInt32(56)
      out.putVarInt32(self.request_format_)

  def OutputPartial(self, out):
    if (self.has_deadline_):
      out.putVarInt32(9)
      out.putDouble(self.deadline_)
    if (self.has_fail_fast_):
      out.putVarInt32(16)
      out.putBoolean(self.fail_fast_)
    if (self.has_duplicate_suppression_):
      out.putVarInt32(24)
      out.putBoolean(self.duplicate_suppression_)
    if (self.has_scheduling_hash_):
      out.putVarInt32(32)
      out.putVarUint64(self.scheduling_hash_)
    if (self.has_protocol_):
      out.putVarInt32(40)
      out.putVarInt32(self.protocol_)
    if (self.has_response_format_):
      out.putVarInt32(48)
      out.putVarInt32(self.response_format_)
    if (self.has_request_format_):
      out.putVarInt32(56)
      out.putVarInt32(self.request_format_)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 9:
        self.set_deadline(d.getDouble())
        continue
      if tt == 16:
        self.set_fail_fast(d.getBoolean())
        continue
      if tt == 24:
        self.set_duplicate_suppression(d.getBoolean())
        continue
      if tt == 32:
        self.set_scheduling_hash(d.getVarUint64())
        continue
      if tt == 40:
        self.set_protocol(d.getVarInt32())
        continue
      if tt == 48:
        self.set_response_format(d.getVarInt32())
        continue
      if tt == 56:
        self.set_request_format(d.getVarInt32())
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    if self.has_deadline_: res+=prefix+("deadline: %s\n" % self.DebugFormat(self.deadline_))
    if self.has_fail_fast_: res+=prefix+("fail_fast: %s\n" % self.DebugFormatBool(self.fail_fast_))
    if self.has_duplicate_suppression_: res+=prefix+("duplicate_suppression: %s\n" % self.DebugFormatBool(self.duplicate_suppression_))
    if self.has_scheduling_hash_: res+=prefix+("scheduling_hash: %s\n" % self.DebugFormatInt64(self.scheduling_hash_))
    if self.has_protocol_: res+=prefix+("protocol: %s\n" % self.DebugFormatInt32(self.protocol_))
    if self.has_response_format_: res+=prefix+("response_format: %s\n" % self.DebugFormatInt32(self.response_format_))
    if self.has_request_format_: res+=prefix+("request_format: %s\n" % self.DebugFormatInt32(self.request_format_))
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  kdeadline = 1
  kfail_fast = 2
  kduplicate_suppression = 3
  kscheduling_hash = 4
  kprotocol = 5
  kresponse_format = 6
  krequest_format = 7

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "deadline",
    2: "fail_fast",
    3: "duplicate_suppression",
    4: "scheduling_hash",
    5: "protocol",
    6: "response_format",
    7: "request_format",
  }, 7)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.DOUBLE,
    2: ProtocolBuffer.Encoder.NUMERIC,
    3: ProtocolBuffer.Encoder.NUMERIC,
    4: ProtocolBuffer.Encoder.NUMERIC,
    5: ProtocolBuffer.Encoder.NUMERIC,
    6: ProtocolBuffer.Encoder.NUMERIC,
    7: ProtocolBuffer.Encoder.NUMERIC,
  }, 7, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("Wh5hcHBob3N0aW5nL2V4ZWN1dG9yL3Rhc2sucHJvdG8KLWFwcGhvc3RpbmcuU3R1YmJ5VGFza1J1bm5lclBheWxvYWRfUnBjT3B0aW9ucxMaCGRlYWRsaW5lIAEoATABOAEUExoJZmFpbF9mYXN0IAIoADAIOAEUExoVZHVwbGljYXRlX3N1cHByZXNzaW9uIAMoADAIOAEUExoPc2NoZWR1bGluZ19oYXNoIAQoADAEOAEUExoIcHJvdG9jb2wgBSgAMAU4AWgAFBMaD3Jlc3BvbnNlX2Zvcm1hdCAGKAAwBTgBaAEUExoOcmVxdWVzdF9mb3JtYXQgBygAMAU4AWgBFHN6C1JQQ1Byb3RvY29siwGSAQNUQ1CYAQCMAYsBkgEDVURQmAEBjAF0c3oGRm9ybWF0iwGSAQxVTkNPTVBSRVNTRUSYAQCMAYsBkgEQWklQUFlfQ09NUFJFU1NFRJgBAYwBdMIBEmFwcGhvc3RpbmcuVGFza1JlZsoBLWFwcGhvc3RpbmcuU3R1YmJ5VGFza1J1bm5lclBheWxvYWQuUnBjT3B0aW9ucw=="))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class StubbyTaskRunnerPayload(ProtocolBuffer.ProtocolMessage):


  MESSAGE_TYPE_ID =   12

  _TypeId_NAMES = {
    12: "MESSAGE_TYPE_ID",
  }

  def TypeId_Name(cls, x): return cls._TypeId_NAMES.get(x, "")
  TypeId_Name = classmethod(TypeId_Name)

  has_channel_ = 0
  has_method_ = 0
  method_ = ""
  has_request_ = 0
  request_ = ""
  has_rpc_options_ = 0
  rpc_options_ = None
  has_request_task_definition_ = 0
  request_task_definition_ = 0

  def __init__(self, contents=None):
    self.channel_ = StubbyTaskRunnerPayload_StubbyChannel()
    self.lazy_init_lock_ = thread.allocate_lock()
    if contents is not None: self.MergeFromString(contents)

  def channel(self): return self.channel_

  def mutable_channel(self): self.has_channel_ = 1; return self.channel_

  def clear_channel(self):self.has_channel_ = 0; self.channel_.Clear()

  def has_channel(self): return self.has_channel_

  def method(self): return self.method_

  def set_method(self, x):
    self.has_method_ = 1
    self.method_ = x

  def clear_method(self):
    if self.has_method_:
      self.has_method_ = 0
      self.method_ = ""

  def has_method(self): return self.has_method_

  def request(self): return self.request_

  def set_request(self, x):
    self.has_request_ = 1
    self.request_ = x

  def clear_request(self):
    if self.has_request_:
      self.has_request_ = 0
      self.request_ = ""

  def has_request(self): return self.has_request_

  def rpc_options(self):
    if self.rpc_options_ is None:
      self.lazy_init_lock_.acquire()
      try:
        if self.rpc_options_ is None: self.rpc_options_ = StubbyTaskRunnerPayload_RpcOptions()
      finally:
        self.lazy_init_lock_.release()
    return self.rpc_options_

  def mutable_rpc_options(self): self.has_rpc_options_ = 1; return self.rpc_options()

  def clear_rpc_options(self):

    if self.has_rpc_options_:
      self.has_rpc_options_ = 0;
      if self.rpc_options_ is not None: self.rpc_options_.Clear()

  def has_rpc_options(self): return self.has_rpc_options_

  def request_task_definition(self): return self.request_task_definition_

  def set_request_task_definition(self, x):
    self.has_request_task_definition_ = 1
    self.request_task_definition_ = x

  def clear_request_task_definition(self):
    if self.has_request_task_definition_:
      self.has_request_task_definition_ = 0
      self.request_task_definition_ = 0

  def has_request_task_definition(self): return self.has_request_task_definition_


  def MergeFrom(self, x):
    assert x is not self
    if (x.has_channel()): self.mutable_channel().MergeFrom(x.channel())
    if (x.has_method()): self.set_method(x.method())
    if (x.has_request()): self.set_request(x.request())
    if (x.has_rpc_options()): self.mutable_rpc_options().MergeFrom(x.rpc_options())
    if (x.has_request_task_definition()): self.set_request_task_definition(x.request_task_definition())

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.StubbyTaskRunnerPayload', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.StubbyTaskRunnerPayload')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.StubbyTaskRunnerPayload')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.StubbyTaskRunnerPayload', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.StubbyTaskRunnerPayload', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.StubbyTaskRunnerPayload', s)


  def Equals(self, x):
    if x is self: return 1
    if self.has_channel_ != x.has_channel_: return 0
    if self.has_channel_ and self.channel_ != x.channel_: return 0
    if self.has_method_ != x.has_method_: return 0
    if self.has_method_ and self.method_ != x.method_: return 0
    if self.has_request_ != x.has_request_: return 0
    if self.has_request_ and self.request_ != x.request_: return 0
    if self.has_rpc_options_ != x.has_rpc_options_: return 0
    if self.has_rpc_options_ and self.rpc_options_ != x.rpc_options_: return 0
    if self.has_request_task_definition_ != x.has_request_task_definition_: return 0
    if self.has_request_task_definition_ and self.request_task_definition_ != x.request_task_definition_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    if (not self.has_channel_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: channel not set.')
    elif not self.channel_.IsInitialized(debug_strs): initialized = 0
    if (not self.has_method_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: method not set.')
    if (not self.has_request_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: request not set.')
    if (self.has_rpc_options_ and not self.rpc_options_.IsInitialized(debug_strs)): initialized = 0
    return initialized

  def ByteSize(self):
    n = 0
    n += self.lengthString(self.channel_.ByteSize())
    n += self.lengthString(len(self.method_))
    n += self.lengthString(len(self.request_))
    if (self.has_rpc_options_): n += 1 + self.lengthString(self.rpc_options_.ByteSize())
    if (self.has_request_task_definition_): n += 2
    return n + 3

  def ByteSizePartial(self):
    n = 0
    if (self.has_channel_):
      n += 1
      n += self.lengthString(self.channel_.ByteSizePartial())
    if (self.has_method_):
      n += 1
      n += self.lengthString(len(self.method_))
    if (self.has_request_):
      n += 1
      n += self.lengthString(len(self.request_))
    if (self.has_rpc_options_): n += 1 + self.lengthString(self.rpc_options_.ByteSizePartial())
    if (self.has_request_task_definition_): n += 2
    return n

  def Clear(self):
    self.clear_channel()
    self.clear_method()
    self.clear_request()
    self.clear_rpc_options()
    self.clear_request_task_definition()

  def OutputUnchecked(self, out):
    out.putVarInt32(10)
    out.putVarInt32(self.channel_.ByteSize())
    self.channel_.OutputUnchecked(out)
    out.putVarInt32(18)
    out.putPrefixedString(self.method_)
    out.putVarInt32(26)
    out.putPrefixedString(self.request_)
    if (self.has_rpc_options_):
      out.putVarInt32(34)
      out.putVarInt32(self.rpc_options_.ByteSize())
      self.rpc_options_.OutputUnchecked(out)
    if (self.has_request_task_definition_):
      out.putVarInt32(40)
      out.putBoolean(self.request_task_definition_)

  def OutputPartial(self, out):
    if (self.has_channel_):
      out.putVarInt32(10)
      out.putVarInt32(self.channel_.ByteSizePartial())
      self.channel_.OutputPartial(out)
    if (self.has_method_):
      out.putVarInt32(18)
      out.putPrefixedString(self.method_)
    if (self.has_request_):
      out.putVarInt32(26)
      out.putPrefixedString(self.request_)
    if (self.has_rpc_options_):
      out.putVarInt32(34)
      out.putVarInt32(self.rpc_options_.ByteSizePartial())
      self.rpc_options_.OutputPartial(out)
    if (self.has_request_task_definition_):
      out.putVarInt32(40)
      out.putBoolean(self.request_task_definition_)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 10:
        length = d.getVarInt32()
        tmp = ProtocolBuffer.Decoder(d.buffer(), d.pos(), d.pos() + length)
        d.skip(length)
        self.mutable_channel().TryMerge(tmp)
        continue
      if tt == 18:
        self.set_method(d.getPrefixedString())
        continue
      if tt == 26:
        self.set_request(d.getPrefixedString())
        continue
      if tt == 34:
        length = d.getVarInt32()
        tmp = ProtocolBuffer.Decoder(d.buffer(), d.pos(), d.pos() + length)
        d.skip(length)
        self.mutable_rpc_options().TryMerge(tmp)
        continue
      if tt == 40:
        self.set_request_task_definition(d.getBoolean())
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    if self.has_channel_:
      res+=prefix+"channel <\n"
      res+=self.channel_.__str__(prefix + "  ", printElemNumber)
      res+=prefix+">\n"
    if self.has_method_: res+=prefix+("method: %s\n" % self.DebugFormatString(self.method_))
    if self.has_request_: res+=prefix+("request: %s\n" % self.DebugFormatString(self.request_))
    if self.has_rpc_options_:
      res+=prefix+"rpc_options <\n"
      res+=self.rpc_options_.__str__(prefix + "  ", printElemNumber)
      res+=prefix+">\n"
    if self.has_request_task_definition_: res+=prefix+("request_task_definition: %s\n" % self.DebugFormatBool(self.request_task_definition_))
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  kchannel = 1
  kmethod = 2
  krequest = 3
  krpc_options = 4
  krequest_task_definition = 5

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "channel",
    2: "method",
    3: "request",
    4: "rpc_options",
    5: "request_task_definition",
  }, 5)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.STRING,
    2: ProtocolBuffer.Encoder.STRING,
    3: ProtocolBuffer.Encoder.STRING,
    4: ProtocolBuffer.Encoder.STRING,
    5: ProtocolBuffer.Encoder.NUMERIC,
  }, 5, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("Wh5hcHBob3N0aW5nL2V4ZWN1dG9yL3Rhc2sucHJvdG8KImFwcGhvc3RpbmcuU3R1YmJ5VGFza1J1bm5lclBheWxvYWQTGgdjaGFubmVsIAEoAjALOAJKMGFwcGhvc3RpbmcuU3R1YmJ5VGFza1J1bm5lclBheWxvYWRfU3R1YmJ5Q2hhbm5lbBQTGgZtZXRob2QgAigCMAk4AhQTGgdyZXF1ZXN0IAMoAjAJOAKjAaoBBWN0eXBlsgEEQ29yZKQBFBMaC3JwY19vcHRpb25zIAQoAjALOAFKLWFwcGhvc3RpbmcuU3R1YmJ5VGFza1J1bm5lclBheWxvYWRfUnBjT3B0aW9ucxQTGhdyZXF1ZXN0X3Rhc2tfZGVmaW5pdGlvbiAFKAAwCDgBQgVmYWxzZaMBqgEHZGVmYXVsdLIBBWZhbHNlpAEUc3oGVHlwZUlkiwGSAQ9NRVNTQUdFX1RZUEVfSUSYAQyMAXTCARJhcHBob3N0aW5nLlRhc2tSZWY="))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class StubbyTaskRunnerInfo(ProtocolBuffer.ProtocolMessage):


  MESSAGE_TYPE_ID =  201

  _TypeId_NAMES = {
    201: "MESSAGE_TYPE_ID",
  }

  def TypeId_Name(cls, x): return cls._TypeId_NAMES.get(x, "")
  TypeId_Name = classmethod(TypeId_Name)

  has_status_ = 0
  status_ = 0
  has_application_error_ = 0
  application_error_ = 0
  has_error_message_ = 0
  error_message_ = ""

  def __init__(self, contents=None):
    if contents is not None: self.MergeFromString(contents)

  def status(self): return self.status_

  def set_status(self, x):
    self.has_status_ = 1
    self.status_ = x

  def clear_status(self):
    if self.has_status_:
      self.has_status_ = 0
      self.status_ = 0

  def has_status(self): return self.has_status_

  def application_error(self): return self.application_error_

  def set_application_error(self, x):
    self.has_application_error_ = 1
    self.application_error_ = x

  def clear_application_error(self):
    if self.has_application_error_:
      self.has_application_error_ = 0
      self.application_error_ = 0

  def has_application_error(self): return self.has_application_error_

  def error_message(self): return self.error_message_

  def set_error_message(self, x):
    self.has_error_message_ = 1
    self.error_message_ = x

  def clear_error_message(self):
    if self.has_error_message_:
      self.has_error_message_ = 0
      self.error_message_ = ""

  def has_error_message(self): return self.has_error_message_


  def MergeFrom(self, x):
    assert x is not self
    if (x.has_status()): self.set_status(x.status())
    if (x.has_application_error()): self.set_application_error(x.application_error())
    if (x.has_error_message()): self.set_error_message(x.error_message())

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.StubbyTaskRunnerInfo', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.StubbyTaskRunnerInfo')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.StubbyTaskRunnerInfo')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.StubbyTaskRunnerInfo', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.StubbyTaskRunnerInfo', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.StubbyTaskRunnerInfo', s)


  def Equals(self, x):
    if x is self: return 1
    if self.has_status_ != x.has_status_: return 0
    if self.has_status_ and self.status_ != x.status_: return 0
    if self.has_application_error_ != x.has_application_error_: return 0
    if self.has_application_error_ and self.application_error_ != x.application_error_: return 0
    if self.has_error_message_ != x.has_error_message_: return 0
    if self.has_error_message_ and self.error_message_ != x.error_message_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    if (not self.has_status_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: status not set.')
    return initialized

  def ByteSize(self):
    n = 0
    n += self.lengthVarInt64(self.status_)
    if (self.has_application_error_): n += 1 + self.lengthVarInt64(self.application_error_)
    if (self.has_error_message_): n += 1 + self.lengthString(len(self.error_message_))
    return n + 1

  def ByteSizePartial(self):
    n = 0
    if (self.has_status_):
      n += 1
      n += self.lengthVarInt64(self.status_)
    if (self.has_application_error_): n += 1 + self.lengthVarInt64(self.application_error_)
    if (self.has_error_message_): n += 1 + self.lengthString(len(self.error_message_))
    return n

  def Clear(self):
    self.clear_status()
    self.clear_application_error()
    self.clear_error_message()

  def OutputUnchecked(self, out):
    out.putVarInt32(8)
    out.putVarInt64(self.status_)
    if (self.has_application_error_):
      out.putVarInt32(16)
      out.putVarInt64(self.application_error_)
    if (self.has_error_message_):
      out.putVarInt32(26)
      out.putPrefixedString(self.error_message_)

  def OutputPartial(self, out):
    if (self.has_status_):
      out.putVarInt32(8)
      out.putVarInt64(self.status_)
    if (self.has_application_error_):
      out.putVarInt32(16)
      out.putVarInt64(self.application_error_)
    if (self.has_error_message_):
      out.putVarInt32(26)
      out.putPrefixedString(self.error_message_)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 8:
        self.set_status(d.getVarInt64())
        continue
      if tt == 16:
        self.set_application_error(d.getVarInt64())
        continue
      if tt == 26:
        self.set_error_message(d.getPrefixedString())
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    if self.has_status_: res+=prefix+("status: %s\n" % self.DebugFormatInt64(self.status_))
    if self.has_application_error_: res+=prefix+("application_error: %s\n" % self.DebugFormatInt64(self.application_error_))
    if self.has_error_message_: res+=prefix+("error_message: %s\n" % self.DebugFormatString(self.error_message_))
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  kstatus = 1
  kapplication_error = 2
  kerror_message = 3

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "status",
    2: "application_error",
    3: "error_message",
  }, 3)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.NUMERIC,
    2: ProtocolBuffer.Encoder.NUMERIC,
    3: ProtocolBuffer.Encoder.STRING,
  }, 3, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("Wh5hcHBob3N0aW5nL2V4ZWN1dG9yL3Rhc2sucHJvdG8KH2FwcGhvc3RpbmcuU3R1YmJ5VGFza1J1bm5lckluZm8TGgZzdGF0dXMgASgAMAM4AhQTGhFhcHBsaWNhdGlvbl9lcnJvciACKAAwAzgBFBMaDWVycm9yX21lc3NhZ2UgAygCMAk4ARRzegZUeXBlSWSLAZIBD01FU1NBR0VfVFlQRV9JRJgByQGMAXTCARJhcHBob3N0aW5nLlRhc2tSZWY="))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class PullTaskPayload(ProtocolBuffer.ProtocolMessage):


  MESSAGE_TYPE_ID =   13

  _TypeId_NAMES = {
    13: "MESSAGE_TYPE_ID",
  }

  def TypeId_Name(cls, x): return cls._TypeId_NAMES.get(x, "")
  TypeId_Name = classmethod(TypeId_Name)

  has_content_ = 0
  content_ = ""

  def __init__(self, contents=None):
    if contents is not None: self.MergeFromString(contents)

  def content(self): return self.content_

  def set_content(self, x):
    self.has_content_ = 1
    self.content_ = x

  def clear_content(self):
    if self.has_content_:
      self.has_content_ = 0
      self.content_ = ""

  def has_content(self): return self.has_content_


  def MergeFrom(self, x):
    assert x is not self
    if (x.has_content()): self.set_content(x.content())

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.PullTaskPayload', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.PullTaskPayload')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.PullTaskPayload')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.PullTaskPayload', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.PullTaskPayload', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.PullTaskPayload', s)


  def Equals(self, x):
    if x is self: return 1
    if self.has_content_ != x.has_content_: return 0
    if self.has_content_ and self.content_ != x.content_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    if (not self.has_content_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: content not set.')
    return initialized

  def ByteSize(self):
    n = 0
    n += self.lengthString(len(self.content_))
    return n + 1

  def ByteSizePartial(self):
    n = 0
    if (self.has_content_):
      n += 1
      n += self.lengthString(len(self.content_))
    return n

  def Clear(self):
    self.clear_content()

  def OutputUnchecked(self, out):
    out.putVarInt32(10)
    out.putPrefixedString(self.content_)

  def OutputPartial(self, out):
    if (self.has_content_):
      out.putVarInt32(10)
      out.putPrefixedString(self.content_)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 10:
        self.set_content(d.getPrefixedString())
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    if self.has_content_: res+=prefix+("content: %s\n" % self.DebugFormatString(self.content_))
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  kcontent = 1

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "content",
  }, 1)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.STRING,
  }, 1, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("Wh5hcHBob3N0aW5nL2V4ZWN1dG9yL3Rhc2sucHJvdG8KGmFwcGhvc3RpbmcuUHVsbFRhc2tQYXlsb2FkExoHY29udGVudCABKAIwCTgCowGqAQVjdHlwZbIBBENvcmSkARRzegZUeXBlSWSLAZIBD01FU1NBR0VfVFlQRV9JRJgBDYwBdMIBEmFwcGhvc3RpbmcuVGFza1JlZg=="))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class TaskDefinition(ProtocolBuffer.ProtocolMessage):
  has_task_ref_ = 0
  has_eta_usec_ = 0
  eta_usec_ = 0
  has_payload_ = 0
  has_retry_count_ = 0
  retry_count_ = 0
  has_store_timestamp_ = 0
  store_timestamp_ = 0
  has_last_invocation_stats_ = 0
  last_invocation_stats_ = None
  has_description_ = 0
  description_ = ""
  has_retry_parameters_ = 0
  retry_parameters_ = None
  has_first_try_usec_ = 0
  first_try_usec_ = 0

  def __init__(self, contents=None):
    self.task_ref_ = TaskRef()
    self.payload_ = MessageSet()
    self.lazy_init_lock_ = thread.allocate_lock()
    if contents is not None: self.MergeFromString(contents)

  def task_ref(self): return self.task_ref_

  def mutable_task_ref(self): self.has_task_ref_ = 1; return self.task_ref_

  def clear_task_ref(self):self.has_task_ref_ = 0; self.task_ref_.Clear()

  def has_task_ref(self): return self.has_task_ref_

  def eta_usec(self): return self.eta_usec_

  def set_eta_usec(self, x):
    self.has_eta_usec_ = 1
    self.eta_usec_ = x

  def clear_eta_usec(self):
    if self.has_eta_usec_:
      self.has_eta_usec_ = 0
      self.eta_usec_ = 0

  def has_eta_usec(self): return self.has_eta_usec_

  def payload(self): return self.payload_

  def mutable_payload(self): self.has_payload_ = 1; return self.payload_

  def clear_payload(self):self.has_payload_ = 0; self.payload_.Clear()

  def has_payload(self): return self.has_payload_

  def retry_count(self): return self.retry_count_

  def set_retry_count(self, x):
    self.has_retry_count_ = 1
    self.retry_count_ = x

  def clear_retry_count(self):
    if self.has_retry_count_:
      self.has_retry_count_ = 0
      self.retry_count_ = 0

  def has_retry_count(self): return self.has_retry_count_

  def store_timestamp(self): return self.store_timestamp_

  def set_store_timestamp(self, x):
    self.has_store_timestamp_ = 1
    self.store_timestamp_ = x

  def clear_store_timestamp(self):
    if self.has_store_timestamp_:
      self.has_store_timestamp_ = 0
      self.store_timestamp_ = 0

  def has_store_timestamp(self): return self.has_store_timestamp_

  def last_invocation_stats(self):
    if self.last_invocation_stats_ is None:
      self.lazy_init_lock_.acquire()
      try:
        if self.last_invocation_stats_ is None: self.last_invocation_stats_ = TaskRunnerStats()
      finally:
        self.lazy_init_lock_.release()
    return self.last_invocation_stats_

  def mutable_last_invocation_stats(self): self.has_last_invocation_stats_ = 1; return self.last_invocation_stats()

  def clear_last_invocation_stats(self):

    if self.has_last_invocation_stats_:
      self.has_last_invocation_stats_ = 0;
      if self.last_invocation_stats_ is not None: self.last_invocation_stats_.Clear()

  def has_last_invocation_stats(self): return self.has_last_invocation_stats_

  def description(self): return self.description_

  def set_description(self, x):
    self.has_description_ = 1
    self.description_ = x

  def clear_description(self):
    if self.has_description_:
      self.has_description_ = 0
      self.description_ = ""

  def has_description(self): return self.has_description_

  def retry_parameters(self):
    if self.retry_parameters_ is None:
      self.lazy_init_lock_.acquire()
      try:
        if self.retry_parameters_ is None: self.retry_parameters_ = google.appengine.executor.retry_pb.RetryParameters()
      finally:
        self.lazy_init_lock_.release()
    return self.retry_parameters_

  def mutable_retry_parameters(self): self.has_retry_parameters_ = 1; return self.retry_parameters()

  def clear_retry_parameters(self):

    if self.has_retry_parameters_:
      self.has_retry_parameters_ = 0;
      if self.retry_parameters_ is not None: self.retry_parameters_.Clear()

  def has_retry_parameters(self): return self.has_retry_parameters_

  def first_try_usec(self): return self.first_try_usec_

  def set_first_try_usec(self, x):
    self.has_first_try_usec_ = 1
    self.first_try_usec_ = x

  def clear_first_try_usec(self):
    if self.has_first_try_usec_:
      self.has_first_try_usec_ = 0
      self.first_try_usec_ = 0

  def has_first_try_usec(self): return self.has_first_try_usec_


  def MergeFrom(self, x):
    assert x is not self
    if (x.has_task_ref()): self.mutable_task_ref().MergeFrom(x.task_ref())
    if (x.has_eta_usec()): self.set_eta_usec(x.eta_usec())
    if (x.has_payload()): self.mutable_payload().MergeFrom(x.payload())
    if (x.has_retry_count()): self.set_retry_count(x.retry_count())
    if (x.has_store_timestamp()): self.set_store_timestamp(x.store_timestamp())
    if (x.has_last_invocation_stats()): self.mutable_last_invocation_stats().MergeFrom(x.last_invocation_stats())
    if (x.has_description()): self.set_description(x.description())
    if (x.has_retry_parameters()): self.mutable_retry_parameters().MergeFrom(x.retry_parameters())
    if (x.has_first_try_usec()): self.set_first_try_usec(x.first_try_usec())

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.TaskDefinition', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.TaskDefinition')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.TaskDefinition')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.TaskDefinition', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.TaskDefinition', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.TaskDefinition', s)


  def Equals(self, x):
    if x is self: return 1
    if self.has_task_ref_ != x.has_task_ref_: return 0
    if self.has_task_ref_ and self.task_ref_ != x.task_ref_: return 0
    if self.has_eta_usec_ != x.has_eta_usec_: return 0
    if self.has_eta_usec_ and self.eta_usec_ != x.eta_usec_: return 0
    if self.has_payload_ != x.has_payload_: return 0
    if self.has_payload_ and self.payload_ != x.payload_: return 0
    if self.has_retry_count_ != x.has_retry_count_: return 0
    if self.has_retry_count_ and self.retry_count_ != x.retry_count_: return 0
    if self.has_store_timestamp_ != x.has_store_timestamp_: return 0
    if self.has_store_timestamp_ and self.store_timestamp_ != x.store_timestamp_: return 0
    if self.has_last_invocation_stats_ != x.has_last_invocation_stats_: return 0
    if self.has_last_invocation_stats_ and self.last_invocation_stats_ != x.last_invocation_stats_: return 0
    if self.has_description_ != x.has_description_: return 0
    if self.has_description_ and self.description_ != x.description_: return 0
    if self.has_retry_parameters_ != x.has_retry_parameters_: return 0
    if self.has_retry_parameters_ and self.retry_parameters_ != x.retry_parameters_: return 0
    if self.has_first_try_usec_ != x.has_first_try_usec_: return 0
    if self.has_first_try_usec_ and self.first_try_usec_ != x.first_try_usec_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    if (not self.has_task_ref_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: task_ref not set.')
    elif not self.task_ref_.IsInitialized(debug_strs): initialized = 0
    if (not self.has_eta_usec_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: eta_usec not set.')
    if (not self.has_payload_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: payload not set.')
    elif not self.payload_.IsInitialized(debug_strs): initialized = 0
    if (self.has_last_invocation_stats_ and not self.last_invocation_stats_.IsInitialized(debug_strs)): initialized = 0
    if (self.has_retry_parameters_ and not self.retry_parameters_.IsInitialized(debug_strs)): initialized = 0
    return initialized

  def ByteSize(self):
    n = 0
    n += self.lengthString(self.task_ref_.ByteSize())
    n += self.lengthVarInt64(self.eta_usec_)
    n += self.lengthString(self.payload_.ByteSize())
    if (self.has_retry_count_): n += 1 + self.lengthVarInt64(self.retry_count_)
    if (self.has_store_timestamp_): n += 1 + self.lengthVarInt64(self.store_timestamp_)
    if (self.has_last_invocation_stats_): n += 1 + self.lengthString(self.last_invocation_stats_.ByteSize())
    if (self.has_description_): n += 1 + self.lengthString(len(self.description_))
    if (self.has_retry_parameters_): n += 1 + self.lengthString(self.retry_parameters_.ByteSize())
    if (self.has_first_try_usec_): n += 1 + self.lengthVarInt64(self.first_try_usec_)
    return n + 3

  def ByteSizePartial(self):
    n = 0
    if (self.has_task_ref_):
      n += 1
      n += self.lengthString(self.task_ref_.ByteSizePartial())
    if (self.has_eta_usec_):
      n += 1
      n += self.lengthVarInt64(self.eta_usec_)
    if (self.has_payload_):
      n += 1
      n += self.lengthString(self.payload_.ByteSizePartial())
    if (self.has_retry_count_): n += 1 + self.lengthVarInt64(self.retry_count_)
    if (self.has_store_timestamp_): n += 1 + self.lengthVarInt64(self.store_timestamp_)
    if (self.has_last_invocation_stats_): n += 1 + self.lengthString(self.last_invocation_stats_.ByteSizePartial())
    if (self.has_description_): n += 1 + self.lengthString(len(self.description_))
    if (self.has_retry_parameters_): n += 1 + self.lengthString(self.retry_parameters_.ByteSizePartial())
    if (self.has_first_try_usec_): n += 1 + self.lengthVarInt64(self.first_try_usec_)
    return n

  def Clear(self):
    self.clear_task_ref()
    self.clear_eta_usec()
    self.clear_payload()
    self.clear_retry_count()
    self.clear_store_timestamp()
    self.clear_last_invocation_stats()
    self.clear_description()
    self.clear_retry_parameters()
    self.clear_first_try_usec()

  def OutputUnchecked(self, out):
    out.putVarInt32(10)
    out.putVarInt32(self.task_ref_.ByteSize())
    self.task_ref_.OutputUnchecked(out)
    out.putVarInt32(16)
    out.putVarInt64(self.eta_usec_)
    out.putVarInt32(26)
    out.putVarInt32(self.payload_.ByteSize())
    self.payload_.OutputUnchecked(out)
    if (self.has_retry_count_):
      out.putVarInt32(32)
      out.putVarInt64(self.retry_count_)
    if (self.has_store_timestamp_):
      out.putVarInt32(40)
      out.putVarInt64(self.store_timestamp_)
    if (self.has_last_invocation_stats_):
      out.putVarInt32(50)
      out.putVarInt32(self.last_invocation_stats_.ByteSize())
      self.last_invocation_stats_.OutputUnchecked(out)
    if (self.has_description_):
      out.putVarInt32(58)
      out.putPrefixedString(self.description_)
    if (self.has_retry_parameters_):
      out.putVarInt32(66)
      out.putVarInt32(self.retry_parameters_.ByteSize())
      self.retry_parameters_.OutputUnchecked(out)
    if (self.has_first_try_usec_):
      out.putVarInt32(72)
      out.putVarInt64(self.first_try_usec_)

  def OutputPartial(self, out):
    if (self.has_task_ref_):
      out.putVarInt32(10)
      out.putVarInt32(self.task_ref_.ByteSizePartial())
      self.task_ref_.OutputPartial(out)
    if (self.has_eta_usec_):
      out.putVarInt32(16)
      out.putVarInt64(self.eta_usec_)
    if (self.has_payload_):
      out.putVarInt32(26)
      out.putVarInt32(self.payload_.ByteSizePartial())
      self.payload_.OutputPartial(out)
    if (self.has_retry_count_):
      out.putVarInt32(32)
      out.putVarInt64(self.retry_count_)
    if (self.has_store_timestamp_):
      out.putVarInt32(40)
      out.putVarInt64(self.store_timestamp_)
    if (self.has_last_invocation_stats_):
      out.putVarInt32(50)
      out.putVarInt32(self.last_invocation_stats_.ByteSizePartial())
      self.last_invocation_stats_.OutputPartial(out)
    if (self.has_description_):
      out.putVarInt32(58)
      out.putPrefixedString(self.description_)
    if (self.has_retry_parameters_):
      out.putVarInt32(66)
      out.putVarInt32(self.retry_parameters_.ByteSizePartial())
      self.retry_parameters_.OutputPartial(out)
    if (self.has_first_try_usec_):
      out.putVarInt32(72)
      out.putVarInt64(self.first_try_usec_)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 10:
        length = d.getVarInt32()
        tmp = ProtocolBuffer.Decoder(d.buffer(), d.pos(), d.pos() + length)
        d.skip(length)
        self.mutable_task_ref().TryMerge(tmp)
        continue
      if tt == 16:
        self.set_eta_usec(d.getVarInt64())
        continue
      if tt == 26:
        length = d.getVarInt32()
        tmp = ProtocolBuffer.Decoder(d.buffer(), d.pos(), d.pos() + length)
        d.skip(length)
        self.mutable_payload().TryMerge(tmp)
        continue
      if tt == 32:
        self.set_retry_count(d.getVarInt64())
        continue
      if tt == 40:
        self.set_store_timestamp(d.getVarInt64())
        continue
      if tt == 50:
        length = d.getVarInt32()
        tmp = ProtocolBuffer.Decoder(d.buffer(), d.pos(), d.pos() + length)
        d.skip(length)
        self.mutable_last_invocation_stats().TryMerge(tmp)
        continue
      if tt == 58:
        self.set_description(d.getPrefixedString())
        continue
      if tt == 66:
        length = d.getVarInt32()
        tmp = ProtocolBuffer.Decoder(d.buffer(), d.pos(), d.pos() + length)
        d.skip(length)
        self.mutable_retry_parameters().TryMerge(tmp)
        continue
      if tt == 72:
        self.set_first_try_usec(d.getVarInt64())
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    if self.has_task_ref_:
      res+=prefix+"task_ref <\n"
      res+=self.task_ref_.__str__(prefix + "  ", printElemNumber)
      res+=prefix+">\n"
    if self.has_eta_usec_: res+=prefix+("eta_usec: %s\n" % self.DebugFormatInt64(self.eta_usec_))
    if self.has_payload_:
      res+=prefix+"payload <\n"
      res+=self.payload_.__str__(prefix + "  ", printElemNumber)
      res+=prefix+">\n"
    if self.has_retry_count_: res+=prefix+("retry_count: %s\n" % self.DebugFormatInt64(self.retry_count_))
    if self.has_store_timestamp_: res+=prefix+("store_timestamp: %s\n" % self.DebugFormatInt64(self.store_timestamp_))
    if self.has_last_invocation_stats_:
      res+=prefix+"last_invocation_stats <\n"
      res+=self.last_invocation_stats_.__str__(prefix + "  ", printElemNumber)
      res+=prefix+">\n"
    if self.has_description_: res+=prefix+("description: %s\n" % self.DebugFormatString(self.description_))
    if self.has_retry_parameters_:
      res+=prefix+"retry_parameters <\n"
      res+=self.retry_parameters_.__str__(prefix + "  ", printElemNumber)
      res+=prefix+">\n"
    if self.has_first_try_usec_: res+=prefix+("first_try_usec: %s\n" % self.DebugFormatInt64(self.first_try_usec_))
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  ktask_ref = 1
  keta_usec = 2
  kpayload = 3
  kretry_count = 4
  kstore_timestamp = 5
  klast_invocation_stats = 6
  kdescription = 7
  kretry_parameters = 8
  kfirst_try_usec = 9

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "task_ref",
    2: "eta_usec",
    3: "payload",
    4: "retry_count",
    5: "store_timestamp",
    6: "last_invocation_stats",
    7: "description",
    8: "retry_parameters",
    9: "first_try_usec",
  }, 9)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.STRING,
    2: ProtocolBuffer.Encoder.NUMERIC,
    3: ProtocolBuffer.Encoder.STRING,
    4: ProtocolBuffer.Encoder.NUMERIC,
    5: ProtocolBuffer.Encoder.NUMERIC,
    6: ProtocolBuffer.Encoder.STRING,
    7: ProtocolBuffer.Encoder.STRING,
    8: ProtocolBuffer.Encoder.STRING,
    9: ProtocolBuffer.Encoder.NUMERIC,
  }, 9, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("Wh5hcHBob3N0aW5nL2V4ZWN1dG9yL3Rhc2sucHJvdG8KGWFwcGhvc3RpbmcuVGFza0RlZmluaXRpb24TGgh0YXNrX3JlZiABKAIwCzgCShJhcHBob3N0aW5nLlRhc2tSZWYUExoIZXRhX3VzZWMgAigAMAM4AhQTGgdwYXlsb2FkIAMoAjALOAJKCk1lc3NhZ2VTZXQUExoLcmV0cnlfY291bnQgBCgAMAM4AUIBMKMBqgEHZGVmYXVsdLIBATCkARQTGg9zdG9yZV90aW1lc3RhbXAgBSgAMAM4ARQTGhVsYXN0X2ludm9jYXRpb25fc3RhdHMgBigCMAs4AUoaYXBwaG9zdGluZy5UYXNrUnVubmVyU3RhdHMUExoLZGVzY3JpcHRpb24gBygCMAk4ARQTGhByZXRyeV9wYXJhbWV0ZXJzIAgoAjALOAFKGmFwcGhvc3RpbmcuUmV0cnlQYXJhbWV0ZXJzFBMaDmZpcnN0X3RyeV91c2VjIAkoADADOAEUwgESYXBwaG9zdGluZy5UYXNrUmVm"))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class TaskGoldenVersion(ProtocolBuffer.ProtocolMessage):
  has_store_timestamp_ = 0
  store_timestamp_ = 0

  def __init__(self, contents=None):
    if contents is not None: self.MergeFromString(contents)

  def store_timestamp(self): return self.store_timestamp_

  def set_store_timestamp(self, x):
    self.has_store_timestamp_ = 1
    self.store_timestamp_ = x

  def clear_store_timestamp(self):
    if self.has_store_timestamp_:
      self.has_store_timestamp_ = 0
      self.store_timestamp_ = 0

  def has_store_timestamp(self): return self.has_store_timestamp_


  def MergeFrom(self, x):
    assert x is not self
    if (x.has_store_timestamp()): self.set_store_timestamp(x.store_timestamp())

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.TaskGoldenVersion', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.TaskGoldenVersion')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.TaskGoldenVersion')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.TaskGoldenVersion', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.TaskGoldenVersion', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.TaskGoldenVersion', s)


  def Equals(self, x):
    if x is self: return 1
    if self.has_store_timestamp_ != x.has_store_timestamp_: return 0
    if self.has_store_timestamp_ and self.store_timestamp_ != x.store_timestamp_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    if (not self.has_store_timestamp_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: store_timestamp not set.')
    return initialized

  def ByteSize(self):
    n = 0
    n += self.lengthVarInt64(self.store_timestamp_)
    return n + 1

  def ByteSizePartial(self):
    n = 0
    if (self.has_store_timestamp_):
      n += 1
      n += self.lengthVarInt64(self.store_timestamp_)
    return n

  def Clear(self):
    self.clear_store_timestamp()

  def OutputUnchecked(self, out):
    out.putVarInt32(8)
    out.putVarInt64(self.store_timestamp_)

  def OutputPartial(self, out):
    if (self.has_store_timestamp_):
      out.putVarInt32(8)
      out.putVarInt64(self.store_timestamp_)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 8:
        self.set_store_timestamp(d.getVarInt64())
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    if self.has_store_timestamp_: res+=prefix+("store_timestamp: %s\n" % self.DebugFormatInt64(self.store_timestamp_))
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  kstore_timestamp = 1

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "store_timestamp",
  }, 1)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.NUMERIC,
  }, 1, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("Wh5hcHBob3N0aW5nL2V4ZWN1dG9yL3Rhc2sucHJvdG8KHGFwcGhvc3RpbmcuVGFza0dvbGRlblZlcnNpb24TGg9zdG9yZV90aW1lc3RhbXAgASgAMAM4AhTCARJhcHBob3N0aW5nLlRhc2tSZWY="))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())


__all__ = ['TaskRef','TaskEtaIndexRef','TaskEtaBorder','TaskRangeByEta','TaskRangeByName','HttpTaskRunnerInfo','TaskRunnerStats','HttpTaskRunnerPayload','HttpTaskRunnerPayload_Header','CronTaskRunnerPayload','StubbyTaskRunnerPayload_StubbyChannel','StubbyTaskRunnerPayload_RpcOptions','StubbyTaskRunnerPayload','StubbyTaskRunnerInfo','PullTaskPayload','TaskDefinition','TaskGoldenVersion']
