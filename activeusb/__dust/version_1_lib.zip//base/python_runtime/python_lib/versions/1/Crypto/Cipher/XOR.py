from _Crypto_Cipher__XOR import *
