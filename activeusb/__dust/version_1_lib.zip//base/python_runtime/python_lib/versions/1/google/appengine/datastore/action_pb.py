#!/usr/bin/env python
#
# Copyright 2007 Google Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#



from google.net.proto import ProtocolBuffer
import array
import base64
import dummy_thread as thread
try:
  from google3.net.proto import _net_proto___parse__python
except ImportError:
  _net_proto___parse__python = None

__pychecker__ = """maxreturns=0 maxbranches=0 no-callinit
                   unusednames=printElemNumber,debug_strs no-special"""

from google.appengine.executor.task_pb import *
import google.appengine.executor.task_pb
class Action(ProtocolBuffer.ProtocolMessage):
  has_task_ = 0
  task_ = None

  def __init__(self, contents=None):
    self.lazy_init_lock_ = thread.allocate_lock()
    if contents is not None: self.MergeFromString(contents)

  def task(self):
    if self.task_ is None:
      self.lazy_init_lock_.acquire()
      try:
        if self.task_ is None: self.task_ = google.appengine.executor.task_pb.TaskDefinition()
      finally:
        self.lazy_init_lock_.release()
    return self.task_

  def mutable_task(self): self.has_task_ = 1; return self.task()

  def clear_task(self):

    if self.has_task_:
      self.has_task_ = 0;
      if self.task_ is not None: self.task_.Clear()

  def has_task(self): return self.has_task_


  def MergeFrom(self, x):
    assert x is not self
    if (x.has_task()): self.mutable_task().MergeFrom(x.task())

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'storage_onestore_v3.Action', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'storage_onestore_v3.Action')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'storage_onestore_v3.Action')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'storage_onestore_v3.Action', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'storage_onestore_v3.Action', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'storage_onestore_v3.Action', s)


  def Equals(self, x):
    if x is self: return 1
    if self.has_task_ != x.has_task_: return 0
    if self.has_task_ and self.task_ != x.task_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    if (self.has_task_ and not self.task_.IsInitialized(debug_strs)): initialized = 0
    return initialized

  def ByteSize(self):
    n = 0
    if (self.has_task_): n += 1 + self.lengthString(self.task_.ByteSize())
    return n

  def ByteSizePartial(self):
    n = 0
    if (self.has_task_): n += 1 + self.lengthString(self.task_.ByteSizePartial())
    return n

  def Clear(self):
    self.clear_task()

  def OutputUnchecked(self, out):
    if (self.has_task_):
      out.putVarInt32(10)
      out.putVarInt32(self.task_.ByteSize())
      self.task_.OutputUnchecked(out)

  def OutputPartial(self, out):
    if (self.has_task_):
      out.putVarInt32(10)
      out.putVarInt32(self.task_.ByteSizePartial())
      self.task_.OutputPartial(out)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 10:
        length = d.getVarInt32()
        tmp = ProtocolBuffer.Decoder(d.buffer(), d.pos(), d.pos() + length)
        d.skip(length)
        self.mutable_task().TryMerge(tmp)
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    if self.has_task_:
      res+=prefix+"task <\n"
      res+=self.task_.__str__(prefix + "  ", printElemNumber)
      res+=prefix+">\n"
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  ktask = 1

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "task",
  }, 1)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.STRING,
  }, 1, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("WiBzdG9yYWdlL29uZXN0b3JlL3YzL2FjdGlvbi5wcm90bwoac3RvcmFnZV9vbmVzdG9yZV92My5BY3Rpb24TGgR0YXNrIAEoAjALOAFKGWFwcGhvc3RpbmcuVGFza0RlZmluaXRpb24UugHDAQogc3RvcmFnZS9vbmVzdG9yZS92My9hY3Rpb24ucHJvdG8SE3N0b3JhZ2Vfb25lc3RvcmVfdjMaHmFwcGhvc3RpbmcvZXhlY3V0b3IvdGFzay5wcm90byIyCgZBY3Rpb24SKAoEdGFzaxgBIAEoCzIaLmFwcGhvc3RpbmcuVGFza0RlZmluaXRpb25CNgoeY29tLmdvb2dsZS5zdG9yYWdlLm9uZXN0b3JlLnYzEAEgASgBQg5PbmVzdG9yZUFjdGlvbg=="))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())


__all__ = ['Action']
