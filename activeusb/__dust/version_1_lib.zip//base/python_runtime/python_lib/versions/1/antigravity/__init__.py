"""Antigravity 0.0."""

import random

SCRIPT = """\
<title>Python</title>
<h1>Python</h1>
<p><i>Guy 1 is talking to Guy 2, who is floating in the sky.</i>
<p>Guy 1: You're flying! How?
<br>Guy 2: Python!
<p>Guy 2: I learned it last night! Everything is so simple!
<br>Guy 2: Hello world is just <code>print "Hello, World!"</code>
<p>Guy 1: I dunno... Dynamic typing? <i>Whitespace?</i>
<br>Guy 2: Come join us! Programming is fun again!
It's a whole new world up here!
<br>Guy 1: But how are you flying?
<p>Guy 2: I just typed <code>import antigravity</code>
<br>Guy 1: That's it?
<br>Guy 2: ...I also sampled everything in the medicine cabinet for comparison.
<br>Guy 2: But I think this is the Python.
<p><a href="http://xkcd.com/353/">"I wrote 20 short programs in Python
yesterday. It was wonderful. Perl, I'm leaving you."</a>
"""

def fly():
  if random.random() < 0.1:
     print "Status: 302"
     print "Location: http://www.google.com/url?sa=D&q=http://xkcd.com/353/"
  else:
     print "Content-type: text/html"
     print
     print SCRIPT
