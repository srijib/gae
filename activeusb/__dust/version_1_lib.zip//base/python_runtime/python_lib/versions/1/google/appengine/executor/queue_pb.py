#!/usr/bin/env python
#
# Copyright 2007 Google Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#



from google.net.proto import ProtocolBuffer
import array
import base64
import dummy_thread as thread
try:
  from google3.net.proto import _net_proto___parse__python
except ImportError:
  _net_proto___parse__python = None

__pychecker__ = """maxreturns=0 maxbranches=0 no-callinit
                   unusednames=printElemNumber,debug_strs no-special"""

from google.appengine.executor.group_pb import *
import google.appengine.executor.group_pb
from google.appengine.executor.retry_pb import *
import google.appengine.executor.retry_pb
from google.net.proto.message_set import MessageSet
class QueueRef(ProtocolBuffer.ProtocolMessage):
  has_group_ref_ = 0
  has_name_ = 0
  name_ = ""

  def __init__(self, contents=None):
    self.group_ref_ = google.appengine.executor.group_pb.GroupRef()
    if contents is not None: self.MergeFromString(contents)

  def group_ref(self): return self.group_ref_

  def mutable_group_ref(self): self.has_group_ref_ = 1; return self.group_ref_

  def clear_group_ref(self):self.has_group_ref_ = 0; self.group_ref_.Clear()

  def has_group_ref(self): return self.has_group_ref_

  def name(self): return self.name_

  def set_name(self, x):
    self.has_name_ = 1
    self.name_ = x

  def clear_name(self):
    if self.has_name_:
      self.has_name_ = 0
      self.name_ = ""

  def has_name(self): return self.has_name_


  def MergeFrom(self, x):
    assert x is not self
    if (x.has_group_ref()): self.mutable_group_ref().MergeFrom(x.group_ref())
    if (x.has_name()): self.set_name(x.name())

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.QueueRef', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.QueueRef')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.QueueRef')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.QueueRef', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.QueueRef', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.QueueRef', s)


  def Equals(self, x):
    if x is self: return 1
    if self.has_group_ref_ != x.has_group_ref_: return 0
    if self.has_group_ref_ and self.group_ref_ != x.group_ref_: return 0
    if self.has_name_ != x.has_name_: return 0
    if self.has_name_ and self.name_ != x.name_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    if (not self.has_group_ref_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: group_ref not set.')
    elif not self.group_ref_.IsInitialized(debug_strs): initialized = 0
    if (not self.has_name_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: name not set.')
    return initialized

  def ByteSize(self):
    n = 0
    n += self.lengthString(self.group_ref_.ByteSize())
    n += self.lengthString(len(self.name_))
    return n + 2

  def ByteSizePartial(self):
    n = 0
    if (self.has_group_ref_):
      n += 1
      n += self.lengthString(self.group_ref_.ByteSizePartial())
    if (self.has_name_):
      n += 1
      n += self.lengthString(len(self.name_))
    return n

  def Clear(self):
    self.clear_group_ref()
    self.clear_name()

  def OutputUnchecked(self, out):
    out.putVarInt32(10)
    out.putVarInt32(self.group_ref_.ByteSize())
    self.group_ref_.OutputUnchecked(out)
    out.putVarInt32(18)
    out.putPrefixedString(self.name_)

  def OutputPartial(self, out):
    if (self.has_group_ref_):
      out.putVarInt32(10)
      out.putVarInt32(self.group_ref_.ByteSizePartial())
      self.group_ref_.OutputPartial(out)
    if (self.has_name_):
      out.putVarInt32(18)
      out.putPrefixedString(self.name_)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 10:
        length = d.getVarInt32()
        tmp = ProtocolBuffer.Decoder(d.buffer(), d.pos(), d.pos() + length)
        d.skip(length)
        self.mutable_group_ref().TryMerge(tmp)
        continue
      if tt == 18:
        self.set_name(d.getPrefixedString())
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    if self.has_group_ref_:
      res+=prefix+"group_ref <\n"
      res+=self.group_ref_.__str__(prefix + "  ", printElemNumber)
      res+=prefix+">\n"
    if self.has_name_: res+=prefix+("name: %s\n" % self.DebugFormatString(self.name_))
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  kgroup_ref = 1
  kname = 2

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "group_ref",
    2: "name",
  }, 2)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.STRING,
    2: ProtocolBuffer.Encoder.STRING,
  }, 2, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("Wh9hcHBob3N0aW5nL2V4ZWN1dG9yL3F1ZXVlLnByb3RvChNhcHBob3N0aW5nLlF1ZXVlUmVmExoJZ3JvdXBfcmVmIAEoAjALOAJKE2FwcGhvc3RpbmcuR3JvdXBSZWYUExoEbmFtZSACKAIwCTgCFLoB/wkKH2FwcGhvc3RpbmcvZXhlY3V0b3IvcXVldWUucHJvdG8SCmFwcGhvc3RpbmcaH2FwcGhvc3RpbmcvZXhlY3V0b3IvZ3JvdXAucHJvdG8aH2FwcGhvc3RpbmcvZXhlY3V0b3IvcmV0cnkucHJvdG8aKW5ldC9wcm90bzIvYnJpZGdlL3Byb3RvL21lc3NhZ2Vfc2V0LnByb3RvIkEKCFF1ZXVlUmVmEicKCWdyb3VwX3JlZhgBIAIoCzIULmFwcGhvc3RpbmcuR3JvdXBSZWYSDAoEbmFtZRgCIAIoDCJCChBRdWV1ZVJhbmdlQm9yZGVyEhAKCGN1c3RvbWVyGAEgAigMEg0KBWdyb3VwGAIgASgMEg0KBXF1ZXVlGAMgASgMImYKClF1ZXVlUmFuZ2USKwoFc3RhcnQYASACKAsyHC5hcHBob3N0aW5nLlF1ZXVlUmFuZ2VCb3JkZXISKwoFbGltaXQYAiACKAsyHC5hcHBob3N0aW5nLlF1ZXVlUmFuZ2VCb3JkZXIidwoZUXVldWVUaHJvdHRsaW5nUGFyYW1ldGVycxIgChhidWNrZXRfcmVmaWxsX3Blcl9zZWNvbmQYASACKAESFwoPYnVja2V0X2NhcGFjaXR5GAIgAigBEh8KF21heF9jb25jdXJyZW50X3JlcXVlc3RzGAMgASgFIjIKFEh0dHBUYXNrUnVubmVySGVhZGVyEgsKA2tleRgBIAIoDBINCgV2YWx1ZRgCIAIoDCKCBAoPUXVldWVEZWZpbml0aW9uEicKCXF1ZXVlX3JlZhgBIAIoCzIULmFwcGhvc3RpbmcuUXVldWVSZWYSRAoVdGhyb3R0bGluZ19wYXJhbWV0ZXJzGAIgAigLMiUuYXBwaG9zdGluZy5RdWV1ZVRocm90dGxpbmdQYXJhbWV0ZXJzEhsKE3VzZXJfc3BlY2lmaWVkX3JhdGUYAyABKAkSGgoPbGFzdF9wdXJnZV91c2VjGAQgASgDOgEwEhUKBnBhdXNlZBgFIAEoCDoFZmFsc2USNQoQcmV0cnlfcGFyYW1ldGVycxgGIAEoCzIbLmFwcGhvc3RpbmcuUmV0cnlQYXJhbWV0ZXJzEjkKBG1vZGUYByABKA4yJS5hcHBob3N0aW5nLlF1ZXVlRGVmaW5pdGlvbi5RdWV1ZU1vZGU6BFBVU0gSKwoIbWV0YWRhdGEYCCABKAsyGS5wcm90bzIuYnJpZGdlLk1lc3NhZ2VTZXQSOQoPaGVhZGVyX292ZXJyaWRlGAkgAygLMiAuYXBwaG9zdGluZy5IdHRwVGFza1J1bm5lckhlYWRlchIPCgNhY2wYCiABKAxCAggBEiQKDGNyZWF0b3JfbmFtZRgLIAEoCToKYXBwaG9zdGluZ0ICCAEiHwoJUXVldWVNb2RlEggKBFBVU0gQABIICgRQVUxMEAEimQEKCFF1ZXVlTWFwEikKBXJhbmdlGAEgAygKMhouYXBwaG9zdGluZy5RdWV1ZU1hcC5SYW5nZRIWCg50aW1lc3RhbXBfdXNlYxgEIAIoAxpKCgVSYW5nZRIrCgtxdWV1ZV9yYW5nZRgCIAIoCzIWLmFwcGhvc3RpbmcuUXVldWVSYW5nZRIUCgxzY2FubmVyX3Rhc2sYAyACKAxCJgoeY29tLmdvb2dsZS5hcHBob3N0aW5nLmV4ZWN1dG9yEAEgASgB"))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class QueueRangeBorder(ProtocolBuffer.ProtocolMessage):
  has_customer_ = 0
  customer_ = ""
  has_group_ = 0
  group_ = ""
  has_queue_ = 0
  queue_ = ""

  def __init__(self, contents=None):
    if contents is not None: self.MergeFromString(contents)

  def customer(self): return self.customer_

  def set_customer(self, x):
    self.has_customer_ = 1
    self.customer_ = x

  def clear_customer(self):
    if self.has_customer_:
      self.has_customer_ = 0
      self.customer_ = ""

  def has_customer(self): return self.has_customer_

  def group(self): return self.group_

  def set_group(self, x):
    self.has_group_ = 1
    self.group_ = x

  def clear_group(self):
    if self.has_group_:
      self.has_group_ = 0
      self.group_ = ""

  def has_group(self): return self.has_group_

  def queue(self): return self.queue_

  def set_queue(self, x):
    self.has_queue_ = 1
    self.queue_ = x

  def clear_queue(self):
    if self.has_queue_:
      self.has_queue_ = 0
      self.queue_ = ""

  def has_queue(self): return self.has_queue_


  def MergeFrom(self, x):
    assert x is not self
    if (x.has_customer()): self.set_customer(x.customer())
    if (x.has_group()): self.set_group(x.group())
    if (x.has_queue()): self.set_queue(x.queue())

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.QueueRangeBorder', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.QueueRangeBorder')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.QueueRangeBorder')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.QueueRangeBorder', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.QueueRangeBorder', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.QueueRangeBorder', s)


  def Equals(self, x):
    if x is self: return 1
    if self.has_customer_ != x.has_customer_: return 0
    if self.has_customer_ and self.customer_ != x.customer_: return 0
    if self.has_group_ != x.has_group_: return 0
    if self.has_group_ and self.group_ != x.group_: return 0
    if self.has_queue_ != x.has_queue_: return 0
    if self.has_queue_ and self.queue_ != x.queue_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    if (not self.has_customer_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: customer not set.')
    return initialized

  def ByteSize(self):
    n = 0
    n += self.lengthString(len(self.customer_))
    if (self.has_group_): n += 1 + self.lengthString(len(self.group_))
    if (self.has_queue_): n += 1 + self.lengthString(len(self.queue_))
    return n + 1

  def ByteSizePartial(self):
    n = 0
    if (self.has_customer_):
      n += 1
      n += self.lengthString(len(self.customer_))
    if (self.has_group_): n += 1 + self.lengthString(len(self.group_))
    if (self.has_queue_): n += 1 + self.lengthString(len(self.queue_))
    return n

  def Clear(self):
    self.clear_customer()
    self.clear_group()
    self.clear_queue()

  def OutputUnchecked(self, out):
    out.putVarInt32(10)
    out.putPrefixedString(self.customer_)
    if (self.has_group_):
      out.putVarInt32(18)
      out.putPrefixedString(self.group_)
    if (self.has_queue_):
      out.putVarInt32(26)
      out.putPrefixedString(self.queue_)

  def OutputPartial(self, out):
    if (self.has_customer_):
      out.putVarInt32(10)
      out.putPrefixedString(self.customer_)
    if (self.has_group_):
      out.putVarInt32(18)
      out.putPrefixedString(self.group_)
    if (self.has_queue_):
      out.putVarInt32(26)
      out.putPrefixedString(self.queue_)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 10:
        self.set_customer(d.getPrefixedString())
        continue
      if tt == 18:
        self.set_group(d.getPrefixedString())
        continue
      if tt == 26:
        self.set_queue(d.getPrefixedString())
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    if self.has_customer_: res+=prefix+("customer: %s\n" % self.DebugFormatString(self.customer_))
    if self.has_group_: res+=prefix+("group: %s\n" % self.DebugFormatString(self.group_))
    if self.has_queue_: res+=prefix+("queue: %s\n" % self.DebugFormatString(self.queue_))
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  kcustomer = 1
  kgroup = 2
  kqueue = 3

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "customer",
    2: "group",
    3: "queue",
  }, 3)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.STRING,
    2: ProtocolBuffer.Encoder.STRING,
    3: ProtocolBuffer.Encoder.STRING,
  }, 3, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("Wh9hcHBob3N0aW5nL2V4ZWN1dG9yL3F1ZXVlLnByb3RvChthcHBob3N0aW5nLlF1ZXVlUmFuZ2VCb3JkZXITGghjdXN0b21lciABKAIwCTgCFBMaBWdyb3VwIAIoAjAJOAEUExoFcXVldWUgAygCMAk4ARTCARNhcHBob3N0aW5nLlF1ZXVlUmVm"))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class QueueRange(ProtocolBuffer.ProtocolMessage):
  has_start_ = 0
  has_limit_ = 0

  def __init__(self, contents=None):
    self.start_ = QueueRangeBorder()
    self.limit_ = QueueRangeBorder()
    if contents is not None: self.MergeFromString(contents)

  def start(self): return self.start_

  def mutable_start(self): self.has_start_ = 1; return self.start_

  def clear_start(self):self.has_start_ = 0; self.start_.Clear()

  def has_start(self): return self.has_start_

  def limit(self): return self.limit_

  def mutable_limit(self): self.has_limit_ = 1; return self.limit_

  def clear_limit(self):self.has_limit_ = 0; self.limit_.Clear()

  def has_limit(self): return self.has_limit_


  def MergeFrom(self, x):
    assert x is not self
    if (x.has_start()): self.mutable_start().MergeFrom(x.start())
    if (x.has_limit()): self.mutable_limit().MergeFrom(x.limit())

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.QueueRange', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.QueueRange')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.QueueRange')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.QueueRange', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.QueueRange', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.QueueRange', s)


  def Equals(self, x):
    if x is self: return 1
    if self.has_start_ != x.has_start_: return 0
    if self.has_start_ and self.start_ != x.start_: return 0
    if self.has_limit_ != x.has_limit_: return 0
    if self.has_limit_ and self.limit_ != x.limit_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    if (not self.has_start_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: start not set.')
    elif not self.start_.IsInitialized(debug_strs): initialized = 0
    if (not self.has_limit_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: limit not set.')
    elif not self.limit_.IsInitialized(debug_strs): initialized = 0
    return initialized

  def ByteSize(self):
    n = 0
    n += self.lengthString(self.start_.ByteSize())
    n += self.lengthString(self.limit_.ByteSize())
    return n + 2

  def ByteSizePartial(self):
    n = 0
    if (self.has_start_):
      n += 1
      n += self.lengthString(self.start_.ByteSizePartial())
    if (self.has_limit_):
      n += 1
      n += self.lengthString(self.limit_.ByteSizePartial())
    return n

  def Clear(self):
    self.clear_start()
    self.clear_limit()

  def OutputUnchecked(self, out):
    out.putVarInt32(10)
    out.putVarInt32(self.start_.ByteSize())
    self.start_.OutputUnchecked(out)
    out.putVarInt32(18)
    out.putVarInt32(self.limit_.ByteSize())
    self.limit_.OutputUnchecked(out)

  def OutputPartial(self, out):
    if (self.has_start_):
      out.putVarInt32(10)
      out.putVarInt32(self.start_.ByteSizePartial())
      self.start_.OutputPartial(out)
    if (self.has_limit_):
      out.putVarInt32(18)
      out.putVarInt32(self.limit_.ByteSizePartial())
      self.limit_.OutputPartial(out)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 10:
        length = d.getVarInt32()
        tmp = ProtocolBuffer.Decoder(d.buffer(), d.pos(), d.pos() + length)
        d.skip(length)
        self.mutable_start().TryMerge(tmp)
        continue
      if tt == 18:
        length = d.getVarInt32()
        tmp = ProtocolBuffer.Decoder(d.buffer(), d.pos(), d.pos() + length)
        d.skip(length)
        self.mutable_limit().TryMerge(tmp)
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    if self.has_start_:
      res+=prefix+"start <\n"
      res+=self.start_.__str__(prefix + "  ", printElemNumber)
      res+=prefix+">\n"
    if self.has_limit_:
      res+=prefix+"limit <\n"
      res+=self.limit_.__str__(prefix + "  ", printElemNumber)
      res+=prefix+">\n"
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  kstart = 1
  klimit = 2

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "start",
    2: "limit",
  }, 2)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.STRING,
    2: ProtocolBuffer.Encoder.STRING,
  }, 2, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("Wh9hcHBob3N0aW5nL2V4ZWN1dG9yL3F1ZXVlLnByb3RvChVhcHBob3N0aW5nLlF1ZXVlUmFuZ2UTGgVzdGFydCABKAIwCzgCShthcHBob3N0aW5nLlF1ZXVlUmFuZ2VCb3JkZXIUExoFbGltaXQgAigCMAs4AkobYXBwaG9zdGluZy5RdWV1ZVJhbmdlQm9yZGVyFMIBE2FwcGhvc3RpbmcuUXVldWVSZWY="))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class QueueThrottlingParameters(ProtocolBuffer.ProtocolMessage):
  has_bucket_refill_per_second_ = 0
  bucket_refill_per_second_ = 0.0
  has_bucket_capacity_ = 0
  bucket_capacity_ = 0.0
  has_max_concurrent_requests_ = 0
  max_concurrent_requests_ = 0

  def __init__(self, contents=None):
    if contents is not None: self.MergeFromString(contents)

  def bucket_refill_per_second(self): return self.bucket_refill_per_second_

  def set_bucket_refill_per_second(self, x):
    self.has_bucket_refill_per_second_ = 1
    self.bucket_refill_per_second_ = x

  def clear_bucket_refill_per_second(self):
    if self.has_bucket_refill_per_second_:
      self.has_bucket_refill_per_second_ = 0
      self.bucket_refill_per_second_ = 0.0

  def has_bucket_refill_per_second(self): return self.has_bucket_refill_per_second_

  def bucket_capacity(self): return self.bucket_capacity_

  def set_bucket_capacity(self, x):
    self.has_bucket_capacity_ = 1
    self.bucket_capacity_ = x

  def clear_bucket_capacity(self):
    if self.has_bucket_capacity_:
      self.has_bucket_capacity_ = 0
      self.bucket_capacity_ = 0.0

  def has_bucket_capacity(self): return self.has_bucket_capacity_

  def max_concurrent_requests(self): return self.max_concurrent_requests_

  def set_max_concurrent_requests(self, x):
    self.has_max_concurrent_requests_ = 1
    self.max_concurrent_requests_ = x

  def clear_max_concurrent_requests(self):
    if self.has_max_concurrent_requests_:
      self.has_max_concurrent_requests_ = 0
      self.max_concurrent_requests_ = 0

  def has_max_concurrent_requests(self): return self.has_max_concurrent_requests_


  def MergeFrom(self, x):
    assert x is not self
    if (x.has_bucket_refill_per_second()): self.set_bucket_refill_per_second(x.bucket_refill_per_second())
    if (x.has_bucket_capacity()): self.set_bucket_capacity(x.bucket_capacity())
    if (x.has_max_concurrent_requests()): self.set_max_concurrent_requests(x.max_concurrent_requests())

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.QueueThrottlingParameters', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.QueueThrottlingParameters')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.QueueThrottlingParameters')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.QueueThrottlingParameters', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.QueueThrottlingParameters', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.QueueThrottlingParameters', s)


  def Equals(self, x):
    if x is self: return 1
    if self.has_bucket_refill_per_second_ != x.has_bucket_refill_per_second_: return 0
    if self.has_bucket_refill_per_second_ and self.bucket_refill_per_second_ != x.bucket_refill_per_second_: return 0
    if self.has_bucket_capacity_ != x.has_bucket_capacity_: return 0
    if self.has_bucket_capacity_ and self.bucket_capacity_ != x.bucket_capacity_: return 0
    if self.has_max_concurrent_requests_ != x.has_max_concurrent_requests_: return 0
    if self.has_max_concurrent_requests_ and self.max_concurrent_requests_ != x.max_concurrent_requests_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    if (not self.has_bucket_refill_per_second_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: bucket_refill_per_second not set.')
    if (not self.has_bucket_capacity_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: bucket_capacity not set.')
    return initialized

  def ByteSize(self):
    n = 0
    if (self.has_max_concurrent_requests_): n += 1 + self.lengthVarInt64(self.max_concurrent_requests_)
    return n + 18

  def ByteSizePartial(self):
    n = 0
    if (self.has_bucket_refill_per_second_):
      n += 9
    if (self.has_bucket_capacity_):
      n += 9
    if (self.has_max_concurrent_requests_): n += 1 + self.lengthVarInt64(self.max_concurrent_requests_)
    return n

  def Clear(self):
    self.clear_bucket_refill_per_second()
    self.clear_bucket_capacity()
    self.clear_max_concurrent_requests()

  def OutputUnchecked(self, out):
    out.putVarInt32(9)
    out.putDouble(self.bucket_refill_per_second_)
    out.putVarInt32(17)
    out.putDouble(self.bucket_capacity_)
    if (self.has_max_concurrent_requests_):
      out.putVarInt32(24)
      out.putVarInt32(self.max_concurrent_requests_)

  def OutputPartial(self, out):
    if (self.has_bucket_refill_per_second_):
      out.putVarInt32(9)
      out.putDouble(self.bucket_refill_per_second_)
    if (self.has_bucket_capacity_):
      out.putVarInt32(17)
      out.putDouble(self.bucket_capacity_)
    if (self.has_max_concurrent_requests_):
      out.putVarInt32(24)
      out.putVarInt32(self.max_concurrent_requests_)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 9:
        self.set_bucket_refill_per_second(d.getDouble())
        continue
      if tt == 17:
        self.set_bucket_capacity(d.getDouble())
        continue
      if tt == 24:
        self.set_max_concurrent_requests(d.getVarInt32())
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    if self.has_bucket_refill_per_second_: res+=prefix+("bucket_refill_per_second: %s\n" % self.DebugFormat(self.bucket_refill_per_second_))
    if self.has_bucket_capacity_: res+=prefix+("bucket_capacity: %s\n" % self.DebugFormat(self.bucket_capacity_))
    if self.has_max_concurrent_requests_: res+=prefix+("max_concurrent_requests: %s\n" % self.DebugFormatInt32(self.max_concurrent_requests_))
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  kbucket_refill_per_second = 1
  kbucket_capacity = 2
  kmax_concurrent_requests = 3

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "bucket_refill_per_second",
    2: "bucket_capacity",
    3: "max_concurrent_requests",
  }, 3)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.DOUBLE,
    2: ProtocolBuffer.Encoder.DOUBLE,
    3: ProtocolBuffer.Encoder.NUMERIC,
  }, 3, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("Wh9hcHBob3N0aW5nL2V4ZWN1dG9yL3F1ZXVlLnByb3RvCiRhcHBob3N0aW5nLlF1ZXVlVGhyb3R0bGluZ1BhcmFtZXRlcnMTGhhidWNrZXRfcmVmaWxsX3Blcl9zZWNvbmQgASgBMAE4AhQTGg9idWNrZXRfY2FwYWNpdHkgAigBMAE4AhQTGhdtYXhfY29uY3VycmVudF9yZXF1ZXN0cyADKAAwBTgBFMIBE2FwcGhvc3RpbmcuUXVldWVSZWY="))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class HttpTaskRunnerHeader(ProtocolBuffer.ProtocolMessage):
  has_key_ = 0
  key_ = ""
  has_value_ = 0
  value_ = ""

  def __init__(self, contents=None):
    if contents is not None: self.MergeFromString(contents)

  def key(self): return self.key_

  def set_key(self, x):
    self.has_key_ = 1
    self.key_ = x

  def clear_key(self):
    if self.has_key_:
      self.has_key_ = 0
      self.key_ = ""

  def has_key(self): return self.has_key_

  def value(self): return self.value_

  def set_value(self, x):
    self.has_value_ = 1
    self.value_ = x

  def clear_value(self):
    if self.has_value_:
      self.has_value_ = 0
      self.value_ = ""

  def has_value(self): return self.has_value_


  def MergeFrom(self, x):
    assert x is not self
    if (x.has_key()): self.set_key(x.key())
    if (x.has_value()): self.set_value(x.value())

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.HttpTaskRunnerHeader', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.HttpTaskRunnerHeader')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.HttpTaskRunnerHeader')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.HttpTaskRunnerHeader', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.HttpTaskRunnerHeader', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.HttpTaskRunnerHeader', s)


  def Equals(self, x):
    if x is self: return 1
    if self.has_key_ != x.has_key_: return 0
    if self.has_key_ and self.key_ != x.key_: return 0
    if self.has_value_ != x.has_value_: return 0
    if self.has_value_ and self.value_ != x.value_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    if (not self.has_key_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: key not set.')
    if (not self.has_value_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: value not set.')
    return initialized

  def ByteSize(self):
    n = 0
    n += self.lengthString(len(self.key_))
    n += self.lengthString(len(self.value_))
    return n + 2

  def ByteSizePartial(self):
    n = 0
    if (self.has_key_):
      n += 1
      n += self.lengthString(len(self.key_))
    if (self.has_value_):
      n += 1
      n += self.lengthString(len(self.value_))
    return n

  def Clear(self):
    self.clear_key()
    self.clear_value()

  def OutputUnchecked(self, out):
    out.putVarInt32(10)
    out.putPrefixedString(self.key_)
    out.putVarInt32(18)
    out.putPrefixedString(self.value_)

  def OutputPartial(self, out):
    if (self.has_key_):
      out.putVarInt32(10)
      out.putPrefixedString(self.key_)
    if (self.has_value_):
      out.putVarInt32(18)
      out.putPrefixedString(self.value_)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 10:
        self.set_key(d.getPrefixedString())
        continue
      if tt == 18:
        self.set_value(d.getPrefixedString())
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    if self.has_key_: res+=prefix+("key: %s\n" % self.DebugFormatString(self.key_))
    if self.has_value_: res+=prefix+("value: %s\n" % self.DebugFormatString(self.value_))
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  kkey = 1
  kvalue = 2

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "key",
    2: "value",
  }, 2)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.STRING,
    2: ProtocolBuffer.Encoder.STRING,
  }, 2, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("Wh9hcHBob3N0aW5nL2V4ZWN1dG9yL3F1ZXVlLnByb3RvCh9hcHBob3N0aW5nLkh0dHBUYXNrUnVubmVySGVhZGVyExoDa2V5IAEoAjAJOAIUExoFdmFsdWUgAigCMAk4AhTCARNhcHBob3N0aW5nLlF1ZXVlUmVm"))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class QueueDefinition(ProtocolBuffer.ProtocolMessage):


  PUSH         =    0
  PULL         =    1

  _QueueMode_NAMES = {
    0: "PUSH",
    1: "PULL",
  }

  def QueueMode_Name(cls, x): return cls._QueueMode_NAMES.get(x, "")
  QueueMode_Name = classmethod(QueueMode_Name)

  has_queue_ref_ = 0
  has_throttling_parameters_ = 0
  has_user_specified_rate_ = 0
  user_specified_rate_ = ""
  has_last_purge_usec_ = 0
  last_purge_usec_ = 0
  has_paused_ = 0
  paused_ = 0
  has_retry_parameters_ = 0
  retry_parameters_ = None
  has_mode_ = 0
  mode_ = 0
  has_metadata_ = 0
  metadata_ = None
  has_acl_ = 0
  acl_ = ""
  has_creator_name_ = 0
  creator_name_ = "apphosting"

  def __init__(self, contents=None):
    self.queue_ref_ = QueueRef()
    self.throttling_parameters_ = QueueThrottlingParameters()
    self.header_override_ = []
    self.lazy_init_lock_ = thread.allocate_lock()
    if contents is not None: self.MergeFromString(contents)

  def queue_ref(self): return self.queue_ref_

  def mutable_queue_ref(self): self.has_queue_ref_ = 1; return self.queue_ref_

  def clear_queue_ref(self):self.has_queue_ref_ = 0; self.queue_ref_.Clear()

  def has_queue_ref(self): return self.has_queue_ref_

  def throttling_parameters(self): return self.throttling_parameters_

  def mutable_throttling_parameters(self): self.has_throttling_parameters_ = 1; return self.throttling_parameters_

  def clear_throttling_parameters(self):self.has_throttling_parameters_ = 0; self.throttling_parameters_.Clear()

  def has_throttling_parameters(self): return self.has_throttling_parameters_

  def user_specified_rate(self): return self.user_specified_rate_

  def set_user_specified_rate(self, x):
    self.has_user_specified_rate_ = 1
    self.user_specified_rate_ = x

  def clear_user_specified_rate(self):
    if self.has_user_specified_rate_:
      self.has_user_specified_rate_ = 0
      self.user_specified_rate_ = ""

  def has_user_specified_rate(self): return self.has_user_specified_rate_

  def last_purge_usec(self): return self.last_purge_usec_

  def set_last_purge_usec(self, x):
    self.has_last_purge_usec_ = 1
    self.last_purge_usec_ = x

  def clear_last_purge_usec(self):
    if self.has_last_purge_usec_:
      self.has_last_purge_usec_ = 0
      self.last_purge_usec_ = 0

  def has_last_purge_usec(self): return self.has_last_purge_usec_

  def paused(self): return self.paused_

  def set_paused(self, x):
    self.has_paused_ = 1
    self.paused_ = x

  def clear_paused(self):
    if self.has_paused_:
      self.has_paused_ = 0
      self.paused_ = 0

  def has_paused(self): return self.has_paused_

  def retry_parameters(self):
    if self.retry_parameters_ is None:
      self.lazy_init_lock_.acquire()
      try:
        if self.retry_parameters_ is None: self.retry_parameters_ = google.appengine.executor.retry_pb.RetryParameters()
      finally:
        self.lazy_init_lock_.release()
    return self.retry_parameters_

  def mutable_retry_parameters(self): self.has_retry_parameters_ = 1; return self.retry_parameters()

  def clear_retry_parameters(self):

    if self.has_retry_parameters_:
      self.has_retry_parameters_ = 0;
      if self.retry_parameters_ is not None: self.retry_parameters_.Clear()

  def has_retry_parameters(self): return self.has_retry_parameters_

  def mode(self): return self.mode_

  def set_mode(self, x):
    self.has_mode_ = 1
    self.mode_ = x

  def clear_mode(self):
    if self.has_mode_:
      self.has_mode_ = 0
      self.mode_ = 0

  def has_mode(self): return self.has_mode_

  def metadata(self):
    if self.metadata_ is None:
      self.lazy_init_lock_.acquire()
      try:
        if self.metadata_ is None: self.metadata_ = MessageSet()
      finally:
        self.lazy_init_lock_.release()
    return self.metadata_

  def mutable_metadata(self): self.has_metadata_ = 1; return self.metadata()

  def clear_metadata(self):

    if self.has_metadata_:
      self.has_metadata_ = 0;
      if self.metadata_ is not None: self.metadata_.Clear()

  def has_metadata(self): return self.has_metadata_

  def header_override_size(self): return len(self.header_override_)
  def header_override_list(self): return self.header_override_

  def header_override(self, i):
    return self.header_override_[i]

  def mutable_header_override(self, i):
    return self.header_override_[i]

  def add_header_override(self):
    x = HttpTaskRunnerHeader()
    self.header_override_.append(x)
    return x

  def clear_header_override(self):
    self.header_override_ = []
  def acl(self): return self.acl_

  def set_acl(self, x):
    self.has_acl_ = 1
    self.acl_ = x

  def clear_acl(self):
    if self.has_acl_:
      self.has_acl_ = 0
      self.acl_ = ""

  def has_acl(self): return self.has_acl_

  def creator_name(self): return self.creator_name_

  def set_creator_name(self, x):
    self.has_creator_name_ = 1
    self.creator_name_ = x

  def clear_creator_name(self):
    if self.has_creator_name_:
      self.has_creator_name_ = 0
      self.creator_name_ = "apphosting"

  def has_creator_name(self): return self.has_creator_name_


  def MergeFrom(self, x):
    assert x is not self
    if (x.has_queue_ref()): self.mutable_queue_ref().MergeFrom(x.queue_ref())
    if (x.has_throttling_parameters()): self.mutable_throttling_parameters().MergeFrom(x.throttling_parameters())
    if (x.has_user_specified_rate()): self.set_user_specified_rate(x.user_specified_rate())
    if (x.has_last_purge_usec()): self.set_last_purge_usec(x.last_purge_usec())
    if (x.has_paused()): self.set_paused(x.paused())
    if (x.has_retry_parameters()): self.mutable_retry_parameters().MergeFrom(x.retry_parameters())
    if (x.has_mode()): self.set_mode(x.mode())
    if (x.has_metadata()): self.mutable_metadata().MergeFrom(x.metadata())
    for i in xrange(x.header_override_size()): self.add_header_override().CopyFrom(x.header_override(i))
    if (x.has_acl()): self.set_acl(x.acl())
    if (x.has_creator_name()): self.set_creator_name(x.creator_name())

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.QueueDefinition', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.QueueDefinition')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.QueueDefinition')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.QueueDefinition', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.QueueDefinition', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.QueueDefinition', s)


  def Equals(self, x):
    if x is self: return 1
    if self.has_queue_ref_ != x.has_queue_ref_: return 0
    if self.has_queue_ref_ and self.queue_ref_ != x.queue_ref_: return 0
    if self.has_throttling_parameters_ != x.has_throttling_parameters_: return 0
    if self.has_throttling_parameters_ and self.throttling_parameters_ != x.throttling_parameters_: return 0
    if self.has_user_specified_rate_ != x.has_user_specified_rate_: return 0
    if self.has_user_specified_rate_ and self.user_specified_rate_ != x.user_specified_rate_: return 0
    if self.has_last_purge_usec_ != x.has_last_purge_usec_: return 0
    if self.has_last_purge_usec_ and self.last_purge_usec_ != x.last_purge_usec_: return 0
    if self.has_paused_ != x.has_paused_: return 0
    if self.has_paused_ and self.paused_ != x.paused_: return 0
    if self.has_retry_parameters_ != x.has_retry_parameters_: return 0
    if self.has_retry_parameters_ and self.retry_parameters_ != x.retry_parameters_: return 0
    if self.has_mode_ != x.has_mode_: return 0
    if self.has_mode_ and self.mode_ != x.mode_: return 0
    if self.has_metadata_ != x.has_metadata_: return 0
    if self.has_metadata_ and self.metadata_ != x.metadata_: return 0
    if len(self.header_override_) != len(x.header_override_): return 0
    for e1, e2 in zip(self.header_override_, x.header_override_):
      if e1 != e2: return 0
    if self.has_acl_ != x.has_acl_: return 0
    if self.has_acl_ and self.acl_ != x.acl_: return 0
    if self.has_creator_name_ != x.has_creator_name_: return 0
    if self.has_creator_name_ and self.creator_name_ != x.creator_name_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    if (not self.has_queue_ref_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: queue_ref not set.')
    elif not self.queue_ref_.IsInitialized(debug_strs): initialized = 0
    if (not self.has_throttling_parameters_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: throttling_parameters not set.')
    elif not self.throttling_parameters_.IsInitialized(debug_strs): initialized = 0
    if (self.has_retry_parameters_ and not self.retry_parameters_.IsInitialized(debug_strs)): initialized = 0
    if (self.has_metadata_ and not self.metadata_.IsInitialized(debug_strs)): initialized = 0
    for p in self.header_override_:
      if not p.IsInitialized(debug_strs): initialized=0
    return initialized

  def ByteSize(self):
    n = 0
    n += self.lengthString(self.queue_ref_.ByteSize())
    n += self.lengthString(self.throttling_parameters_.ByteSize())
    if (self.has_user_specified_rate_): n += 1 + self.lengthString(len(self.user_specified_rate_))
    if (self.has_last_purge_usec_): n += 1 + self.lengthVarInt64(self.last_purge_usec_)
    if (self.has_paused_): n += 2
    if (self.has_retry_parameters_): n += 1 + self.lengthString(self.retry_parameters_.ByteSize())
    if (self.has_mode_): n += 1 + self.lengthVarInt64(self.mode_)
    if (self.has_metadata_): n += 1 + self.lengthString(self.metadata_.ByteSize())
    n += 1 * len(self.header_override_)
    for i in xrange(len(self.header_override_)): n += self.lengthString(self.header_override_[i].ByteSize())
    if (self.has_acl_): n += 1 + self.lengthString(len(self.acl_))
    if (self.has_creator_name_): n += 1 + self.lengthString(len(self.creator_name_))
    return n + 2

  def ByteSizePartial(self):
    n = 0
    if (self.has_queue_ref_):
      n += 1
      n += self.lengthString(self.queue_ref_.ByteSizePartial())
    if (self.has_throttling_parameters_):
      n += 1
      n += self.lengthString(self.throttling_parameters_.ByteSizePartial())
    if (self.has_user_specified_rate_): n += 1 + self.lengthString(len(self.user_specified_rate_))
    if (self.has_last_purge_usec_): n += 1 + self.lengthVarInt64(self.last_purge_usec_)
    if (self.has_paused_): n += 2
    if (self.has_retry_parameters_): n += 1 + self.lengthString(self.retry_parameters_.ByteSizePartial())
    if (self.has_mode_): n += 1 + self.lengthVarInt64(self.mode_)
    if (self.has_metadata_): n += 1 + self.lengthString(self.metadata_.ByteSizePartial())
    n += 1 * len(self.header_override_)
    for i in xrange(len(self.header_override_)): n += self.lengthString(self.header_override_[i].ByteSizePartial())
    if (self.has_acl_): n += 1 + self.lengthString(len(self.acl_))
    if (self.has_creator_name_): n += 1 + self.lengthString(len(self.creator_name_))
    return n

  def Clear(self):
    self.clear_queue_ref()
    self.clear_throttling_parameters()
    self.clear_user_specified_rate()
    self.clear_last_purge_usec()
    self.clear_paused()
    self.clear_retry_parameters()
    self.clear_mode()
    self.clear_metadata()
    self.clear_header_override()
    self.clear_acl()
    self.clear_creator_name()

  def OutputUnchecked(self, out):
    out.putVarInt32(10)
    out.putVarInt32(self.queue_ref_.ByteSize())
    self.queue_ref_.OutputUnchecked(out)
    out.putVarInt32(18)
    out.putVarInt32(self.throttling_parameters_.ByteSize())
    self.throttling_parameters_.OutputUnchecked(out)
    if (self.has_user_specified_rate_):
      out.putVarInt32(26)
      out.putPrefixedString(self.user_specified_rate_)
    if (self.has_last_purge_usec_):
      out.putVarInt32(32)
      out.putVarInt64(self.last_purge_usec_)
    if (self.has_paused_):
      out.putVarInt32(40)
      out.putBoolean(self.paused_)
    if (self.has_retry_parameters_):
      out.putVarInt32(50)
      out.putVarInt32(self.retry_parameters_.ByteSize())
      self.retry_parameters_.OutputUnchecked(out)
    if (self.has_mode_):
      out.putVarInt32(56)
      out.putVarInt32(self.mode_)
    if (self.has_metadata_):
      out.putVarInt32(66)
      out.putVarInt32(self.metadata_.ByteSize())
      self.metadata_.OutputUnchecked(out)
    for i in xrange(len(self.header_override_)):
      out.putVarInt32(74)
      out.putVarInt32(self.header_override_[i].ByteSize())
      self.header_override_[i].OutputUnchecked(out)
    if (self.has_acl_):
      out.putVarInt32(82)
      out.putPrefixedString(self.acl_)
    if (self.has_creator_name_):
      out.putVarInt32(90)
      out.putPrefixedString(self.creator_name_)

  def OutputPartial(self, out):
    if (self.has_queue_ref_):
      out.putVarInt32(10)
      out.putVarInt32(self.queue_ref_.ByteSizePartial())
      self.queue_ref_.OutputPartial(out)
    if (self.has_throttling_parameters_):
      out.putVarInt32(18)
      out.putVarInt32(self.throttling_parameters_.ByteSizePartial())
      self.throttling_parameters_.OutputPartial(out)
    if (self.has_user_specified_rate_):
      out.putVarInt32(26)
      out.putPrefixedString(self.user_specified_rate_)
    if (self.has_last_purge_usec_):
      out.putVarInt32(32)
      out.putVarInt64(self.last_purge_usec_)
    if (self.has_paused_):
      out.putVarInt32(40)
      out.putBoolean(self.paused_)
    if (self.has_retry_parameters_):
      out.putVarInt32(50)
      out.putVarInt32(self.retry_parameters_.ByteSizePartial())
      self.retry_parameters_.OutputPartial(out)
    if (self.has_mode_):
      out.putVarInt32(56)
      out.putVarInt32(self.mode_)
    if (self.has_metadata_):
      out.putVarInt32(66)
      out.putVarInt32(self.metadata_.ByteSizePartial())
      self.metadata_.OutputPartial(out)
    for i in xrange(len(self.header_override_)):
      out.putVarInt32(74)
      out.putVarInt32(self.header_override_[i].ByteSizePartial())
      self.header_override_[i].OutputPartial(out)
    if (self.has_acl_):
      out.putVarInt32(82)
      out.putPrefixedString(self.acl_)
    if (self.has_creator_name_):
      out.putVarInt32(90)
      out.putPrefixedString(self.creator_name_)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 10:
        length = d.getVarInt32()
        tmp = ProtocolBuffer.Decoder(d.buffer(), d.pos(), d.pos() + length)
        d.skip(length)
        self.mutable_queue_ref().TryMerge(tmp)
        continue
      if tt == 18:
        length = d.getVarInt32()
        tmp = ProtocolBuffer.Decoder(d.buffer(), d.pos(), d.pos() + length)
        d.skip(length)
        self.mutable_throttling_parameters().TryMerge(tmp)
        continue
      if tt == 26:
        self.set_user_specified_rate(d.getPrefixedString())
        continue
      if tt == 32:
        self.set_last_purge_usec(d.getVarInt64())
        continue
      if tt == 40:
        self.set_paused(d.getBoolean())
        continue
      if tt == 50:
        length = d.getVarInt32()
        tmp = ProtocolBuffer.Decoder(d.buffer(), d.pos(), d.pos() + length)
        d.skip(length)
        self.mutable_retry_parameters().TryMerge(tmp)
        continue
      if tt == 56:
        self.set_mode(d.getVarInt32())
        continue
      if tt == 66:
        length = d.getVarInt32()
        tmp = ProtocolBuffer.Decoder(d.buffer(), d.pos(), d.pos() + length)
        d.skip(length)
        self.mutable_metadata().TryMerge(tmp)
        continue
      if tt == 74:
        length = d.getVarInt32()
        tmp = ProtocolBuffer.Decoder(d.buffer(), d.pos(), d.pos() + length)
        d.skip(length)
        self.add_header_override().TryMerge(tmp)
        continue
      if tt == 82:
        self.set_acl(d.getPrefixedString())
        continue
      if tt == 90:
        self.set_creator_name(d.getPrefixedString())
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    if self.has_queue_ref_:
      res+=prefix+"queue_ref <\n"
      res+=self.queue_ref_.__str__(prefix + "  ", printElemNumber)
      res+=prefix+">\n"
    if self.has_throttling_parameters_:
      res+=prefix+"throttling_parameters <\n"
      res+=self.throttling_parameters_.__str__(prefix + "  ", printElemNumber)
      res+=prefix+">\n"
    if self.has_user_specified_rate_: res+=prefix+("user_specified_rate: %s\n" % self.DebugFormatString(self.user_specified_rate_))
    if self.has_last_purge_usec_: res+=prefix+("last_purge_usec: %s\n" % self.DebugFormatInt64(self.last_purge_usec_))
    if self.has_paused_: res+=prefix+("paused: %s\n" % self.DebugFormatBool(self.paused_))
    if self.has_retry_parameters_:
      res+=prefix+"retry_parameters <\n"
      res+=self.retry_parameters_.__str__(prefix + "  ", printElemNumber)
      res+=prefix+">\n"
    if self.has_mode_: res+=prefix+("mode: %s\n" % self.DebugFormatInt32(self.mode_))
    if self.has_metadata_:
      res+=prefix+"metadata <\n"
      res+=self.metadata_.__str__(prefix + "  ", printElemNumber)
      res+=prefix+">\n"
    cnt=0
    for e in self.header_override_:
      elm=""
      if printElemNumber: elm="(%d)" % cnt
      res+=prefix+("header_override%s <\n" % elm)
      res+=e.__str__(prefix + "  ", printElemNumber)
      res+=prefix+">\n"
      cnt+=1
    if self.has_acl_: res+=prefix+("acl: %s\n" % self.DebugFormatString(self.acl_))
    if self.has_creator_name_: res+=prefix+("creator_name: %s\n" % self.DebugFormatString(self.creator_name_))
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  kqueue_ref = 1
  kthrottling_parameters = 2
  kuser_specified_rate = 3
  klast_purge_usec = 4
  kpaused = 5
  kretry_parameters = 6
  kmode = 7
  kmetadata = 8
  kheader_override = 9
  kacl = 10
  kcreator_name = 11

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "queue_ref",
    2: "throttling_parameters",
    3: "user_specified_rate",
    4: "last_purge_usec",
    5: "paused",
    6: "retry_parameters",
    7: "mode",
    8: "metadata",
    9: "header_override",
    10: "acl",
    11: "creator_name",
  }, 11)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.STRING,
    2: ProtocolBuffer.Encoder.STRING,
    3: ProtocolBuffer.Encoder.STRING,
    4: ProtocolBuffer.Encoder.NUMERIC,
    5: ProtocolBuffer.Encoder.NUMERIC,
    6: ProtocolBuffer.Encoder.STRING,
    7: ProtocolBuffer.Encoder.NUMERIC,
    8: ProtocolBuffer.Encoder.STRING,
    9: ProtocolBuffer.Encoder.STRING,
    10: ProtocolBuffer.Encoder.STRING,
    11: ProtocolBuffer.Encoder.STRING,
  }, 11, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("Wh9hcHBob3N0aW5nL2V4ZWN1dG9yL3F1ZXVlLnByb3RvChphcHBob3N0aW5nLlF1ZXVlRGVmaW5pdGlvbhMaCXF1ZXVlX3JlZiABKAIwCzgCShNhcHBob3N0aW5nLlF1ZXVlUmVmFBMaFXRocm90dGxpbmdfcGFyYW1ldGVycyACKAIwCzgCSiRhcHBob3N0aW5nLlF1ZXVlVGhyb3R0bGluZ1BhcmFtZXRlcnMUExoTdXNlcl9zcGVjaWZpZWRfcmF0ZSADKAIwCTgBFBMaD2xhc3RfcHVyZ2VfdXNlYyAEKAAwAzgBQgEwowGqAQdkZWZhdWx0sgEBMKQBFBMaBnBhdXNlZCAFKAAwCDgBQgVmYWxzZaMBqgEHZGVmYXVsdLIBBWZhbHNlpAEUExoQcmV0cnlfcGFyYW1ldGVycyAGKAIwCzgBShphcHBob3N0aW5nLlJldHJ5UGFyYW1ldGVycxQTGgRtb2RlIAcoADAFOAFCATBoAKMBqgEHZGVmYXVsdLIBBFBVU0ikARQTGghtZXRhZGF0YSAIKAIwCzgBSgpNZXNzYWdlU2V0FBMaD2hlYWRlcl9vdmVycmlkZSAJKAIwCzgDSh9hcHBob3N0aW5nLkh0dHBUYXNrUnVubmVySGVhZGVyFBMaA2FjbCAKKAIwCTgBowGqAQVjdHlwZbIBBENvcmSkARQTGgxjcmVhdG9yX25hbWUgCygCMAk4AUIKYXBwaG9zdGluZ6MBqgEFY3R5cGWyAQRDb3JkpAGjAaoBB2RlZmF1bHSyAQwiYXBwaG9zdGluZyKkARRzeglRdWV1ZU1vZGWLAZIBBFBVU0iYAQCMAYsBkgEEUFVMTJgBAYwBdMIBE2FwcGhvc3RpbmcuUXVldWVSZWY="))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class QueueMap_Range(ProtocolBuffer.ProtocolMessage):
  has_queue_range_ = 0
  has_scanner_task_ = 0
  scanner_task_ = ""

  def __init__(self, contents=None):
    self.queue_range_ = QueueRange()
    if contents is not None: self.MergeFromString(contents)

  def queue_range(self): return self.queue_range_

  def mutable_queue_range(self): self.has_queue_range_ = 1; return self.queue_range_

  def clear_queue_range(self):self.has_queue_range_ = 0; self.queue_range_.Clear()

  def has_queue_range(self): return self.has_queue_range_

  def scanner_task(self): return self.scanner_task_

  def set_scanner_task(self, x):
    self.has_scanner_task_ = 1
    self.scanner_task_ = x

  def clear_scanner_task(self):
    if self.has_scanner_task_:
      self.has_scanner_task_ = 0
      self.scanner_task_ = ""

  def has_scanner_task(self): return self.has_scanner_task_


  def MergeFrom(self, x):
    assert x is not self
    if (x.has_queue_range()): self.mutable_queue_range().MergeFrom(x.queue_range())
    if (x.has_scanner_task()): self.set_scanner_task(x.scanner_task())

  def Equals(self, x):
    if x is self: return 1
    if self.has_queue_range_ != x.has_queue_range_: return 0
    if self.has_queue_range_ and self.queue_range_ != x.queue_range_: return 0
    if self.has_scanner_task_ != x.has_scanner_task_: return 0
    if self.has_scanner_task_ and self.scanner_task_ != x.scanner_task_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    if (not self.has_queue_range_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: queue_range not set.')
    elif not self.queue_range_.IsInitialized(debug_strs): initialized = 0
    if (not self.has_scanner_task_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: scanner_task not set.')
    return initialized

  def ByteSize(self):
    n = 0
    n += self.lengthString(self.queue_range_.ByteSize())
    n += self.lengthString(len(self.scanner_task_))
    return n + 2

  def ByteSizePartial(self):
    n = 0
    if (self.has_queue_range_):
      n += 1
      n += self.lengthString(self.queue_range_.ByteSizePartial())
    if (self.has_scanner_task_):
      n += 1
      n += self.lengthString(len(self.scanner_task_))
    return n

  def Clear(self):
    self.clear_queue_range()
    self.clear_scanner_task()

  def OutputUnchecked(self, out):
    out.putVarInt32(18)
    out.putVarInt32(self.queue_range_.ByteSize())
    self.queue_range_.OutputUnchecked(out)
    out.putVarInt32(26)
    out.putPrefixedString(self.scanner_task_)

  def OutputPartial(self, out):
    if (self.has_queue_range_):
      out.putVarInt32(18)
      out.putVarInt32(self.queue_range_.ByteSizePartial())
      self.queue_range_.OutputPartial(out)
    if (self.has_scanner_task_):
      out.putVarInt32(26)
      out.putPrefixedString(self.scanner_task_)

  def TryMerge(self, d):
    while 1:
      tt = d.getVarInt32()
      if tt == 12: break
      if tt == 18:
        length = d.getVarInt32()
        tmp = ProtocolBuffer.Decoder(d.buffer(), d.pos(), d.pos() + length)
        d.skip(length)
        self.mutable_queue_range().TryMerge(tmp)
        continue
      if tt == 26:
        self.set_scanner_task(d.getPrefixedString())
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    if self.has_queue_range_:
      res+=prefix+"queue_range <\n"
      res+=self.queue_range_.__str__(prefix + "  ", printElemNumber)
      res+=prefix+">\n"
    if self.has_scanner_task_: res+=prefix+("scanner_task: %s\n" % self.DebugFormatString(self.scanner_task_))
    return res

class QueueMap(ProtocolBuffer.ProtocolMessage):
  has_timestamp_usec_ = 0
  timestamp_usec_ = 0

  def __init__(self, contents=None):
    self.range_ = []
    if contents is not None: self.MergeFromString(contents)

  def range_size(self): return len(self.range_)
  def range_list(self): return self.range_

  def range(self, i):
    return self.range_[i]

  def mutable_range(self, i):
    return self.range_[i]

  def add_range(self):
    x = QueueMap_Range()
    self.range_.append(x)
    return x

  def clear_range(self):
    self.range_ = []
  def timestamp_usec(self): return self.timestamp_usec_

  def set_timestamp_usec(self, x):
    self.has_timestamp_usec_ = 1
    self.timestamp_usec_ = x

  def clear_timestamp_usec(self):
    if self.has_timestamp_usec_:
      self.has_timestamp_usec_ = 0
      self.timestamp_usec_ = 0

  def has_timestamp_usec(self): return self.has_timestamp_usec_


  def MergeFrom(self, x):
    assert x is not self
    for i in xrange(x.range_size()): self.add_range().CopyFrom(x.range(i))
    if (x.has_timestamp_usec()): self.set_timestamp_usec(x.timestamp_usec())

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.QueueMap', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.QueueMap')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.QueueMap')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.QueueMap', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.QueueMap', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.QueueMap', s)


  def Equals(self, x):
    if x is self: return 1
    if len(self.range_) != len(x.range_): return 0
    for e1, e2 in zip(self.range_, x.range_):
      if e1 != e2: return 0
    if self.has_timestamp_usec_ != x.has_timestamp_usec_: return 0
    if self.has_timestamp_usec_ and self.timestamp_usec_ != x.timestamp_usec_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    for p in self.range_:
      if not p.IsInitialized(debug_strs): initialized=0
    if (not self.has_timestamp_usec_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: timestamp_usec not set.')
    return initialized

  def ByteSize(self):
    n = 0
    n += 2 * len(self.range_)
    for i in xrange(len(self.range_)): n += self.range_[i].ByteSize()
    n += self.lengthVarInt64(self.timestamp_usec_)
    return n + 1

  def ByteSizePartial(self):
    n = 0
    n += 2 * len(self.range_)
    for i in xrange(len(self.range_)): n += self.range_[i].ByteSizePartial()
    if (self.has_timestamp_usec_):
      n += 1
      n += self.lengthVarInt64(self.timestamp_usec_)
    return n

  def Clear(self):
    self.clear_range()
    self.clear_timestamp_usec()

  def OutputUnchecked(self, out):
    for i in xrange(len(self.range_)):
      out.putVarInt32(11)
      self.range_[i].OutputUnchecked(out)
      out.putVarInt32(12)
    out.putVarInt32(32)
    out.putVarInt64(self.timestamp_usec_)

  def OutputPartial(self, out):
    for i in xrange(len(self.range_)):
      out.putVarInt32(11)
      self.range_[i].OutputPartial(out)
      out.putVarInt32(12)
    if (self.has_timestamp_usec_):
      out.putVarInt32(32)
      out.putVarInt64(self.timestamp_usec_)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 11:
        self.add_range().TryMerge(d)
        continue
      if tt == 32:
        self.set_timestamp_usec(d.getVarInt64())
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    cnt=0
    for e in self.range_:
      elm=""
      if printElemNumber: elm="(%d)" % cnt
      res+=prefix+("Range%s {\n" % elm)
      res+=e.__str__(prefix + "  ", printElemNumber)
      res+=prefix+"}\n"
      cnt+=1
    if self.has_timestamp_usec_: res+=prefix+("timestamp_usec: %s\n" % self.DebugFormatInt64(self.timestamp_usec_))
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  kRangeGroup = 1
  kRangequeue_range = 2
  kRangescanner_task = 3
  ktimestamp_usec = 4

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "Range",
    2: "queue_range",
    3: "scanner_task",
    4: "timestamp_usec",
  }, 4)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.STARTGROUP,
    2: ProtocolBuffer.Encoder.STRING,
    3: ProtocolBuffer.Encoder.STRING,
    4: ProtocolBuffer.Encoder.NUMERIC,
  }, 4, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("Wh9hcHBob3N0aW5nL2V4ZWN1dG9yL3F1ZXVlLnByb3RvChNhcHBob3N0aW5nLlF1ZXVlTWFwExoFUmFuZ2UgASgDMAo4AxQTGhFSYW5nZS5xdWV1ZV9yYW5nZSACKAIwCzgCShVhcHBob3N0aW5nLlF1ZXVlUmFuZ2VgABQTGhJSYW5nZS5zY2FubmVyX3Rhc2sgAygCMAk4AmAAFBMaDnRpbWVzdGFtcF91c2VjIAQoADADOAIUwgETYXBwaG9zdGluZy5RdWV1ZVJlZg=="))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())


__all__ = ['QueueRef','QueueRangeBorder','QueueRange','QueueThrottlingParameters','HttpTaskRunnerHeader','QueueDefinition','QueueMap','QueueMap_Range']
