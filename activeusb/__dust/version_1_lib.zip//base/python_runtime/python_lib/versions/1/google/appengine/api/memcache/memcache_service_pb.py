#!/usr/bin/env python
#
# Copyright 2007 Google Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#



from google.net.proto import ProtocolBuffer
import array
import base64
import dummy_thread as thread
try:
  from google3.net.proto import _net_proto___parse__python
except ImportError:
  _net_proto___parse__python = None
import sys
try:
  __import__('google.net.rpc.python.rpc_internals_lite')
  __import__('google.net.rpc.python.pywraprpc_lite')
  rpc_internals = sys.modules.get('google.net.rpc.python.rpc_internals_lite')
  pywraprpc = sys.modules.get('google.net.rpc.python.pywraprpc_lite')
  _client_stub_base_class = rpc_internals.StubbyRPCBaseStub
except ImportError:
  _client_stub_base_class = object
try:
  __import__('google.net.rpc.python.rpcserver')
  rpcserver = sys.modules.get('google.net.rpc.python.rpcserver')
  _server_stub_base_class = rpcserver.BaseRpcServer
except ImportError:
  _server_stub_base_class = object

__pychecker__ = """maxreturns=0 maxbranches=0 no-callinit
                   unusednames=printElemNumber,debug_strs no-special"""

class MemcacheServiceError(ProtocolBuffer.ProtocolMessage):


  OK           =    0
  UNSPECIFIED_ERROR =    1
  NAMESPACE_NOT_SET =    2
  PERMISSION_DENIED =    3
  NUM_BACKENDS_UNSPECIFIED =    4

  _ErrorCode_NAMES = {
    0: "OK",
    1: "UNSPECIFIED_ERROR",
    2: "NAMESPACE_NOT_SET",
    3: "PERMISSION_DENIED",
    4: "NUM_BACKENDS_UNSPECIFIED",
  }

  def ErrorCode_Name(cls, x): return cls._ErrorCode_NAMES.get(x, "")
  ErrorCode_Name = classmethod(ErrorCode_Name)


  def __init__(self, contents=None):
    pass
    if contents is not None: self.MergeFromString(contents)


  def MergeFrom(self, x):
    assert x is not self

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.MemcacheServiceError', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.MemcacheServiceError')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.MemcacheServiceError')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.MemcacheServiceError', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.MemcacheServiceError', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.MemcacheServiceError', s)


  def Equals(self, x):
    if x is self: return 1
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    return initialized

  def ByteSize(self):
    n = 0
    return n

  def ByteSizePartial(self):
    n = 0
    return n

  def Clear(self):
    pass

  def OutputUnchecked(self, out):
    pass

  def OutputPartial(self, out):
    pass

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])


  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
  }, 0)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
  }, 0, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("Wi5hcHBob3N0aW5nL2FwaS9tZW1jYWNoZS9tZW1jYWNoZV9zZXJ2aWNlLnByb3RvCh9hcHBob3N0aW5nLk1lbWNhY2hlU2VydmljZUVycm9yc3oJRXJyb3JDb2RliwGSAQJPS5gBAIwBiwGSARFVTlNQRUNJRklFRF9FUlJPUpgBAYwBiwGSARFOQU1FU1BBQ0VfTk9UX1NFVJgBAowBiwGSARFQRVJNSVNTSU9OX0RFTklFRJgBA4wBiwGSARhOVU1fQkFDS0VORFNfVU5TUEVDSUZJRUSYAQSMAXS6AaobCi5hcHBob3N0aW5nL2FwaS9tZW1jYWNoZS9tZW1jYWNoZV9zZXJ2aWNlLnByb3RvEgphcHBob3N0aW5nIo4BChRNZW1jYWNoZVNlcnZpY2VFcnJvciJ2CglFcnJvckNvZGUSBgoCT0sQABIVChFVTlNQRUNJRklFRF9FUlJPUhABEhUKEU5BTUVTUEFDRV9OT1RfU0VUEAISFQoRUEVSTUlTU0lPTl9ERU5JRUQQAxIcChhOVU1fQkFDS0VORFNfVU5TUEVDSUZJRUQQBCI9CgtBcHBPdmVycmlkZRIOCgZhcHBfaWQYASACKAkSHgoWbnVtX21lbWNhY2hlZ19iYWNrZW5kcxgCIAIoBSJzChJNZW1jYWNoZUdldFJlcXVlc3QSCwoDa2V5GAEgAygMEhQKCm5hbWVfc3BhY2UYAiABKAk6ABIPCgdmb3JfY2FzGAQgASgIEikKCG92ZXJyaWRlGAUgASgLMhcuYXBwaG9zdGluZy5BcHBPdmVycmlkZSKoAQoTTWVtY2FjaGVHZXRSZXNwb25zZRIyCgRpdGVtGAEgAygKMiQuYXBwaG9zdGluZy5NZW1jYWNoZUdldFJlc3BvbnNlLkl0ZW0aXQoESXRlbRILCgNrZXkYAiACKAwSDQoFdmFsdWUYAyACKAwSDQoFZmxhZ3MYBCABKAcSDgoGY2FzX2lkGAUgASgGEhoKEmV4cGlyZXNfaW5fc2Vjb25kcxgGIAEoBSLxAgoSTWVtY2FjaGVTZXRSZXF1ZXN0EjEKBGl0ZW0YASADKAoyIy5hcHBob3N0aW5nLk1lbWNhY2hlU2V0UmVxdWVzdC5JdGVtEhQKCm5hbWVfc3BhY2UYByABKAk6ABIpCghvdmVycmlkZRgKIAEoCzIXLmFwcGhvc3RpbmcuQXBwT3ZlcnJpZGUasQEKBEl0ZW0SCwoDa2V5GAIgAigMEg0KBXZhbHVlGAMgAigMEg0KBWZsYWdzGAQgASgHEkEKCnNldF9wb2xpY3kYBSABKA4yKC5hcHBob3N0aW5nLk1lbWNhY2hlU2V0UmVxdWVzdC5TZXRQb2xpY3k6A1NFVBIaCg9leHBpcmF0aW9uX3RpbWUYBiABKAc6ATASDgoGY2FzX2lkGAggASgGEg8KB2Zvcl9jYXMYCSABKAgiMwoJU2V0UG9saWN5EgcKA1NFVBABEgcKA0FERBACEgsKB1JFUExBQ0UQAxIHCgNDQVMQBCKcAQoTTWVtY2FjaGVTZXRSZXNwb25zZRJBCgpzZXRfc3RhdHVzGAEgAygOMi0uYXBwaG9zdGluZy5NZW1jYWNoZVNldFJlc3BvbnNlLlNldFN0YXR1c0NvZGUiQgoNU2V0U3RhdHVzQ29kZRIKCgZTVE9SRUQQARIOCgpOT1RfU1RPUkVEEAISCQoFRVJST1IQAxIKCgZFWElTVFMQBCK7AQoVTWVtY2FjaGVEZWxldGVSZXF1ZXN0EjQKBGl0ZW0YASADKAoyJi5hcHBob3N0aW5nLk1lbWNhY2hlRGVsZXRlUmVxdWVzdC5JdGVtEhQKCm5hbWVfc3BhY2UYBCABKAk6ABIpCghvdmVycmlkZRgFIAEoCzIXLmFwcGhvc3RpbmcuQXBwT3ZlcnJpZGUaKwoESXRlbRILCgNrZXkYAiACKAwSFgoLZGVsZXRlX3RpbWUYAyABKAc6ATAilAEKFk1lbWNhY2hlRGVsZXRlUmVzcG9uc2USSgoNZGVsZXRlX3N0YXR1cxgBIAMoDjIzLmFwcGhvc3RpbmcuTWVtY2FjaGVEZWxldGVSZXNwb25zZS5EZWxldGVTdGF0dXNDb2RlIi4KEERlbGV0ZVN0YXR1c0NvZGUSCwoHREVMRVRFRBABEg0KCU5PVF9GT1VORBACIqECChhNZW1jYWNoZUluY3JlbWVudFJlcXVlc3QSCwoDa2V5GAEgAigMEhQKCm5hbWVfc3BhY2UYBCABKAk6ABIQCgVkZWx0YRgCIAEoBDoBMRJMCglkaXJlY3Rpb24YAyABKA4yLi5hcHBob3N0aW5nLk1lbWNhY2hlSW5jcmVtZW50UmVxdWVzdC5EaXJlY3Rpb246CUlOQ1JFTUVOVBIVCg1pbml0aWFsX3ZhbHVlGAUgASgEEhUKDWluaXRpYWxfZmxhZ3MYBiABKAcSKQoIb3ZlcnJpZGUYByABKAsyFy5hcHBob3N0aW5nLkFwcE92ZXJyaWRlIikKCURpcmVjdGlvbhINCglJTkNSRU1FTlQQARINCglERUNSRU1FTlQQAiK+AQoZTWVtY2FjaGVJbmNyZW1lbnRSZXNwb25zZRIRCgluZXdfdmFsdWUYASABKAQSUwoQaW5jcmVtZW50X3N0YXR1cxgCIAEoDjI5LmFwcGhvc3RpbmcuTWVtY2FjaGVJbmNyZW1lbnRSZXNwb25zZS5JbmNyZW1lbnRTdGF0dXNDb2RlIjkKE0luY3JlbWVudFN0YXR1c0NvZGUSBgoCT0sQARIPCgtOT1RfQ0hBTkdFRBACEgkKBUVSUk9SEAMilAEKHU1lbWNhY2hlQmF0Y2hJbmNyZW1lbnRSZXF1ZXN0EhQKCm5hbWVfc3BhY2UYASABKAk6ABIyCgRpdGVtGAIgAygLMiQuYXBwaG9zdGluZy5NZW1jYWNoZUluY3JlbWVudFJlcXVlc3QSKQoIb3ZlcnJpZGUYAyABKAsyFy5hcHBob3N0aW5nLkFwcE92ZXJyaWRlIlUKHk1lbWNhY2hlQmF0Y2hJbmNyZW1lbnRSZXNwb25zZRIzCgRpdGVtGAEgAygLMiUuYXBwaG9zdGluZy5NZW1jYWNoZUluY3JlbWVudFJlc3BvbnNlIkEKFE1lbWNhY2hlRmx1c2hSZXF1ZXN0EikKCG92ZXJyaWRlGAEgASgLMhcuYXBwaG9zdGluZy5BcHBPdmVycmlkZSIXChVNZW1jYWNoZUZsdXNoUmVzcG9uc2UiQQoUTWVtY2FjaGVTdGF0c1JlcXVlc3QSKQoIb3ZlcnJpZGUYASABKAsyFy5hcHBob3N0aW5nLkFwcE92ZXJyaWRlIn4KFE1lcmdlZE5hbWVzcGFjZVN0YXRzEgwKBGhpdHMYASACKAQSDgoGbWlzc2VzGAIgAigEEhEKCWJ5dGVfaGl0cxgDIAIoBBINCgVpdGVtcxgEIAIoBBINCgVieXRlcxgFIAIoBBIXCg9vbGRlc3RfaXRlbV9hZ2UYBiACKAciSAoVTWVtY2FjaGVTdGF0c1Jlc3BvbnNlEi8KBXN0YXRzGAEgASgLMiAuYXBwaG9zdGluZy5NZXJnZWROYW1lc3BhY2VTdGF0cyJuChdNZW1jYWNoZUdyYWJUYWlsUmVxdWVzdBISCgppdGVtX2NvdW50GAEgAigFEhQKCm5hbWVfc3BhY2UYAiABKAk6ABIpCghvdmVycmlkZRgDIAEoCzIXLmFwcGhvc3RpbmcuQXBwT3ZlcnJpZGUieQoYTWVtY2FjaGVHcmFiVGFpbFJlc3BvbnNlEjcKBGl0ZW0YASADKAoyKS5hcHBob3N0aW5nLk1lbWNhY2hlR3JhYlRhaWxSZXNwb25zZS5JdGVtGiQKBEl0ZW0SDQoFdmFsdWUYAiACKAwSDQoFZmxhZ3MYAyABKAcyqwUKD01lbWNhY2hlU2VydmljZRJGCgNHZXQSHi5hcHBob3N0aW5nLk1lbWNhY2hlR2V0UmVxdWVzdBofLmFwcGhvc3RpbmcuTWVtY2FjaGVHZXRSZXNwb25zZRJGCgNTZXQSHi5hcHBob3N0aW5nLk1lbWNhY2hlU2V0UmVxdWVzdBofLmFwcGhvc3RpbmcuTWVtY2FjaGVTZXRSZXNwb25zZRJPCgZEZWxldGUSIS5hcHBob3N0aW5nLk1lbWNhY2hlRGVsZXRlUmVxdWVzdBoiLmFwcGhvc3RpbmcuTWVtY2FjaGVEZWxldGVSZXNwb25zZRJYCglJbmNyZW1lbnQSJC5hcHBob3N0aW5nLk1lbWNhY2hlSW5jcmVtZW50UmVxdWVzdBolLmFwcGhvc3RpbmcuTWVtY2FjaGVJbmNyZW1lbnRSZXNwb25zZRJnCg5CYXRjaEluY3JlbWVudBIpLmFwcGhvc3RpbmcuTWVtY2FjaGVCYXRjaEluY3JlbWVudFJlcXVlc3QaKi5hcHBob3N0aW5nLk1lbWNhY2hlQmF0Y2hJbmNyZW1lbnRSZXNwb25zZRJPCghGbHVzaEFsbBIgLmFwcGhvc3RpbmcuTWVtY2FjaGVGbHVzaFJlcXVlc3QaIS5hcHBob3N0aW5nLk1lbWNhY2hlRmx1c2hSZXNwb25zZRJMCgVTdGF0cxIgLmFwcGhvc3RpbmcuTWVtY2FjaGVTdGF0c1JlcXVlc3QaIS5hcHBob3N0aW5nLk1lbWNhY2hlU3RhdHNSZXNwb25zZRJVCghHcmFiVGFpbBIjLmFwcGhvc3RpbmcuTWVtY2FjaGVHcmFiVGFpbFJlcXVlc3QaJC5hcHBob3N0aW5nLk1lbWNhY2hlR3JhYlRhaWxSZXNwb25zZUI/CiFjb20uZ29vZ2xlLmFwcGVuZ2luZS5hcGkubWVtY2FjaGUQASABKAJCEU1lbWNhY2hlU2VydmljZVBiiAEB"))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class AppOverride(ProtocolBuffer.ProtocolMessage):
  has_app_id_ = 0
  app_id_ = ""
  has_num_memcacheg_backends_ = 0
  num_memcacheg_backends_ = 0

  def __init__(self, contents=None):
    if contents is not None: self.MergeFromString(contents)

  def app_id(self): return self.app_id_

  def set_app_id(self, x):
    self.has_app_id_ = 1
    self.app_id_ = x

  def clear_app_id(self):
    if self.has_app_id_:
      self.has_app_id_ = 0
      self.app_id_ = ""

  def has_app_id(self): return self.has_app_id_

  def num_memcacheg_backends(self): return self.num_memcacheg_backends_

  def set_num_memcacheg_backends(self, x):
    self.has_num_memcacheg_backends_ = 1
    self.num_memcacheg_backends_ = x

  def clear_num_memcacheg_backends(self):
    if self.has_num_memcacheg_backends_:
      self.has_num_memcacheg_backends_ = 0
      self.num_memcacheg_backends_ = 0

  def has_num_memcacheg_backends(self): return self.has_num_memcacheg_backends_


  def MergeFrom(self, x):
    assert x is not self
    if (x.has_app_id()): self.set_app_id(x.app_id())
    if (x.has_num_memcacheg_backends()): self.set_num_memcacheg_backends(x.num_memcacheg_backends())

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.AppOverride', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.AppOverride')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.AppOverride')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.AppOverride', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.AppOverride', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.AppOverride', s)


  def Equals(self, x):
    if x is self: return 1
    if self.has_app_id_ != x.has_app_id_: return 0
    if self.has_app_id_ and self.app_id_ != x.app_id_: return 0
    if self.has_num_memcacheg_backends_ != x.has_num_memcacheg_backends_: return 0
    if self.has_num_memcacheg_backends_ and self.num_memcacheg_backends_ != x.num_memcacheg_backends_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    if (not self.has_app_id_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: app_id not set.')
    if (not self.has_num_memcacheg_backends_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: num_memcacheg_backends not set.')
    return initialized

  def ByteSize(self):
    n = 0
    n += self.lengthString(len(self.app_id_))
    n += self.lengthVarInt64(self.num_memcacheg_backends_)
    return n + 2

  def ByteSizePartial(self):
    n = 0
    if (self.has_app_id_):
      n += 1
      n += self.lengthString(len(self.app_id_))
    if (self.has_num_memcacheg_backends_):
      n += 1
      n += self.lengthVarInt64(self.num_memcacheg_backends_)
    return n

  def Clear(self):
    self.clear_app_id()
    self.clear_num_memcacheg_backends()

  def OutputUnchecked(self, out):
    out.putVarInt32(10)
    out.putPrefixedString(self.app_id_)
    out.putVarInt32(16)
    out.putVarInt32(self.num_memcacheg_backends_)

  def OutputPartial(self, out):
    if (self.has_app_id_):
      out.putVarInt32(10)
      out.putPrefixedString(self.app_id_)
    if (self.has_num_memcacheg_backends_):
      out.putVarInt32(16)
      out.putVarInt32(self.num_memcacheg_backends_)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 10:
        self.set_app_id(d.getPrefixedString())
        continue
      if tt == 16:
        self.set_num_memcacheg_backends(d.getVarInt32())
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    if self.has_app_id_: res+=prefix+("app_id: %s\n" % self.DebugFormatString(self.app_id_))
    if self.has_num_memcacheg_backends_: res+=prefix+("num_memcacheg_backends: %s\n" % self.DebugFormatInt32(self.num_memcacheg_backends_))
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  kapp_id = 1
  knum_memcacheg_backends = 2

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "app_id",
    2: "num_memcacheg_backends",
  }, 2)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.STRING,
    2: ProtocolBuffer.Encoder.NUMERIC,
  }, 2, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("Wi5hcHBob3N0aW5nL2FwaS9tZW1jYWNoZS9tZW1jYWNoZV9zZXJ2aWNlLnByb3RvChZhcHBob3N0aW5nLkFwcE92ZXJyaWRlExoGYXBwX2lkIAEoAjAJOAIUExoWbnVtX21lbWNhY2hlZ19iYWNrZW5kcyACKAAwBTgCFMIBH2FwcGhvc3RpbmcuTWVtY2FjaGVTZXJ2aWNlRXJyb3I="))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class MemcacheGetRequest(ProtocolBuffer.ProtocolMessage):
  has_name_space_ = 0
  name_space_ = ""
  has_for_cas_ = 0
  for_cas_ = 0
  has_override_ = 0
  override_ = None

  def __init__(self, contents=None):
    self.key_ = []
    self.lazy_init_lock_ = thread.allocate_lock()
    if contents is not None: self.MergeFromString(contents)

  def key_size(self): return len(self.key_)
  def key_list(self): return self.key_

  def key(self, i):
    return self.key_[i]

  def set_key(self, i, x):
    self.key_[i] = x

  def add_key(self, x):
    self.key_.append(x)

  def clear_key(self):
    self.key_ = []

  def name_space(self): return self.name_space_

  def set_name_space(self, x):
    self.has_name_space_ = 1
    self.name_space_ = x

  def clear_name_space(self):
    if self.has_name_space_:
      self.has_name_space_ = 0
      self.name_space_ = ""

  def has_name_space(self): return self.has_name_space_

  def for_cas(self): return self.for_cas_

  def set_for_cas(self, x):
    self.has_for_cas_ = 1
    self.for_cas_ = x

  def clear_for_cas(self):
    if self.has_for_cas_:
      self.has_for_cas_ = 0
      self.for_cas_ = 0

  def has_for_cas(self): return self.has_for_cas_

  def override(self):
    if self.override_ is None:
      self.lazy_init_lock_.acquire()
      try:
        if self.override_ is None: self.override_ = AppOverride()
      finally:
        self.lazy_init_lock_.release()
    return self.override_

  def mutable_override(self): self.has_override_ = 1; return self.override()

  def clear_override(self):

    if self.has_override_:
      self.has_override_ = 0;
      if self.override_ is not None: self.override_.Clear()

  def has_override(self): return self.has_override_


  def MergeFrom(self, x):
    assert x is not self
    for i in xrange(x.key_size()): self.add_key(x.key(i))
    if (x.has_name_space()): self.set_name_space(x.name_space())
    if (x.has_for_cas()): self.set_for_cas(x.for_cas())
    if (x.has_override()): self.mutable_override().MergeFrom(x.override())

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.MemcacheGetRequest', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.MemcacheGetRequest')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.MemcacheGetRequest')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.MemcacheGetRequest', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.MemcacheGetRequest', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.MemcacheGetRequest', s)


  def Equals(self, x):
    if x is self: return 1
    if len(self.key_) != len(x.key_): return 0
    for e1, e2 in zip(self.key_, x.key_):
      if e1 != e2: return 0
    if self.has_name_space_ != x.has_name_space_: return 0
    if self.has_name_space_ and self.name_space_ != x.name_space_: return 0
    if self.has_for_cas_ != x.has_for_cas_: return 0
    if self.has_for_cas_ and self.for_cas_ != x.for_cas_: return 0
    if self.has_override_ != x.has_override_: return 0
    if self.has_override_ and self.override_ != x.override_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    if (self.has_override_ and not self.override_.IsInitialized(debug_strs)): initialized = 0
    return initialized

  def ByteSize(self):
    n = 0
    n += 1 * len(self.key_)
    for i in xrange(len(self.key_)): n += self.lengthString(len(self.key_[i]))
    if (self.has_name_space_): n += 1 + self.lengthString(len(self.name_space_))
    if (self.has_for_cas_): n += 2
    if (self.has_override_): n += 1 + self.lengthString(self.override_.ByteSize())
    return n

  def ByteSizePartial(self):
    n = 0
    n += 1 * len(self.key_)
    for i in xrange(len(self.key_)): n += self.lengthString(len(self.key_[i]))
    if (self.has_name_space_): n += 1 + self.lengthString(len(self.name_space_))
    if (self.has_for_cas_): n += 2
    if (self.has_override_): n += 1 + self.lengthString(self.override_.ByteSizePartial())
    return n

  def Clear(self):
    self.clear_key()
    self.clear_name_space()
    self.clear_for_cas()
    self.clear_override()

  def OutputUnchecked(self, out):
    for i in xrange(len(self.key_)):
      out.putVarInt32(10)
      out.putPrefixedString(self.key_[i])
    if (self.has_name_space_):
      out.putVarInt32(18)
      out.putPrefixedString(self.name_space_)
    if (self.has_for_cas_):
      out.putVarInt32(32)
      out.putBoolean(self.for_cas_)
    if (self.has_override_):
      out.putVarInt32(42)
      out.putVarInt32(self.override_.ByteSize())
      self.override_.OutputUnchecked(out)

  def OutputPartial(self, out):
    for i in xrange(len(self.key_)):
      out.putVarInt32(10)
      out.putPrefixedString(self.key_[i])
    if (self.has_name_space_):
      out.putVarInt32(18)
      out.putPrefixedString(self.name_space_)
    if (self.has_for_cas_):
      out.putVarInt32(32)
      out.putBoolean(self.for_cas_)
    if (self.has_override_):
      out.putVarInt32(42)
      out.putVarInt32(self.override_.ByteSizePartial())
      self.override_.OutputPartial(out)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 10:
        self.add_key(d.getPrefixedString())
        continue
      if tt == 18:
        self.set_name_space(d.getPrefixedString())
        continue
      if tt == 32:
        self.set_for_cas(d.getBoolean())
        continue
      if tt == 42:
        length = d.getVarInt32()
        tmp = ProtocolBuffer.Decoder(d.buffer(), d.pos(), d.pos() + length)
        d.skip(length)
        self.mutable_override().TryMerge(tmp)
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    cnt=0
    for e in self.key_:
      elm=""
      if printElemNumber: elm="(%d)" % cnt
      res+=prefix+("key%s: %s\n" % (elm, self.DebugFormatString(e)))
      cnt+=1
    if self.has_name_space_: res+=prefix+("name_space: %s\n" % self.DebugFormatString(self.name_space_))
    if self.has_for_cas_: res+=prefix+("for_cas: %s\n" % self.DebugFormatBool(self.for_cas_))
    if self.has_override_:
      res+=prefix+"override <\n"
      res+=self.override_.__str__(prefix + "  ", printElemNumber)
      res+=prefix+">\n"
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  kkey = 1
  kname_space = 2
  kfor_cas = 4
  koverride = 5

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "key",
    2: "name_space",
    4: "for_cas",
    5: "override",
  }, 5)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.STRING,
    2: ProtocolBuffer.Encoder.STRING,
    4: ProtocolBuffer.Encoder.NUMERIC,
    5: ProtocolBuffer.Encoder.STRING,
  }, 5, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("Wi5hcHBob3N0aW5nL2FwaS9tZW1jYWNoZS9tZW1jYWNoZV9zZXJ2aWNlLnByb3RvCh1hcHBob3N0aW5nLk1lbWNhY2hlR2V0UmVxdWVzdBMaA2tleSABKAIwCTgDFBMaCm5hbWVfc3BhY2UgAigCMAk4AUIAowGqAQdkZWZhdWx0sgECIiKkARQTGgdmb3JfY2FzIAQoADAIOAEUExoIb3ZlcnJpZGUgBSgCMAs4AUoWYXBwaG9zdGluZy5BcHBPdmVycmlkZRTCAR9hcHBob3N0aW5nLk1lbWNhY2hlU2VydmljZUVycm9y"))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class MemcacheGetResponse_Item(ProtocolBuffer.ProtocolMessage):
  has_key_ = 0
  key_ = ""
  has_value_ = 0
  value_ = ""
  has_flags_ = 0
  flags_ = 0
  has_cas_id_ = 0
  cas_id_ = 0
  has_expires_in_seconds_ = 0
  expires_in_seconds_ = 0

  def __init__(self, contents=None):
    if contents is not None: self.MergeFromString(contents)

  def key(self): return self.key_

  def set_key(self, x):
    self.has_key_ = 1
    self.key_ = x

  def clear_key(self):
    if self.has_key_:
      self.has_key_ = 0
      self.key_ = ""

  def has_key(self): return self.has_key_

  def value(self): return self.value_

  def set_value(self, x):
    self.has_value_ = 1
    self.value_ = x

  def clear_value(self):
    if self.has_value_:
      self.has_value_ = 0
      self.value_ = ""

  def has_value(self): return self.has_value_

  def flags(self): return self.flags_

  def set_flags(self, x):
    self.has_flags_ = 1
    self.flags_ = x

  def clear_flags(self):
    if self.has_flags_:
      self.has_flags_ = 0
      self.flags_ = 0

  def has_flags(self): return self.has_flags_

  def cas_id(self): return self.cas_id_

  def set_cas_id(self, x):
    self.has_cas_id_ = 1
    self.cas_id_ = x

  def clear_cas_id(self):
    if self.has_cas_id_:
      self.has_cas_id_ = 0
      self.cas_id_ = 0

  def has_cas_id(self): return self.has_cas_id_

  def expires_in_seconds(self): return self.expires_in_seconds_

  def set_expires_in_seconds(self, x):
    self.has_expires_in_seconds_ = 1
    self.expires_in_seconds_ = x

  def clear_expires_in_seconds(self):
    if self.has_expires_in_seconds_:
      self.has_expires_in_seconds_ = 0
      self.expires_in_seconds_ = 0

  def has_expires_in_seconds(self): return self.has_expires_in_seconds_


  def MergeFrom(self, x):
    assert x is not self
    if (x.has_key()): self.set_key(x.key())
    if (x.has_value()): self.set_value(x.value())
    if (x.has_flags()): self.set_flags(x.flags())
    if (x.has_cas_id()): self.set_cas_id(x.cas_id())
    if (x.has_expires_in_seconds()): self.set_expires_in_seconds(x.expires_in_seconds())

  def Equals(self, x):
    if x is self: return 1
    if self.has_key_ != x.has_key_: return 0
    if self.has_key_ and self.key_ != x.key_: return 0
    if self.has_value_ != x.has_value_: return 0
    if self.has_value_ and self.value_ != x.value_: return 0
    if self.has_flags_ != x.has_flags_: return 0
    if self.has_flags_ and self.flags_ != x.flags_: return 0
    if self.has_cas_id_ != x.has_cas_id_: return 0
    if self.has_cas_id_ and self.cas_id_ != x.cas_id_: return 0
    if self.has_expires_in_seconds_ != x.has_expires_in_seconds_: return 0
    if self.has_expires_in_seconds_ and self.expires_in_seconds_ != x.expires_in_seconds_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    if (not self.has_key_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: key not set.')
    if (not self.has_value_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: value not set.')
    return initialized

  def ByteSize(self):
    n = 0
    n += self.lengthString(len(self.key_))
    n += self.lengthString(len(self.value_))
    if (self.has_flags_): n += 5
    if (self.has_cas_id_): n += 9
    if (self.has_expires_in_seconds_): n += 1 + self.lengthVarInt64(self.expires_in_seconds_)
    return n + 2

  def ByteSizePartial(self):
    n = 0
    if (self.has_key_):
      n += 1
      n += self.lengthString(len(self.key_))
    if (self.has_value_):
      n += 1
      n += self.lengthString(len(self.value_))
    if (self.has_flags_): n += 5
    if (self.has_cas_id_): n += 9
    if (self.has_expires_in_seconds_): n += 1 + self.lengthVarInt64(self.expires_in_seconds_)
    return n

  def Clear(self):
    self.clear_key()
    self.clear_value()
    self.clear_flags()
    self.clear_cas_id()
    self.clear_expires_in_seconds()

  def OutputUnchecked(self, out):
    out.putVarInt32(18)
    out.putPrefixedString(self.key_)
    out.putVarInt32(26)
    out.putPrefixedString(self.value_)
    if (self.has_flags_):
      out.putVarInt32(37)
      out.put32(self.flags_)
    if (self.has_cas_id_):
      out.putVarInt32(41)
      out.put64(self.cas_id_)
    if (self.has_expires_in_seconds_):
      out.putVarInt32(48)
      out.putVarInt32(self.expires_in_seconds_)

  def OutputPartial(self, out):
    if (self.has_key_):
      out.putVarInt32(18)
      out.putPrefixedString(self.key_)
    if (self.has_value_):
      out.putVarInt32(26)
      out.putPrefixedString(self.value_)
    if (self.has_flags_):
      out.putVarInt32(37)
      out.put32(self.flags_)
    if (self.has_cas_id_):
      out.putVarInt32(41)
      out.put64(self.cas_id_)
    if (self.has_expires_in_seconds_):
      out.putVarInt32(48)
      out.putVarInt32(self.expires_in_seconds_)

  def TryMerge(self, d):
    while 1:
      tt = d.getVarInt32()
      if tt == 12: break
      if tt == 18:
        self.set_key(d.getPrefixedString())
        continue
      if tt == 26:
        self.set_value(d.getPrefixedString())
        continue
      if tt == 37:
        self.set_flags(d.get32())
        continue
      if tt == 41:
        self.set_cas_id(d.get64())
        continue
      if tt == 48:
        self.set_expires_in_seconds(d.getVarInt32())
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    if self.has_key_: res+=prefix+("key: %s\n" % self.DebugFormatString(self.key_))
    if self.has_value_: res+=prefix+("value: %s\n" % self.DebugFormatString(self.value_))
    if self.has_flags_: res+=prefix+("flags: %s\n" % self.DebugFormatFixed32(self.flags_))
    if self.has_cas_id_: res+=prefix+("cas_id: %s\n" % self.DebugFormatFixed64(self.cas_id_))
    if self.has_expires_in_seconds_: res+=prefix+("expires_in_seconds: %s\n" % self.DebugFormatInt32(self.expires_in_seconds_))
    return res

class MemcacheGetResponse(ProtocolBuffer.ProtocolMessage):

  def __init__(self, contents=None):
    self.item_ = []
    if contents is not None: self.MergeFromString(contents)

  def item_size(self): return len(self.item_)
  def item_list(self): return self.item_

  def item(self, i):
    return self.item_[i]

  def mutable_item(self, i):
    return self.item_[i]

  def add_item(self):
    x = MemcacheGetResponse_Item()
    self.item_.append(x)
    return x

  def clear_item(self):
    self.item_ = []

  def MergeFrom(self, x):
    assert x is not self
    for i in xrange(x.item_size()): self.add_item().CopyFrom(x.item(i))

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.MemcacheGetResponse', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.MemcacheGetResponse')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.MemcacheGetResponse')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.MemcacheGetResponse', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.MemcacheGetResponse', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.MemcacheGetResponse', s)


  def Equals(self, x):
    if x is self: return 1
    if len(self.item_) != len(x.item_): return 0
    for e1, e2 in zip(self.item_, x.item_):
      if e1 != e2: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    for p in self.item_:
      if not p.IsInitialized(debug_strs): initialized=0
    return initialized

  def ByteSize(self):
    n = 0
    n += 2 * len(self.item_)
    for i in xrange(len(self.item_)): n += self.item_[i].ByteSize()
    return n

  def ByteSizePartial(self):
    n = 0
    n += 2 * len(self.item_)
    for i in xrange(len(self.item_)): n += self.item_[i].ByteSizePartial()
    return n

  def Clear(self):
    self.clear_item()

  def OutputUnchecked(self, out):
    for i in xrange(len(self.item_)):
      out.putVarInt32(11)
      self.item_[i].OutputUnchecked(out)
      out.putVarInt32(12)

  def OutputPartial(self, out):
    for i in xrange(len(self.item_)):
      out.putVarInt32(11)
      self.item_[i].OutputPartial(out)
      out.putVarInt32(12)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 11:
        self.add_item().TryMerge(d)
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    cnt=0
    for e in self.item_:
      elm=""
      if printElemNumber: elm="(%d)" % cnt
      res+=prefix+("Item%s {\n" % elm)
      res+=e.__str__(prefix + "  ", printElemNumber)
      res+=prefix+"}\n"
      cnt+=1
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  kItemGroup = 1
  kItemkey = 2
  kItemvalue = 3
  kItemflags = 4
  kItemcas_id = 5
  kItemexpires_in_seconds = 6

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "Item",
    2: "key",
    3: "value",
    4: "flags",
    5: "cas_id",
    6: "expires_in_seconds",
  }, 6)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.STARTGROUP,
    2: ProtocolBuffer.Encoder.STRING,
    3: ProtocolBuffer.Encoder.STRING,
    4: ProtocolBuffer.Encoder.FLOAT,
    5: ProtocolBuffer.Encoder.DOUBLE,
    6: ProtocolBuffer.Encoder.NUMERIC,
  }, 6, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("Wi5hcHBob3N0aW5nL2FwaS9tZW1jYWNoZS9tZW1jYWNoZV9zZXJ2aWNlLnByb3RvCh5hcHBob3N0aW5nLk1lbWNhY2hlR2V0UmVzcG9uc2UTGgRJdGVtIAEoAzAKOAMUExoISXRlbS5rZXkgAigCMAk4AmAAFBMaCkl0ZW0udmFsdWUgAygCMAk4AmAAFBMaCkl0ZW0uZmxhZ3MgBCgFMAc4AWAAFBMaC0l0ZW0uY2FzX2lkIAUoATAGOAFgABQTGhdJdGVtLmV4cGlyZXNfaW5fc2Vjb25kcyAGKAAwBTgBYAAUwgEfYXBwaG9zdGluZy5NZW1jYWNoZVNlcnZpY2VFcnJvcg=="))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class MemcacheSetRequest_Item(ProtocolBuffer.ProtocolMessage):
  has_key_ = 0
  key_ = ""
  has_value_ = 0
  value_ = ""
  has_flags_ = 0
  flags_ = 0
  has_set_policy_ = 0
  set_policy_ = 1
  has_expiration_time_ = 0
  expiration_time_ = 0
  has_cas_id_ = 0
  cas_id_ = 0
  has_for_cas_ = 0
  for_cas_ = 0

  def __init__(self, contents=None):
    if contents is not None: self.MergeFromString(contents)

  def key(self): return self.key_

  def set_key(self, x):
    self.has_key_ = 1
    self.key_ = x

  def clear_key(self):
    if self.has_key_:
      self.has_key_ = 0
      self.key_ = ""

  def has_key(self): return self.has_key_

  def value(self): return self.value_

  def set_value(self, x):
    self.has_value_ = 1
    self.value_ = x

  def clear_value(self):
    if self.has_value_:
      self.has_value_ = 0
      self.value_ = ""

  def has_value(self): return self.has_value_

  def flags(self): return self.flags_

  def set_flags(self, x):
    self.has_flags_ = 1
    self.flags_ = x

  def clear_flags(self):
    if self.has_flags_:
      self.has_flags_ = 0
      self.flags_ = 0

  def has_flags(self): return self.has_flags_

  def set_policy(self): return self.set_policy_

  def set_set_policy(self, x):
    self.has_set_policy_ = 1
    self.set_policy_ = x

  def clear_set_policy(self):
    if self.has_set_policy_:
      self.has_set_policy_ = 0
      self.set_policy_ = 1

  def has_set_policy(self): return self.has_set_policy_

  def expiration_time(self): return self.expiration_time_

  def set_expiration_time(self, x):
    self.has_expiration_time_ = 1
    self.expiration_time_ = x

  def clear_expiration_time(self):
    if self.has_expiration_time_:
      self.has_expiration_time_ = 0
      self.expiration_time_ = 0

  def has_expiration_time(self): return self.has_expiration_time_

  def cas_id(self): return self.cas_id_

  def set_cas_id(self, x):
    self.has_cas_id_ = 1
    self.cas_id_ = x

  def clear_cas_id(self):
    if self.has_cas_id_:
      self.has_cas_id_ = 0
      self.cas_id_ = 0

  def has_cas_id(self): return self.has_cas_id_

  def for_cas(self): return self.for_cas_

  def set_for_cas(self, x):
    self.has_for_cas_ = 1
    self.for_cas_ = x

  def clear_for_cas(self):
    if self.has_for_cas_:
      self.has_for_cas_ = 0
      self.for_cas_ = 0

  def has_for_cas(self): return self.has_for_cas_


  def MergeFrom(self, x):
    assert x is not self
    if (x.has_key()): self.set_key(x.key())
    if (x.has_value()): self.set_value(x.value())
    if (x.has_flags()): self.set_flags(x.flags())
    if (x.has_set_policy()): self.set_set_policy(x.set_policy())
    if (x.has_expiration_time()): self.set_expiration_time(x.expiration_time())
    if (x.has_cas_id()): self.set_cas_id(x.cas_id())
    if (x.has_for_cas()): self.set_for_cas(x.for_cas())

  def Equals(self, x):
    if x is self: return 1
    if self.has_key_ != x.has_key_: return 0
    if self.has_key_ and self.key_ != x.key_: return 0
    if self.has_value_ != x.has_value_: return 0
    if self.has_value_ and self.value_ != x.value_: return 0
    if self.has_flags_ != x.has_flags_: return 0
    if self.has_flags_ and self.flags_ != x.flags_: return 0
    if self.has_set_policy_ != x.has_set_policy_: return 0
    if self.has_set_policy_ and self.set_policy_ != x.set_policy_: return 0
    if self.has_expiration_time_ != x.has_expiration_time_: return 0
    if self.has_expiration_time_ and self.expiration_time_ != x.expiration_time_: return 0
    if self.has_cas_id_ != x.has_cas_id_: return 0
    if self.has_cas_id_ and self.cas_id_ != x.cas_id_: return 0
    if self.has_for_cas_ != x.has_for_cas_: return 0
    if self.has_for_cas_ and self.for_cas_ != x.for_cas_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    if (not self.has_key_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: key not set.')
    if (not self.has_value_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: value not set.')
    return initialized

  def ByteSize(self):
    n = 0
    n += self.lengthString(len(self.key_))
    n += self.lengthString(len(self.value_))
    if (self.has_flags_): n += 5
    if (self.has_set_policy_): n += 1 + self.lengthVarInt64(self.set_policy_)
    if (self.has_expiration_time_): n += 5
    if (self.has_cas_id_): n += 9
    if (self.has_for_cas_): n += 2
    return n + 2

  def ByteSizePartial(self):
    n = 0
    if (self.has_key_):
      n += 1
      n += self.lengthString(len(self.key_))
    if (self.has_value_):
      n += 1
      n += self.lengthString(len(self.value_))
    if (self.has_flags_): n += 5
    if (self.has_set_policy_): n += 1 + self.lengthVarInt64(self.set_policy_)
    if (self.has_expiration_time_): n += 5
    if (self.has_cas_id_): n += 9
    if (self.has_for_cas_): n += 2
    return n

  def Clear(self):
    self.clear_key()
    self.clear_value()
    self.clear_flags()
    self.clear_set_policy()
    self.clear_expiration_time()
    self.clear_cas_id()
    self.clear_for_cas()

  def OutputUnchecked(self, out):
    out.putVarInt32(18)
    out.putPrefixedString(self.key_)
    out.putVarInt32(26)
    out.putPrefixedString(self.value_)
    if (self.has_flags_):
      out.putVarInt32(37)
      out.put32(self.flags_)
    if (self.has_set_policy_):
      out.putVarInt32(40)
      out.putVarInt32(self.set_policy_)
    if (self.has_expiration_time_):
      out.putVarInt32(53)
      out.put32(self.expiration_time_)
    if (self.has_cas_id_):
      out.putVarInt32(65)
      out.put64(self.cas_id_)
    if (self.has_for_cas_):
      out.putVarInt32(72)
      out.putBoolean(self.for_cas_)

  def OutputPartial(self, out):
    if (self.has_key_):
      out.putVarInt32(18)
      out.putPrefixedString(self.key_)
    if (self.has_value_):
      out.putVarInt32(26)
      out.putPrefixedString(self.value_)
    if (self.has_flags_):
      out.putVarInt32(37)
      out.put32(self.flags_)
    if (self.has_set_policy_):
      out.putVarInt32(40)
      out.putVarInt32(self.set_policy_)
    if (self.has_expiration_time_):
      out.putVarInt32(53)
      out.put32(self.expiration_time_)
    if (self.has_cas_id_):
      out.putVarInt32(65)
      out.put64(self.cas_id_)
    if (self.has_for_cas_):
      out.putVarInt32(72)
      out.putBoolean(self.for_cas_)

  def TryMerge(self, d):
    while 1:
      tt = d.getVarInt32()
      if tt == 12: break
      if tt == 18:
        self.set_key(d.getPrefixedString())
        continue
      if tt == 26:
        self.set_value(d.getPrefixedString())
        continue
      if tt == 37:
        self.set_flags(d.get32())
        continue
      if tt == 40:
        self.set_set_policy(d.getVarInt32())
        continue
      if tt == 53:
        self.set_expiration_time(d.get32())
        continue
      if tt == 65:
        self.set_cas_id(d.get64())
        continue
      if tt == 72:
        self.set_for_cas(d.getBoolean())
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    if self.has_key_: res+=prefix+("key: %s\n" % self.DebugFormatString(self.key_))
    if self.has_value_: res+=prefix+("value: %s\n" % self.DebugFormatString(self.value_))
    if self.has_flags_: res+=prefix+("flags: %s\n" % self.DebugFormatFixed32(self.flags_))
    if self.has_set_policy_: res+=prefix+("set_policy: %s\n" % self.DebugFormatInt32(self.set_policy_))
    if self.has_expiration_time_: res+=prefix+("expiration_time: %s\n" % self.DebugFormatFixed32(self.expiration_time_))
    if self.has_cas_id_: res+=prefix+("cas_id: %s\n" % self.DebugFormatFixed64(self.cas_id_))
    if self.has_for_cas_: res+=prefix+("for_cas: %s\n" % self.DebugFormatBool(self.for_cas_))
    return res

class MemcacheSetRequest(ProtocolBuffer.ProtocolMessage):


  SET          =    1
  ADD          =    2
  REPLACE      =    3
  CAS          =    4

  _SetPolicy_NAMES = {
    1: "SET",
    2: "ADD",
    3: "REPLACE",
    4: "CAS",
  }

  def SetPolicy_Name(cls, x): return cls._SetPolicy_NAMES.get(x, "")
  SetPolicy_Name = classmethod(SetPolicy_Name)

  has_name_space_ = 0
  name_space_ = ""
  has_override_ = 0
  override_ = None

  def __init__(self, contents=None):
    self.item_ = []
    self.lazy_init_lock_ = thread.allocate_lock()
    if contents is not None: self.MergeFromString(contents)

  def item_size(self): return len(self.item_)
  def item_list(self): return self.item_

  def item(self, i):
    return self.item_[i]

  def mutable_item(self, i):
    return self.item_[i]

  def add_item(self):
    x = MemcacheSetRequest_Item()
    self.item_.append(x)
    return x

  def clear_item(self):
    self.item_ = []
  def name_space(self): return self.name_space_

  def set_name_space(self, x):
    self.has_name_space_ = 1
    self.name_space_ = x

  def clear_name_space(self):
    if self.has_name_space_:
      self.has_name_space_ = 0
      self.name_space_ = ""

  def has_name_space(self): return self.has_name_space_

  def override(self):
    if self.override_ is None:
      self.lazy_init_lock_.acquire()
      try:
        if self.override_ is None: self.override_ = AppOverride()
      finally:
        self.lazy_init_lock_.release()
    return self.override_

  def mutable_override(self): self.has_override_ = 1; return self.override()

  def clear_override(self):

    if self.has_override_:
      self.has_override_ = 0;
      if self.override_ is not None: self.override_.Clear()

  def has_override(self): return self.has_override_


  def MergeFrom(self, x):
    assert x is not self
    for i in xrange(x.item_size()): self.add_item().CopyFrom(x.item(i))
    if (x.has_name_space()): self.set_name_space(x.name_space())
    if (x.has_override()): self.mutable_override().MergeFrom(x.override())

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.MemcacheSetRequest', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.MemcacheSetRequest')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.MemcacheSetRequest')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.MemcacheSetRequest', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.MemcacheSetRequest', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.MemcacheSetRequest', s)


  def Equals(self, x):
    if x is self: return 1
    if len(self.item_) != len(x.item_): return 0
    for e1, e2 in zip(self.item_, x.item_):
      if e1 != e2: return 0
    if self.has_name_space_ != x.has_name_space_: return 0
    if self.has_name_space_ and self.name_space_ != x.name_space_: return 0
    if self.has_override_ != x.has_override_: return 0
    if self.has_override_ and self.override_ != x.override_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    for p in self.item_:
      if not p.IsInitialized(debug_strs): initialized=0
    if (self.has_override_ and not self.override_.IsInitialized(debug_strs)): initialized = 0
    return initialized

  def ByteSize(self):
    n = 0
    n += 2 * len(self.item_)
    for i in xrange(len(self.item_)): n += self.item_[i].ByteSize()
    if (self.has_name_space_): n += 1 + self.lengthString(len(self.name_space_))
    if (self.has_override_): n += 1 + self.lengthString(self.override_.ByteSize())
    return n

  def ByteSizePartial(self):
    n = 0
    n += 2 * len(self.item_)
    for i in xrange(len(self.item_)): n += self.item_[i].ByteSizePartial()
    if (self.has_name_space_): n += 1 + self.lengthString(len(self.name_space_))
    if (self.has_override_): n += 1 + self.lengthString(self.override_.ByteSizePartial())
    return n

  def Clear(self):
    self.clear_item()
    self.clear_name_space()
    self.clear_override()

  def OutputUnchecked(self, out):
    for i in xrange(len(self.item_)):
      out.putVarInt32(11)
      self.item_[i].OutputUnchecked(out)
      out.putVarInt32(12)
    if (self.has_name_space_):
      out.putVarInt32(58)
      out.putPrefixedString(self.name_space_)
    if (self.has_override_):
      out.putVarInt32(82)
      out.putVarInt32(self.override_.ByteSize())
      self.override_.OutputUnchecked(out)

  def OutputPartial(self, out):
    for i in xrange(len(self.item_)):
      out.putVarInt32(11)
      self.item_[i].OutputPartial(out)
      out.putVarInt32(12)
    if (self.has_name_space_):
      out.putVarInt32(58)
      out.putPrefixedString(self.name_space_)
    if (self.has_override_):
      out.putVarInt32(82)
      out.putVarInt32(self.override_.ByteSizePartial())
      self.override_.OutputPartial(out)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 11:
        self.add_item().TryMerge(d)
        continue
      if tt == 58:
        self.set_name_space(d.getPrefixedString())
        continue
      if tt == 82:
        length = d.getVarInt32()
        tmp = ProtocolBuffer.Decoder(d.buffer(), d.pos(), d.pos() + length)
        d.skip(length)
        self.mutable_override().TryMerge(tmp)
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    cnt=0
    for e in self.item_:
      elm=""
      if printElemNumber: elm="(%d)" % cnt
      res+=prefix+("Item%s {\n" % elm)
      res+=e.__str__(prefix + "  ", printElemNumber)
      res+=prefix+"}\n"
      cnt+=1
    if self.has_name_space_: res+=prefix+("name_space: %s\n" % self.DebugFormatString(self.name_space_))
    if self.has_override_:
      res+=prefix+"override <\n"
      res+=self.override_.__str__(prefix + "  ", printElemNumber)
      res+=prefix+">\n"
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  kItemGroup = 1
  kItemkey = 2
  kItemvalue = 3
  kItemflags = 4
  kItemset_policy = 5
  kItemexpiration_time = 6
  kItemcas_id = 8
  kItemfor_cas = 9
  kname_space = 7
  koverride = 10

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "Item",
    2: "key",
    3: "value",
    4: "flags",
    5: "set_policy",
    6: "expiration_time",
    7: "name_space",
    8: "cas_id",
    9: "for_cas",
    10: "override",
  }, 10)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.STARTGROUP,
    2: ProtocolBuffer.Encoder.STRING,
    3: ProtocolBuffer.Encoder.STRING,
    4: ProtocolBuffer.Encoder.FLOAT,
    5: ProtocolBuffer.Encoder.NUMERIC,
    6: ProtocolBuffer.Encoder.FLOAT,
    7: ProtocolBuffer.Encoder.STRING,
    8: ProtocolBuffer.Encoder.DOUBLE,
    9: ProtocolBuffer.Encoder.NUMERIC,
    10: ProtocolBuffer.Encoder.STRING,
  }, 10, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("Wi5hcHBob3N0aW5nL2FwaS9tZW1jYWNoZS9tZW1jYWNoZV9zZXJ2aWNlLnByb3RvCh1hcHBob3N0aW5nLk1lbWNhY2hlU2V0UmVxdWVzdBMaBEl0ZW0gASgDMAo4AxQTGghJdGVtLmtleSACKAIwCTgCYAAUExoKSXRlbS52YWx1ZSADKAIwCTgCYAAUExoKSXRlbS5mbGFncyAEKAUwBzgBYAAUExoPSXRlbS5zZXRfcG9saWN5IAUoADAFOAFCATFgAGgAowGqAQdkZWZhdWx0sgEDU0VUpAEUExoUSXRlbS5leHBpcmF0aW9uX3RpbWUgBigFMAc4AUIBMGAAowGqAQdkZWZhdWx0sgEBMKQBFBMaC0l0ZW0uY2FzX2lkIAgoATAGOAFgABQTGgxJdGVtLmZvcl9jYXMgCSgAMAg4AWAAFBMaCm5hbWVfc3BhY2UgBygCMAk4AUIAowGqAQdkZWZhdWx0sgECIiKkARQTGghvdmVycmlkZSAKKAIwCzgBShZhcHBob3N0aW5nLkFwcE92ZXJyaWRlFHN6CVNldFBvbGljeYsBkgEDU0VUmAEBjAGLAZIBA0FERJgBAowBiwGSAQdSRVBMQUNFmAEDjAGLAZIBA0NBU5gBBIwBdMIBH2FwcGhvc3RpbmcuTWVtY2FjaGVTZXJ2aWNlRXJyb3I="))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class MemcacheSetResponse(ProtocolBuffer.ProtocolMessage):


  STORED       =    1
  NOT_STORED   =    2
  ERROR        =    3
  EXISTS       =    4

  _SetStatusCode_NAMES = {
    1: "STORED",
    2: "NOT_STORED",
    3: "ERROR",
    4: "EXISTS",
  }

  def SetStatusCode_Name(cls, x): return cls._SetStatusCode_NAMES.get(x, "")
  SetStatusCode_Name = classmethod(SetStatusCode_Name)


  def __init__(self, contents=None):
    self.set_status_ = []
    if contents is not None: self.MergeFromString(contents)

  def set_status_size(self): return len(self.set_status_)
  def set_status_list(self): return self.set_status_

  def set_status(self, i):
    return self.set_status_[i]

  def set_set_status(self, i, x):
    self.set_status_[i] = x

  def add_set_status(self, x):
    self.set_status_.append(x)

  def clear_set_status(self):
    self.set_status_ = []


  def MergeFrom(self, x):
    assert x is not self
    for i in xrange(x.set_status_size()): self.add_set_status(x.set_status(i))

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.MemcacheSetResponse', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.MemcacheSetResponse')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.MemcacheSetResponse')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.MemcacheSetResponse', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.MemcacheSetResponse', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.MemcacheSetResponse', s)


  def Equals(self, x):
    if x is self: return 1
    if len(self.set_status_) != len(x.set_status_): return 0
    for e1, e2 in zip(self.set_status_, x.set_status_):
      if e1 != e2: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    return initialized

  def ByteSize(self):
    n = 0
    n += 1 * len(self.set_status_)
    for i in xrange(len(self.set_status_)): n += self.lengthVarInt64(self.set_status_[i])
    return n

  def ByteSizePartial(self):
    n = 0
    n += 1 * len(self.set_status_)
    for i in xrange(len(self.set_status_)): n += self.lengthVarInt64(self.set_status_[i])
    return n

  def Clear(self):
    self.clear_set_status()

  def OutputUnchecked(self, out):
    for i in xrange(len(self.set_status_)):
      out.putVarInt32(8)
      out.putVarInt32(self.set_status_[i])

  def OutputPartial(self, out):
    for i in xrange(len(self.set_status_)):
      out.putVarInt32(8)
      out.putVarInt32(self.set_status_[i])

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 8:
        self.add_set_status(d.getVarInt32())
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    cnt=0
    for e in self.set_status_:
      elm=""
      if printElemNumber: elm="(%d)" % cnt
      res+=prefix+("set_status%s: %s\n" % (elm, self.DebugFormatInt32(e)))
      cnt+=1
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  kset_status = 1

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "set_status",
  }, 1)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.NUMERIC,
  }, 1, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("Wi5hcHBob3N0aW5nL2FwaS9tZW1jYWNoZS9tZW1jYWNoZV9zZXJ2aWNlLnByb3RvCh5hcHBob3N0aW5nLk1lbWNhY2hlU2V0UmVzcG9uc2UTGgpzZXRfc3RhdHVzIAEoADAFOANoABRzeg1TZXRTdGF0dXNDb2RliwGSAQZTVE9SRUSYAQGMAYsBkgEKTk9UX1NUT1JFRJgBAowBiwGSAQVFUlJPUpgBA4wBiwGSAQZFWElTVFOYAQSMAXTCAR9hcHBob3N0aW5nLk1lbWNhY2hlU2VydmljZUVycm9y"))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class MemcacheDeleteRequest_Item(ProtocolBuffer.ProtocolMessage):
  has_key_ = 0
  key_ = ""
  has_delete_time_ = 0
  delete_time_ = 0

  def __init__(self, contents=None):
    if contents is not None: self.MergeFromString(contents)

  def key(self): return self.key_

  def set_key(self, x):
    self.has_key_ = 1
    self.key_ = x

  def clear_key(self):
    if self.has_key_:
      self.has_key_ = 0
      self.key_ = ""

  def has_key(self): return self.has_key_

  def delete_time(self): return self.delete_time_

  def set_delete_time(self, x):
    self.has_delete_time_ = 1
    self.delete_time_ = x

  def clear_delete_time(self):
    if self.has_delete_time_:
      self.has_delete_time_ = 0
      self.delete_time_ = 0

  def has_delete_time(self): return self.has_delete_time_


  def MergeFrom(self, x):
    assert x is not self
    if (x.has_key()): self.set_key(x.key())
    if (x.has_delete_time()): self.set_delete_time(x.delete_time())

  def Equals(self, x):
    if x is self: return 1
    if self.has_key_ != x.has_key_: return 0
    if self.has_key_ and self.key_ != x.key_: return 0
    if self.has_delete_time_ != x.has_delete_time_: return 0
    if self.has_delete_time_ and self.delete_time_ != x.delete_time_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    if (not self.has_key_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: key not set.')
    return initialized

  def ByteSize(self):
    n = 0
    n += self.lengthString(len(self.key_))
    if (self.has_delete_time_): n += 5
    return n + 1

  def ByteSizePartial(self):
    n = 0
    if (self.has_key_):
      n += 1
      n += self.lengthString(len(self.key_))
    if (self.has_delete_time_): n += 5
    return n

  def Clear(self):
    self.clear_key()
    self.clear_delete_time()

  def OutputUnchecked(self, out):
    out.putVarInt32(18)
    out.putPrefixedString(self.key_)
    if (self.has_delete_time_):
      out.putVarInt32(29)
      out.put32(self.delete_time_)

  def OutputPartial(self, out):
    if (self.has_key_):
      out.putVarInt32(18)
      out.putPrefixedString(self.key_)
    if (self.has_delete_time_):
      out.putVarInt32(29)
      out.put32(self.delete_time_)

  def TryMerge(self, d):
    while 1:
      tt = d.getVarInt32()
      if tt == 12: break
      if tt == 18:
        self.set_key(d.getPrefixedString())
        continue
      if tt == 29:
        self.set_delete_time(d.get32())
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    if self.has_key_: res+=prefix+("key: %s\n" % self.DebugFormatString(self.key_))
    if self.has_delete_time_: res+=prefix+("delete_time: %s\n" % self.DebugFormatFixed32(self.delete_time_))
    return res

class MemcacheDeleteRequest(ProtocolBuffer.ProtocolMessage):
  has_name_space_ = 0
  name_space_ = ""
  has_override_ = 0
  override_ = None

  def __init__(self, contents=None):
    self.item_ = []
    self.lazy_init_lock_ = thread.allocate_lock()
    if contents is not None: self.MergeFromString(contents)

  def item_size(self): return len(self.item_)
  def item_list(self): return self.item_

  def item(self, i):
    return self.item_[i]

  def mutable_item(self, i):
    return self.item_[i]

  def add_item(self):
    x = MemcacheDeleteRequest_Item()
    self.item_.append(x)
    return x

  def clear_item(self):
    self.item_ = []
  def name_space(self): return self.name_space_

  def set_name_space(self, x):
    self.has_name_space_ = 1
    self.name_space_ = x

  def clear_name_space(self):
    if self.has_name_space_:
      self.has_name_space_ = 0
      self.name_space_ = ""

  def has_name_space(self): return self.has_name_space_

  def override(self):
    if self.override_ is None:
      self.lazy_init_lock_.acquire()
      try:
        if self.override_ is None: self.override_ = AppOverride()
      finally:
        self.lazy_init_lock_.release()
    return self.override_

  def mutable_override(self): self.has_override_ = 1; return self.override()

  def clear_override(self):

    if self.has_override_:
      self.has_override_ = 0;
      if self.override_ is not None: self.override_.Clear()

  def has_override(self): return self.has_override_


  def MergeFrom(self, x):
    assert x is not self
    for i in xrange(x.item_size()): self.add_item().CopyFrom(x.item(i))
    if (x.has_name_space()): self.set_name_space(x.name_space())
    if (x.has_override()): self.mutable_override().MergeFrom(x.override())

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.MemcacheDeleteRequest', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.MemcacheDeleteRequest')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.MemcacheDeleteRequest')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.MemcacheDeleteRequest', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.MemcacheDeleteRequest', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.MemcacheDeleteRequest', s)


  def Equals(self, x):
    if x is self: return 1
    if len(self.item_) != len(x.item_): return 0
    for e1, e2 in zip(self.item_, x.item_):
      if e1 != e2: return 0
    if self.has_name_space_ != x.has_name_space_: return 0
    if self.has_name_space_ and self.name_space_ != x.name_space_: return 0
    if self.has_override_ != x.has_override_: return 0
    if self.has_override_ and self.override_ != x.override_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    for p in self.item_:
      if not p.IsInitialized(debug_strs): initialized=0
    if (self.has_override_ and not self.override_.IsInitialized(debug_strs)): initialized = 0
    return initialized

  def ByteSize(self):
    n = 0
    n += 2 * len(self.item_)
    for i in xrange(len(self.item_)): n += self.item_[i].ByteSize()
    if (self.has_name_space_): n += 1 + self.lengthString(len(self.name_space_))
    if (self.has_override_): n += 1 + self.lengthString(self.override_.ByteSize())
    return n

  def ByteSizePartial(self):
    n = 0
    n += 2 * len(self.item_)
    for i in xrange(len(self.item_)): n += self.item_[i].ByteSizePartial()
    if (self.has_name_space_): n += 1 + self.lengthString(len(self.name_space_))
    if (self.has_override_): n += 1 + self.lengthString(self.override_.ByteSizePartial())
    return n

  def Clear(self):
    self.clear_item()
    self.clear_name_space()
    self.clear_override()

  def OutputUnchecked(self, out):
    for i in xrange(len(self.item_)):
      out.putVarInt32(11)
      self.item_[i].OutputUnchecked(out)
      out.putVarInt32(12)
    if (self.has_name_space_):
      out.putVarInt32(34)
      out.putPrefixedString(self.name_space_)
    if (self.has_override_):
      out.putVarInt32(42)
      out.putVarInt32(self.override_.ByteSize())
      self.override_.OutputUnchecked(out)

  def OutputPartial(self, out):
    for i in xrange(len(self.item_)):
      out.putVarInt32(11)
      self.item_[i].OutputPartial(out)
      out.putVarInt32(12)
    if (self.has_name_space_):
      out.putVarInt32(34)
      out.putPrefixedString(self.name_space_)
    if (self.has_override_):
      out.putVarInt32(42)
      out.putVarInt32(self.override_.ByteSizePartial())
      self.override_.OutputPartial(out)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 11:
        self.add_item().TryMerge(d)
        continue
      if tt == 34:
        self.set_name_space(d.getPrefixedString())
        continue
      if tt == 42:
        length = d.getVarInt32()
        tmp = ProtocolBuffer.Decoder(d.buffer(), d.pos(), d.pos() + length)
        d.skip(length)
        self.mutable_override().TryMerge(tmp)
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    cnt=0
    for e in self.item_:
      elm=""
      if printElemNumber: elm="(%d)" % cnt
      res+=prefix+("Item%s {\n" % elm)
      res+=e.__str__(prefix + "  ", printElemNumber)
      res+=prefix+"}\n"
      cnt+=1
    if self.has_name_space_: res+=prefix+("name_space: %s\n" % self.DebugFormatString(self.name_space_))
    if self.has_override_:
      res+=prefix+"override <\n"
      res+=self.override_.__str__(prefix + "  ", printElemNumber)
      res+=prefix+">\n"
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  kItemGroup = 1
  kItemkey = 2
  kItemdelete_time = 3
  kname_space = 4
  koverride = 5

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "Item",
    2: "key",
    3: "delete_time",
    4: "name_space",
    5: "override",
  }, 5)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.STARTGROUP,
    2: ProtocolBuffer.Encoder.STRING,
    3: ProtocolBuffer.Encoder.FLOAT,
    4: ProtocolBuffer.Encoder.STRING,
    5: ProtocolBuffer.Encoder.STRING,
  }, 5, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("Wi5hcHBob3N0aW5nL2FwaS9tZW1jYWNoZS9tZW1jYWNoZV9zZXJ2aWNlLnByb3RvCiBhcHBob3N0aW5nLk1lbWNhY2hlRGVsZXRlUmVxdWVzdBMaBEl0ZW0gASgDMAo4AxQTGghJdGVtLmtleSACKAIwCTgCYAAUExoQSXRlbS5kZWxldGVfdGltZSADKAUwBzgBQgEwYACjAaoBB2RlZmF1bHSyAQEwpAEUExoKbmFtZV9zcGFjZSAEKAIwCTgBQgCjAaoBB2RlZmF1bHSyAQIiIqQBFBMaCG92ZXJyaWRlIAUoAjALOAFKFmFwcGhvc3RpbmcuQXBwT3ZlcnJpZGUUwgEfYXBwaG9zdGluZy5NZW1jYWNoZVNlcnZpY2VFcnJvcg=="))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class MemcacheDeleteResponse(ProtocolBuffer.ProtocolMessage):


  DELETED      =    1
  NOT_FOUND    =    2

  _DeleteStatusCode_NAMES = {
    1: "DELETED",
    2: "NOT_FOUND",
  }

  def DeleteStatusCode_Name(cls, x): return cls._DeleteStatusCode_NAMES.get(x, "")
  DeleteStatusCode_Name = classmethod(DeleteStatusCode_Name)


  def __init__(self, contents=None):
    self.delete_status_ = []
    if contents is not None: self.MergeFromString(contents)

  def delete_status_size(self): return len(self.delete_status_)
  def delete_status_list(self): return self.delete_status_

  def delete_status(self, i):
    return self.delete_status_[i]

  def set_delete_status(self, i, x):
    self.delete_status_[i] = x

  def add_delete_status(self, x):
    self.delete_status_.append(x)

  def clear_delete_status(self):
    self.delete_status_ = []


  def MergeFrom(self, x):
    assert x is not self
    for i in xrange(x.delete_status_size()): self.add_delete_status(x.delete_status(i))

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.MemcacheDeleteResponse', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.MemcacheDeleteResponse')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.MemcacheDeleteResponse')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.MemcacheDeleteResponse', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.MemcacheDeleteResponse', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.MemcacheDeleteResponse', s)


  def Equals(self, x):
    if x is self: return 1
    if len(self.delete_status_) != len(x.delete_status_): return 0
    for e1, e2 in zip(self.delete_status_, x.delete_status_):
      if e1 != e2: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    return initialized

  def ByteSize(self):
    n = 0
    n += 1 * len(self.delete_status_)
    for i in xrange(len(self.delete_status_)): n += self.lengthVarInt64(self.delete_status_[i])
    return n

  def ByteSizePartial(self):
    n = 0
    n += 1 * len(self.delete_status_)
    for i in xrange(len(self.delete_status_)): n += self.lengthVarInt64(self.delete_status_[i])
    return n

  def Clear(self):
    self.clear_delete_status()

  def OutputUnchecked(self, out):
    for i in xrange(len(self.delete_status_)):
      out.putVarInt32(8)
      out.putVarInt32(self.delete_status_[i])

  def OutputPartial(self, out):
    for i in xrange(len(self.delete_status_)):
      out.putVarInt32(8)
      out.putVarInt32(self.delete_status_[i])

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 8:
        self.add_delete_status(d.getVarInt32())
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    cnt=0
    for e in self.delete_status_:
      elm=""
      if printElemNumber: elm="(%d)" % cnt
      res+=prefix+("delete_status%s: %s\n" % (elm, self.DebugFormatInt32(e)))
      cnt+=1
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  kdelete_status = 1

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "delete_status",
  }, 1)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.NUMERIC,
  }, 1, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("Wi5hcHBob3N0aW5nL2FwaS9tZW1jYWNoZS9tZW1jYWNoZV9zZXJ2aWNlLnByb3RvCiFhcHBob3N0aW5nLk1lbWNhY2hlRGVsZXRlUmVzcG9uc2UTGg1kZWxldGVfc3RhdHVzIAEoADAFOANoABRzehBEZWxldGVTdGF0dXNDb2RliwGSAQdERUxFVEVEmAEBjAGLAZIBCU5PVF9GT1VORJgBAowBdMIBH2FwcGhvc3RpbmcuTWVtY2FjaGVTZXJ2aWNlRXJyb3I="))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class MemcacheIncrementRequest(ProtocolBuffer.ProtocolMessage):


  INCREMENT    =    1
  DECREMENT    =    2

  _Direction_NAMES = {
    1: "INCREMENT",
    2: "DECREMENT",
  }

  def Direction_Name(cls, x): return cls._Direction_NAMES.get(x, "")
  Direction_Name = classmethod(Direction_Name)

  has_key_ = 0
  key_ = ""
  has_name_space_ = 0
  name_space_ = ""
  has_delta_ = 0
  delta_ = 1
  has_direction_ = 0
  direction_ = 1
  has_initial_value_ = 0
  initial_value_ = 0
  has_initial_flags_ = 0
  initial_flags_ = 0
  has_override_ = 0
  override_ = None

  def __init__(self, contents=None):
    self.lazy_init_lock_ = thread.allocate_lock()
    if contents is not None: self.MergeFromString(contents)

  def key(self): return self.key_

  def set_key(self, x):
    self.has_key_ = 1
    self.key_ = x

  def clear_key(self):
    if self.has_key_:
      self.has_key_ = 0
      self.key_ = ""

  def has_key(self): return self.has_key_

  def name_space(self): return self.name_space_

  def set_name_space(self, x):
    self.has_name_space_ = 1
    self.name_space_ = x

  def clear_name_space(self):
    if self.has_name_space_:
      self.has_name_space_ = 0
      self.name_space_ = ""

  def has_name_space(self): return self.has_name_space_

  def delta(self): return self.delta_

  def set_delta(self, x):
    self.has_delta_ = 1
    self.delta_ = x

  def clear_delta(self):
    if self.has_delta_:
      self.has_delta_ = 0
      self.delta_ = 1

  def has_delta(self): return self.has_delta_

  def direction(self): return self.direction_

  def set_direction(self, x):
    self.has_direction_ = 1
    self.direction_ = x

  def clear_direction(self):
    if self.has_direction_:
      self.has_direction_ = 0
      self.direction_ = 1

  def has_direction(self): return self.has_direction_

  def initial_value(self): return self.initial_value_

  def set_initial_value(self, x):
    self.has_initial_value_ = 1
    self.initial_value_ = x

  def clear_initial_value(self):
    if self.has_initial_value_:
      self.has_initial_value_ = 0
      self.initial_value_ = 0

  def has_initial_value(self): return self.has_initial_value_

  def initial_flags(self): return self.initial_flags_

  def set_initial_flags(self, x):
    self.has_initial_flags_ = 1
    self.initial_flags_ = x

  def clear_initial_flags(self):
    if self.has_initial_flags_:
      self.has_initial_flags_ = 0
      self.initial_flags_ = 0

  def has_initial_flags(self): return self.has_initial_flags_

  def override(self):
    if self.override_ is None:
      self.lazy_init_lock_.acquire()
      try:
        if self.override_ is None: self.override_ = AppOverride()
      finally:
        self.lazy_init_lock_.release()
    return self.override_

  def mutable_override(self): self.has_override_ = 1; return self.override()

  def clear_override(self):

    if self.has_override_:
      self.has_override_ = 0;
      if self.override_ is not None: self.override_.Clear()

  def has_override(self): return self.has_override_


  def MergeFrom(self, x):
    assert x is not self
    if (x.has_key()): self.set_key(x.key())
    if (x.has_name_space()): self.set_name_space(x.name_space())
    if (x.has_delta()): self.set_delta(x.delta())
    if (x.has_direction()): self.set_direction(x.direction())
    if (x.has_initial_value()): self.set_initial_value(x.initial_value())
    if (x.has_initial_flags()): self.set_initial_flags(x.initial_flags())
    if (x.has_override()): self.mutable_override().MergeFrom(x.override())

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.MemcacheIncrementRequest', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.MemcacheIncrementRequest')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.MemcacheIncrementRequest')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.MemcacheIncrementRequest', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.MemcacheIncrementRequest', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.MemcacheIncrementRequest', s)


  def Equals(self, x):
    if x is self: return 1
    if self.has_key_ != x.has_key_: return 0
    if self.has_key_ and self.key_ != x.key_: return 0
    if self.has_name_space_ != x.has_name_space_: return 0
    if self.has_name_space_ and self.name_space_ != x.name_space_: return 0
    if self.has_delta_ != x.has_delta_: return 0
    if self.has_delta_ and self.delta_ != x.delta_: return 0
    if self.has_direction_ != x.has_direction_: return 0
    if self.has_direction_ and self.direction_ != x.direction_: return 0
    if self.has_initial_value_ != x.has_initial_value_: return 0
    if self.has_initial_value_ and self.initial_value_ != x.initial_value_: return 0
    if self.has_initial_flags_ != x.has_initial_flags_: return 0
    if self.has_initial_flags_ and self.initial_flags_ != x.initial_flags_: return 0
    if self.has_override_ != x.has_override_: return 0
    if self.has_override_ and self.override_ != x.override_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    if (not self.has_key_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: key not set.')
    if (self.has_override_ and not self.override_.IsInitialized(debug_strs)): initialized = 0
    return initialized

  def ByteSize(self):
    n = 0
    n += self.lengthString(len(self.key_))
    if (self.has_name_space_): n += 1 + self.lengthString(len(self.name_space_))
    if (self.has_delta_): n += 1 + self.lengthVarInt64(self.delta_)
    if (self.has_direction_): n += 1 + self.lengthVarInt64(self.direction_)
    if (self.has_initial_value_): n += 1 + self.lengthVarInt64(self.initial_value_)
    if (self.has_initial_flags_): n += 5
    if (self.has_override_): n += 1 + self.lengthString(self.override_.ByteSize())
    return n + 1

  def ByteSizePartial(self):
    n = 0
    if (self.has_key_):
      n += 1
      n += self.lengthString(len(self.key_))
    if (self.has_name_space_): n += 1 + self.lengthString(len(self.name_space_))
    if (self.has_delta_): n += 1 + self.lengthVarInt64(self.delta_)
    if (self.has_direction_): n += 1 + self.lengthVarInt64(self.direction_)
    if (self.has_initial_value_): n += 1 + self.lengthVarInt64(self.initial_value_)
    if (self.has_initial_flags_): n += 5
    if (self.has_override_): n += 1 + self.lengthString(self.override_.ByteSizePartial())
    return n

  def Clear(self):
    self.clear_key()
    self.clear_name_space()
    self.clear_delta()
    self.clear_direction()
    self.clear_initial_value()
    self.clear_initial_flags()
    self.clear_override()

  def OutputUnchecked(self, out):
    out.putVarInt32(10)
    out.putPrefixedString(self.key_)
    if (self.has_delta_):
      out.putVarInt32(16)
      out.putVarUint64(self.delta_)
    if (self.has_direction_):
      out.putVarInt32(24)
      out.putVarInt32(self.direction_)
    if (self.has_name_space_):
      out.putVarInt32(34)
      out.putPrefixedString(self.name_space_)
    if (self.has_initial_value_):
      out.putVarInt32(40)
      out.putVarUint64(self.initial_value_)
    if (self.has_initial_flags_):
      out.putVarInt32(53)
      out.put32(self.initial_flags_)
    if (self.has_override_):
      out.putVarInt32(58)
      out.putVarInt32(self.override_.ByteSize())
      self.override_.OutputUnchecked(out)

  def OutputPartial(self, out):
    if (self.has_key_):
      out.putVarInt32(10)
      out.putPrefixedString(self.key_)
    if (self.has_delta_):
      out.putVarInt32(16)
      out.putVarUint64(self.delta_)
    if (self.has_direction_):
      out.putVarInt32(24)
      out.putVarInt32(self.direction_)
    if (self.has_name_space_):
      out.putVarInt32(34)
      out.putPrefixedString(self.name_space_)
    if (self.has_initial_value_):
      out.putVarInt32(40)
      out.putVarUint64(self.initial_value_)
    if (self.has_initial_flags_):
      out.putVarInt32(53)
      out.put32(self.initial_flags_)
    if (self.has_override_):
      out.putVarInt32(58)
      out.putVarInt32(self.override_.ByteSizePartial())
      self.override_.OutputPartial(out)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 10:
        self.set_key(d.getPrefixedString())
        continue
      if tt == 16:
        self.set_delta(d.getVarUint64())
        continue
      if tt == 24:
        self.set_direction(d.getVarInt32())
        continue
      if tt == 34:
        self.set_name_space(d.getPrefixedString())
        continue
      if tt == 40:
        self.set_initial_value(d.getVarUint64())
        continue
      if tt == 53:
        self.set_initial_flags(d.get32())
        continue
      if tt == 58:
        length = d.getVarInt32()
        tmp = ProtocolBuffer.Decoder(d.buffer(), d.pos(), d.pos() + length)
        d.skip(length)
        self.mutable_override().TryMerge(tmp)
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    if self.has_key_: res+=prefix+("key: %s\n" % self.DebugFormatString(self.key_))
    if self.has_name_space_: res+=prefix+("name_space: %s\n" % self.DebugFormatString(self.name_space_))
    if self.has_delta_: res+=prefix+("delta: %s\n" % self.DebugFormatInt64(self.delta_))
    if self.has_direction_: res+=prefix+("direction: %s\n" % self.DebugFormatInt32(self.direction_))
    if self.has_initial_value_: res+=prefix+("initial_value: %s\n" % self.DebugFormatInt64(self.initial_value_))
    if self.has_initial_flags_: res+=prefix+("initial_flags: %s\n" % self.DebugFormatFixed32(self.initial_flags_))
    if self.has_override_:
      res+=prefix+"override <\n"
      res+=self.override_.__str__(prefix + "  ", printElemNumber)
      res+=prefix+">\n"
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  kkey = 1
  kname_space = 4
  kdelta = 2
  kdirection = 3
  kinitial_value = 5
  kinitial_flags = 6
  koverride = 7

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "key",
    2: "delta",
    3: "direction",
    4: "name_space",
    5: "initial_value",
    6: "initial_flags",
    7: "override",
  }, 7)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.STRING,
    2: ProtocolBuffer.Encoder.NUMERIC,
    3: ProtocolBuffer.Encoder.NUMERIC,
    4: ProtocolBuffer.Encoder.STRING,
    5: ProtocolBuffer.Encoder.NUMERIC,
    6: ProtocolBuffer.Encoder.FLOAT,
    7: ProtocolBuffer.Encoder.STRING,
  }, 7, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("Wi5hcHBob3N0aW5nL2FwaS9tZW1jYWNoZS9tZW1jYWNoZV9zZXJ2aWNlLnByb3RvCiNhcHBob3N0aW5nLk1lbWNhY2hlSW5jcmVtZW50UmVxdWVzdBMaA2tleSABKAIwCTgCFBMaCm5hbWVfc3BhY2UgBCgCMAk4AUIAowGqAQdkZWZhdWx0sgECIiKkARQTGgVkZWx0YSACKAAwBDgBQgExowGqAQdkZWZhdWx0sgEBMaQBFBMaCWRpcmVjdGlvbiADKAAwBTgBQgExaACjAaoBB2RlZmF1bHSyAQlJTkNSRU1FTlSkARQTGg1pbml0aWFsX3ZhbHVlIAUoADAEOAEUExoNaW5pdGlhbF9mbGFncyAGKAUwBzgBFBMaCG92ZXJyaWRlIAcoAjALOAFKFmFwcGhvc3RpbmcuQXBwT3ZlcnJpZGUUc3oJRGlyZWN0aW9uiwGSAQlJTkNSRU1FTlSYAQGMAYsBkgEJREVDUkVNRU5UmAECjAF0wgEfYXBwaG9zdGluZy5NZW1jYWNoZVNlcnZpY2VFcnJvcg=="))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class MemcacheIncrementResponse(ProtocolBuffer.ProtocolMessage):


  OK           =    1
  NOT_CHANGED  =    2
  ERROR        =    3

  _IncrementStatusCode_NAMES = {
    1: "OK",
    2: "NOT_CHANGED",
    3: "ERROR",
  }

  def IncrementStatusCode_Name(cls, x): return cls._IncrementStatusCode_NAMES.get(x, "")
  IncrementStatusCode_Name = classmethod(IncrementStatusCode_Name)

  has_new_value_ = 0
  new_value_ = 0
  has_increment_status_ = 0
  increment_status_ = 0

  def __init__(self, contents=None):
    if contents is not None: self.MergeFromString(contents)

  def new_value(self): return self.new_value_

  def set_new_value(self, x):
    self.has_new_value_ = 1
    self.new_value_ = x

  def clear_new_value(self):
    if self.has_new_value_:
      self.has_new_value_ = 0
      self.new_value_ = 0

  def has_new_value(self): return self.has_new_value_

  def increment_status(self): return self.increment_status_

  def set_increment_status(self, x):
    self.has_increment_status_ = 1
    self.increment_status_ = x

  def clear_increment_status(self):
    if self.has_increment_status_:
      self.has_increment_status_ = 0
      self.increment_status_ = 0

  def has_increment_status(self): return self.has_increment_status_


  def MergeFrom(self, x):
    assert x is not self
    if (x.has_new_value()): self.set_new_value(x.new_value())
    if (x.has_increment_status()): self.set_increment_status(x.increment_status())

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.MemcacheIncrementResponse', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.MemcacheIncrementResponse')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.MemcacheIncrementResponse')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.MemcacheIncrementResponse', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.MemcacheIncrementResponse', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.MemcacheIncrementResponse', s)


  def Equals(self, x):
    if x is self: return 1
    if self.has_new_value_ != x.has_new_value_: return 0
    if self.has_new_value_ and self.new_value_ != x.new_value_: return 0
    if self.has_increment_status_ != x.has_increment_status_: return 0
    if self.has_increment_status_ and self.increment_status_ != x.increment_status_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    return initialized

  def ByteSize(self):
    n = 0
    if (self.has_new_value_): n += 1 + self.lengthVarInt64(self.new_value_)
    if (self.has_increment_status_): n += 1 + self.lengthVarInt64(self.increment_status_)
    return n

  def ByteSizePartial(self):
    n = 0
    if (self.has_new_value_): n += 1 + self.lengthVarInt64(self.new_value_)
    if (self.has_increment_status_): n += 1 + self.lengthVarInt64(self.increment_status_)
    return n

  def Clear(self):
    self.clear_new_value()
    self.clear_increment_status()

  def OutputUnchecked(self, out):
    if (self.has_new_value_):
      out.putVarInt32(8)
      out.putVarUint64(self.new_value_)
    if (self.has_increment_status_):
      out.putVarInt32(16)
      out.putVarInt32(self.increment_status_)

  def OutputPartial(self, out):
    if (self.has_new_value_):
      out.putVarInt32(8)
      out.putVarUint64(self.new_value_)
    if (self.has_increment_status_):
      out.putVarInt32(16)
      out.putVarInt32(self.increment_status_)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 8:
        self.set_new_value(d.getVarUint64())
        continue
      if tt == 16:
        self.set_increment_status(d.getVarInt32())
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    if self.has_new_value_: res+=prefix+("new_value: %s\n" % self.DebugFormatInt64(self.new_value_))
    if self.has_increment_status_: res+=prefix+("increment_status: %s\n" % self.DebugFormatInt32(self.increment_status_))
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  knew_value = 1
  kincrement_status = 2

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "new_value",
    2: "increment_status",
  }, 2)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.NUMERIC,
    2: ProtocolBuffer.Encoder.NUMERIC,
  }, 2, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("Wi5hcHBob3N0aW5nL2FwaS9tZW1jYWNoZS9tZW1jYWNoZV9zZXJ2aWNlLnByb3RvCiRhcHBob3N0aW5nLk1lbWNhY2hlSW5jcmVtZW50UmVzcG9uc2UTGgluZXdfdmFsdWUgASgAMAQ4ARQTGhBpbmNyZW1lbnRfc3RhdHVzIAIoADAFOAFoABRzehNJbmNyZW1lbnRTdGF0dXNDb2RliwGSAQJPS5gBAYwBiwGSAQtOT1RfQ0hBTkdFRJgBAowBiwGSAQVFUlJPUpgBA4wBdMIBH2FwcGhvc3RpbmcuTWVtY2FjaGVTZXJ2aWNlRXJyb3I="))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class MemcacheBatchIncrementRequest(ProtocolBuffer.ProtocolMessage):
  has_name_space_ = 0
  name_space_ = ""
  has_override_ = 0
  override_ = None

  def __init__(self, contents=None):
    self.item_ = []
    self.lazy_init_lock_ = thread.allocate_lock()
    if contents is not None: self.MergeFromString(contents)

  def name_space(self): return self.name_space_

  def set_name_space(self, x):
    self.has_name_space_ = 1
    self.name_space_ = x

  def clear_name_space(self):
    if self.has_name_space_:
      self.has_name_space_ = 0
      self.name_space_ = ""

  def has_name_space(self): return self.has_name_space_

  def item_size(self): return len(self.item_)
  def item_list(self): return self.item_

  def item(self, i):
    return self.item_[i]

  def mutable_item(self, i):
    return self.item_[i]

  def add_item(self):
    x = MemcacheIncrementRequest()
    self.item_.append(x)
    return x

  def clear_item(self):
    self.item_ = []
  def override(self):
    if self.override_ is None:
      self.lazy_init_lock_.acquire()
      try:
        if self.override_ is None: self.override_ = AppOverride()
      finally:
        self.lazy_init_lock_.release()
    return self.override_

  def mutable_override(self): self.has_override_ = 1; return self.override()

  def clear_override(self):

    if self.has_override_:
      self.has_override_ = 0;
      if self.override_ is not None: self.override_.Clear()

  def has_override(self): return self.has_override_


  def MergeFrom(self, x):
    assert x is not self
    if (x.has_name_space()): self.set_name_space(x.name_space())
    for i in xrange(x.item_size()): self.add_item().CopyFrom(x.item(i))
    if (x.has_override()): self.mutable_override().MergeFrom(x.override())

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.MemcacheBatchIncrementRequest', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.MemcacheBatchIncrementRequest')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.MemcacheBatchIncrementRequest')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.MemcacheBatchIncrementRequest', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.MemcacheBatchIncrementRequest', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.MemcacheBatchIncrementRequest', s)


  def Equals(self, x):
    if x is self: return 1
    if self.has_name_space_ != x.has_name_space_: return 0
    if self.has_name_space_ and self.name_space_ != x.name_space_: return 0
    if len(self.item_) != len(x.item_): return 0
    for e1, e2 in zip(self.item_, x.item_):
      if e1 != e2: return 0
    if self.has_override_ != x.has_override_: return 0
    if self.has_override_ and self.override_ != x.override_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    for p in self.item_:
      if not p.IsInitialized(debug_strs): initialized=0
    if (self.has_override_ and not self.override_.IsInitialized(debug_strs)): initialized = 0
    return initialized

  def ByteSize(self):
    n = 0
    if (self.has_name_space_): n += 1 + self.lengthString(len(self.name_space_))
    n += 1 * len(self.item_)
    for i in xrange(len(self.item_)): n += self.lengthString(self.item_[i].ByteSize())
    if (self.has_override_): n += 1 + self.lengthString(self.override_.ByteSize())
    return n

  def ByteSizePartial(self):
    n = 0
    if (self.has_name_space_): n += 1 + self.lengthString(len(self.name_space_))
    n += 1 * len(self.item_)
    for i in xrange(len(self.item_)): n += self.lengthString(self.item_[i].ByteSizePartial())
    if (self.has_override_): n += 1 + self.lengthString(self.override_.ByteSizePartial())
    return n

  def Clear(self):
    self.clear_name_space()
    self.clear_item()
    self.clear_override()

  def OutputUnchecked(self, out):
    if (self.has_name_space_):
      out.putVarInt32(10)
      out.putPrefixedString(self.name_space_)
    for i in xrange(len(self.item_)):
      out.putVarInt32(18)
      out.putVarInt32(self.item_[i].ByteSize())
      self.item_[i].OutputUnchecked(out)
    if (self.has_override_):
      out.putVarInt32(26)
      out.putVarInt32(self.override_.ByteSize())
      self.override_.OutputUnchecked(out)

  def OutputPartial(self, out):
    if (self.has_name_space_):
      out.putVarInt32(10)
      out.putPrefixedString(self.name_space_)
    for i in xrange(len(self.item_)):
      out.putVarInt32(18)
      out.putVarInt32(self.item_[i].ByteSizePartial())
      self.item_[i].OutputPartial(out)
    if (self.has_override_):
      out.putVarInt32(26)
      out.putVarInt32(self.override_.ByteSizePartial())
      self.override_.OutputPartial(out)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 10:
        self.set_name_space(d.getPrefixedString())
        continue
      if tt == 18:
        length = d.getVarInt32()
        tmp = ProtocolBuffer.Decoder(d.buffer(), d.pos(), d.pos() + length)
        d.skip(length)
        self.add_item().TryMerge(tmp)
        continue
      if tt == 26:
        length = d.getVarInt32()
        tmp = ProtocolBuffer.Decoder(d.buffer(), d.pos(), d.pos() + length)
        d.skip(length)
        self.mutable_override().TryMerge(tmp)
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    if self.has_name_space_: res+=prefix+("name_space: %s\n" % self.DebugFormatString(self.name_space_))
    cnt=0
    for e in self.item_:
      elm=""
      if printElemNumber: elm="(%d)" % cnt
      res+=prefix+("item%s <\n" % elm)
      res+=e.__str__(prefix + "  ", printElemNumber)
      res+=prefix+">\n"
      cnt+=1
    if self.has_override_:
      res+=prefix+"override <\n"
      res+=self.override_.__str__(prefix + "  ", printElemNumber)
      res+=prefix+">\n"
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  kname_space = 1
  kitem = 2
  koverride = 3

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "name_space",
    2: "item",
    3: "override",
  }, 3)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.STRING,
    2: ProtocolBuffer.Encoder.STRING,
    3: ProtocolBuffer.Encoder.STRING,
  }, 3, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("Wi5hcHBob3N0aW5nL2FwaS9tZW1jYWNoZS9tZW1jYWNoZV9zZXJ2aWNlLnByb3RvCihhcHBob3N0aW5nLk1lbWNhY2hlQmF0Y2hJbmNyZW1lbnRSZXF1ZXN0ExoKbmFtZV9zcGFjZSABKAIwCTgBQgCjAaoBB2RlZmF1bHSyAQIiIqQBFBMaBGl0ZW0gAigCMAs4A0ojYXBwaG9zdGluZy5NZW1jYWNoZUluY3JlbWVudFJlcXVlc3QUExoIb3ZlcnJpZGUgAygCMAs4AUoWYXBwaG9zdGluZy5BcHBPdmVycmlkZRTCAR9hcHBob3N0aW5nLk1lbWNhY2hlU2VydmljZUVycm9y"))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class MemcacheBatchIncrementResponse(ProtocolBuffer.ProtocolMessage):

  def __init__(self, contents=None):
    self.item_ = []
    if contents is not None: self.MergeFromString(contents)

  def item_size(self): return len(self.item_)
  def item_list(self): return self.item_

  def item(self, i):
    return self.item_[i]

  def mutable_item(self, i):
    return self.item_[i]

  def add_item(self):
    x = MemcacheIncrementResponse()
    self.item_.append(x)
    return x

  def clear_item(self):
    self.item_ = []

  def MergeFrom(self, x):
    assert x is not self
    for i in xrange(x.item_size()): self.add_item().CopyFrom(x.item(i))

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.MemcacheBatchIncrementResponse', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.MemcacheBatchIncrementResponse')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.MemcacheBatchIncrementResponse')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.MemcacheBatchIncrementResponse', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.MemcacheBatchIncrementResponse', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.MemcacheBatchIncrementResponse', s)


  def Equals(self, x):
    if x is self: return 1
    if len(self.item_) != len(x.item_): return 0
    for e1, e2 in zip(self.item_, x.item_):
      if e1 != e2: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    for p in self.item_:
      if not p.IsInitialized(debug_strs): initialized=0
    return initialized

  def ByteSize(self):
    n = 0
    n += 1 * len(self.item_)
    for i in xrange(len(self.item_)): n += self.lengthString(self.item_[i].ByteSize())
    return n

  def ByteSizePartial(self):
    n = 0
    n += 1 * len(self.item_)
    for i in xrange(len(self.item_)): n += self.lengthString(self.item_[i].ByteSizePartial())
    return n

  def Clear(self):
    self.clear_item()

  def OutputUnchecked(self, out):
    for i in xrange(len(self.item_)):
      out.putVarInt32(10)
      out.putVarInt32(self.item_[i].ByteSize())
      self.item_[i].OutputUnchecked(out)

  def OutputPartial(self, out):
    for i in xrange(len(self.item_)):
      out.putVarInt32(10)
      out.putVarInt32(self.item_[i].ByteSizePartial())
      self.item_[i].OutputPartial(out)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 10:
        length = d.getVarInt32()
        tmp = ProtocolBuffer.Decoder(d.buffer(), d.pos(), d.pos() + length)
        d.skip(length)
        self.add_item().TryMerge(tmp)
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    cnt=0
    for e in self.item_:
      elm=""
      if printElemNumber: elm="(%d)" % cnt
      res+=prefix+("item%s <\n" % elm)
      res+=e.__str__(prefix + "  ", printElemNumber)
      res+=prefix+">\n"
      cnt+=1
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  kitem = 1

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "item",
  }, 1)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.STRING,
  }, 1, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("Wi5hcHBob3N0aW5nL2FwaS9tZW1jYWNoZS9tZW1jYWNoZV9zZXJ2aWNlLnByb3RvCilhcHBob3N0aW5nLk1lbWNhY2hlQmF0Y2hJbmNyZW1lbnRSZXNwb25zZRMaBGl0ZW0gASgCMAs4A0okYXBwaG9zdGluZy5NZW1jYWNoZUluY3JlbWVudFJlc3BvbnNlFMIBH2FwcGhvc3RpbmcuTWVtY2FjaGVTZXJ2aWNlRXJyb3I="))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class MemcacheFlushRequest(ProtocolBuffer.ProtocolMessage):
  has_override_ = 0
  override_ = None

  def __init__(self, contents=None):
    self.lazy_init_lock_ = thread.allocate_lock()
    if contents is not None: self.MergeFromString(contents)

  def override(self):
    if self.override_ is None:
      self.lazy_init_lock_.acquire()
      try:
        if self.override_ is None: self.override_ = AppOverride()
      finally:
        self.lazy_init_lock_.release()
    return self.override_

  def mutable_override(self): self.has_override_ = 1; return self.override()

  def clear_override(self):

    if self.has_override_:
      self.has_override_ = 0;
      if self.override_ is not None: self.override_.Clear()

  def has_override(self): return self.has_override_


  def MergeFrom(self, x):
    assert x is not self
    if (x.has_override()): self.mutable_override().MergeFrom(x.override())

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.MemcacheFlushRequest', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.MemcacheFlushRequest')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.MemcacheFlushRequest')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.MemcacheFlushRequest', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.MemcacheFlushRequest', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.MemcacheFlushRequest', s)


  def Equals(self, x):
    if x is self: return 1
    if self.has_override_ != x.has_override_: return 0
    if self.has_override_ and self.override_ != x.override_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    if (self.has_override_ and not self.override_.IsInitialized(debug_strs)): initialized = 0
    return initialized

  def ByteSize(self):
    n = 0
    if (self.has_override_): n += 1 + self.lengthString(self.override_.ByteSize())
    return n

  def ByteSizePartial(self):
    n = 0
    if (self.has_override_): n += 1 + self.lengthString(self.override_.ByteSizePartial())
    return n

  def Clear(self):
    self.clear_override()

  def OutputUnchecked(self, out):
    if (self.has_override_):
      out.putVarInt32(10)
      out.putVarInt32(self.override_.ByteSize())
      self.override_.OutputUnchecked(out)

  def OutputPartial(self, out):
    if (self.has_override_):
      out.putVarInt32(10)
      out.putVarInt32(self.override_.ByteSizePartial())
      self.override_.OutputPartial(out)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 10:
        length = d.getVarInt32()
        tmp = ProtocolBuffer.Decoder(d.buffer(), d.pos(), d.pos() + length)
        d.skip(length)
        self.mutable_override().TryMerge(tmp)
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    if self.has_override_:
      res+=prefix+"override <\n"
      res+=self.override_.__str__(prefix + "  ", printElemNumber)
      res+=prefix+">\n"
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  koverride = 1

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "override",
  }, 1)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.STRING,
  }, 1, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("Wi5hcHBob3N0aW5nL2FwaS9tZW1jYWNoZS9tZW1jYWNoZV9zZXJ2aWNlLnByb3RvCh9hcHBob3N0aW5nLk1lbWNhY2hlRmx1c2hSZXF1ZXN0ExoIb3ZlcnJpZGUgASgCMAs4AUoWYXBwaG9zdGluZy5BcHBPdmVycmlkZRTCAR9hcHBob3N0aW5nLk1lbWNhY2hlU2VydmljZUVycm9y"))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class MemcacheFlushResponse(ProtocolBuffer.ProtocolMessage):

  def __init__(self, contents=None):
    pass
    if contents is not None: self.MergeFromString(contents)


  def MergeFrom(self, x):
    assert x is not self

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.MemcacheFlushResponse', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.MemcacheFlushResponse')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.MemcacheFlushResponse')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.MemcacheFlushResponse', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.MemcacheFlushResponse', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.MemcacheFlushResponse', s)


  def Equals(self, x):
    if x is self: return 1
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    return initialized

  def ByteSize(self):
    n = 0
    return n

  def ByteSizePartial(self):
    n = 0
    return n

  def Clear(self):
    pass

  def OutputUnchecked(self, out):
    pass

  def OutputPartial(self, out):
    pass

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])


  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
  }, 0)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
  }, 0, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("Wi5hcHBob3N0aW5nL2FwaS9tZW1jYWNoZS9tZW1jYWNoZV9zZXJ2aWNlLnByb3RvCiBhcHBob3N0aW5nLk1lbWNhY2hlRmx1c2hSZXNwb25zZcIBH2FwcGhvc3RpbmcuTWVtY2FjaGVTZXJ2aWNlRXJyb3I="))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class MemcacheStatsRequest(ProtocolBuffer.ProtocolMessage):
  has_override_ = 0
  override_ = None

  def __init__(self, contents=None):
    self.lazy_init_lock_ = thread.allocate_lock()
    if contents is not None: self.MergeFromString(contents)

  def override(self):
    if self.override_ is None:
      self.lazy_init_lock_.acquire()
      try:
        if self.override_ is None: self.override_ = AppOverride()
      finally:
        self.lazy_init_lock_.release()
    return self.override_

  def mutable_override(self): self.has_override_ = 1; return self.override()

  def clear_override(self):

    if self.has_override_:
      self.has_override_ = 0;
      if self.override_ is not None: self.override_.Clear()

  def has_override(self): return self.has_override_


  def MergeFrom(self, x):
    assert x is not self
    if (x.has_override()): self.mutable_override().MergeFrom(x.override())

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.MemcacheStatsRequest', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.MemcacheStatsRequest')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.MemcacheStatsRequest')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.MemcacheStatsRequest', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.MemcacheStatsRequest', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.MemcacheStatsRequest', s)


  def Equals(self, x):
    if x is self: return 1
    if self.has_override_ != x.has_override_: return 0
    if self.has_override_ and self.override_ != x.override_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    if (self.has_override_ and not self.override_.IsInitialized(debug_strs)): initialized = 0
    return initialized

  def ByteSize(self):
    n = 0
    if (self.has_override_): n += 1 + self.lengthString(self.override_.ByteSize())
    return n

  def ByteSizePartial(self):
    n = 0
    if (self.has_override_): n += 1 + self.lengthString(self.override_.ByteSizePartial())
    return n

  def Clear(self):
    self.clear_override()

  def OutputUnchecked(self, out):
    if (self.has_override_):
      out.putVarInt32(10)
      out.putVarInt32(self.override_.ByteSize())
      self.override_.OutputUnchecked(out)

  def OutputPartial(self, out):
    if (self.has_override_):
      out.putVarInt32(10)
      out.putVarInt32(self.override_.ByteSizePartial())
      self.override_.OutputPartial(out)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 10:
        length = d.getVarInt32()
        tmp = ProtocolBuffer.Decoder(d.buffer(), d.pos(), d.pos() + length)
        d.skip(length)
        self.mutable_override().TryMerge(tmp)
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    if self.has_override_:
      res+=prefix+"override <\n"
      res+=self.override_.__str__(prefix + "  ", printElemNumber)
      res+=prefix+">\n"
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  koverride = 1

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "override",
  }, 1)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.STRING,
  }, 1, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("Wi5hcHBob3N0aW5nL2FwaS9tZW1jYWNoZS9tZW1jYWNoZV9zZXJ2aWNlLnByb3RvCh9hcHBob3N0aW5nLk1lbWNhY2hlU3RhdHNSZXF1ZXN0ExoIb3ZlcnJpZGUgASgCMAs4AUoWYXBwaG9zdGluZy5BcHBPdmVycmlkZRTCAR9hcHBob3N0aW5nLk1lbWNhY2hlU2VydmljZUVycm9y"))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class MergedNamespaceStats(ProtocolBuffer.ProtocolMessage):
  has_hits_ = 0
  hits_ = 0
  has_misses_ = 0
  misses_ = 0
  has_byte_hits_ = 0
  byte_hits_ = 0
  has_items_ = 0
  items_ = 0
  has_bytes_ = 0
  bytes_ = 0
  has_oldest_item_age_ = 0
  oldest_item_age_ = 0

  def __init__(self, contents=None):
    if contents is not None: self.MergeFromString(contents)

  def hits(self): return self.hits_

  def set_hits(self, x):
    self.has_hits_ = 1
    self.hits_ = x

  def clear_hits(self):
    if self.has_hits_:
      self.has_hits_ = 0
      self.hits_ = 0

  def has_hits(self): return self.has_hits_

  def misses(self): return self.misses_

  def set_misses(self, x):
    self.has_misses_ = 1
    self.misses_ = x

  def clear_misses(self):
    if self.has_misses_:
      self.has_misses_ = 0
      self.misses_ = 0

  def has_misses(self): return self.has_misses_

  def byte_hits(self): return self.byte_hits_

  def set_byte_hits(self, x):
    self.has_byte_hits_ = 1
    self.byte_hits_ = x

  def clear_byte_hits(self):
    if self.has_byte_hits_:
      self.has_byte_hits_ = 0
      self.byte_hits_ = 0

  def has_byte_hits(self): return self.has_byte_hits_

  def items(self): return self.items_

  def set_items(self, x):
    self.has_items_ = 1
    self.items_ = x

  def clear_items(self):
    if self.has_items_:
      self.has_items_ = 0
      self.items_ = 0

  def has_items(self): return self.has_items_

  def bytes(self): return self.bytes_

  def set_bytes(self, x):
    self.has_bytes_ = 1
    self.bytes_ = x

  def clear_bytes(self):
    if self.has_bytes_:
      self.has_bytes_ = 0
      self.bytes_ = 0

  def has_bytes(self): return self.has_bytes_

  def oldest_item_age(self): return self.oldest_item_age_

  def set_oldest_item_age(self, x):
    self.has_oldest_item_age_ = 1
    self.oldest_item_age_ = x

  def clear_oldest_item_age(self):
    if self.has_oldest_item_age_:
      self.has_oldest_item_age_ = 0
      self.oldest_item_age_ = 0

  def has_oldest_item_age(self): return self.has_oldest_item_age_


  def MergeFrom(self, x):
    assert x is not self
    if (x.has_hits()): self.set_hits(x.hits())
    if (x.has_misses()): self.set_misses(x.misses())
    if (x.has_byte_hits()): self.set_byte_hits(x.byte_hits())
    if (x.has_items()): self.set_items(x.items())
    if (x.has_bytes()): self.set_bytes(x.bytes())
    if (x.has_oldest_item_age()): self.set_oldest_item_age(x.oldest_item_age())

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.MergedNamespaceStats', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.MergedNamespaceStats')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.MergedNamespaceStats')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.MergedNamespaceStats', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.MergedNamespaceStats', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.MergedNamespaceStats', s)


  def Equals(self, x):
    if x is self: return 1
    if self.has_hits_ != x.has_hits_: return 0
    if self.has_hits_ and self.hits_ != x.hits_: return 0
    if self.has_misses_ != x.has_misses_: return 0
    if self.has_misses_ and self.misses_ != x.misses_: return 0
    if self.has_byte_hits_ != x.has_byte_hits_: return 0
    if self.has_byte_hits_ and self.byte_hits_ != x.byte_hits_: return 0
    if self.has_items_ != x.has_items_: return 0
    if self.has_items_ and self.items_ != x.items_: return 0
    if self.has_bytes_ != x.has_bytes_: return 0
    if self.has_bytes_ and self.bytes_ != x.bytes_: return 0
    if self.has_oldest_item_age_ != x.has_oldest_item_age_: return 0
    if self.has_oldest_item_age_ and self.oldest_item_age_ != x.oldest_item_age_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    if (not self.has_hits_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: hits not set.')
    if (not self.has_misses_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: misses not set.')
    if (not self.has_byte_hits_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: byte_hits not set.')
    if (not self.has_items_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: items not set.')
    if (not self.has_bytes_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: bytes not set.')
    if (not self.has_oldest_item_age_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: oldest_item_age not set.')
    return initialized

  def ByteSize(self):
    n = 0
    n += self.lengthVarInt64(self.hits_)
    n += self.lengthVarInt64(self.misses_)
    n += self.lengthVarInt64(self.byte_hits_)
    n += self.lengthVarInt64(self.items_)
    n += self.lengthVarInt64(self.bytes_)
    return n + 10

  def ByteSizePartial(self):
    n = 0
    if (self.has_hits_):
      n += 1
      n += self.lengthVarInt64(self.hits_)
    if (self.has_misses_):
      n += 1
      n += self.lengthVarInt64(self.misses_)
    if (self.has_byte_hits_):
      n += 1
      n += self.lengthVarInt64(self.byte_hits_)
    if (self.has_items_):
      n += 1
      n += self.lengthVarInt64(self.items_)
    if (self.has_bytes_):
      n += 1
      n += self.lengthVarInt64(self.bytes_)
    if (self.has_oldest_item_age_):
      n += 5
    return n

  def Clear(self):
    self.clear_hits()
    self.clear_misses()
    self.clear_byte_hits()
    self.clear_items()
    self.clear_bytes()
    self.clear_oldest_item_age()

  def OutputUnchecked(self, out):
    out.putVarInt32(8)
    out.putVarUint64(self.hits_)
    out.putVarInt32(16)
    out.putVarUint64(self.misses_)
    out.putVarInt32(24)
    out.putVarUint64(self.byte_hits_)
    out.putVarInt32(32)
    out.putVarUint64(self.items_)
    out.putVarInt32(40)
    out.putVarUint64(self.bytes_)
    out.putVarInt32(53)
    out.put32(self.oldest_item_age_)

  def OutputPartial(self, out):
    if (self.has_hits_):
      out.putVarInt32(8)
      out.putVarUint64(self.hits_)
    if (self.has_misses_):
      out.putVarInt32(16)
      out.putVarUint64(self.misses_)
    if (self.has_byte_hits_):
      out.putVarInt32(24)
      out.putVarUint64(self.byte_hits_)
    if (self.has_items_):
      out.putVarInt32(32)
      out.putVarUint64(self.items_)
    if (self.has_bytes_):
      out.putVarInt32(40)
      out.putVarUint64(self.bytes_)
    if (self.has_oldest_item_age_):
      out.putVarInt32(53)
      out.put32(self.oldest_item_age_)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 8:
        self.set_hits(d.getVarUint64())
        continue
      if tt == 16:
        self.set_misses(d.getVarUint64())
        continue
      if tt == 24:
        self.set_byte_hits(d.getVarUint64())
        continue
      if tt == 32:
        self.set_items(d.getVarUint64())
        continue
      if tt == 40:
        self.set_bytes(d.getVarUint64())
        continue
      if tt == 53:
        self.set_oldest_item_age(d.get32())
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    if self.has_hits_: res+=prefix+("hits: %s\n" % self.DebugFormatInt64(self.hits_))
    if self.has_misses_: res+=prefix+("misses: %s\n" % self.DebugFormatInt64(self.misses_))
    if self.has_byte_hits_: res+=prefix+("byte_hits: %s\n" % self.DebugFormatInt64(self.byte_hits_))
    if self.has_items_: res+=prefix+("items: %s\n" % self.DebugFormatInt64(self.items_))
    if self.has_bytes_: res+=prefix+("bytes: %s\n" % self.DebugFormatInt64(self.bytes_))
    if self.has_oldest_item_age_: res+=prefix+("oldest_item_age: %s\n" % self.DebugFormatFixed32(self.oldest_item_age_))
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  khits = 1
  kmisses = 2
  kbyte_hits = 3
  kitems = 4
  kbytes = 5
  koldest_item_age = 6

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "hits",
    2: "misses",
    3: "byte_hits",
    4: "items",
    5: "bytes",
    6: "oldest_item_age",
  }, 6)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.NUMERIC,
    2: ProtocolBuffer.Encoder.NUMERIC,
    3: ProtocolBuffer.Encoder.NUMERIC,
    4: ProtocolBuffer.Encoder.NUMERIC,
    5: ProtocolBuffer.Encoder.NUMERIC,
    6: ProtocolBuffer.Encoder.FLOAT,
  }, 6, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("Wi5hcHBob3N0aW5nL2FwaS9tZW1jYWNoZS9tZW1jYWNoZV9zZXJ2aWNlLnByb3RvCh9hcHBob3N0aW5nLk1lcmdlZE5hbWVzcGFjZVN0YXRzExoEaGl0cyABKAAwBDgCFBMaBm1pc3NlcyACKAAwBDgCFBMaCWJ5dGVfaGl0cyADKAAwBDgCFBMaBWl0ZW1zIAQoADAEOAIUExoFYnl0ZXMgBSgAMAQ4AhQTGg9vbGRlc3RfaXRlbV9hZ2UgBigFMAc4AhTCAR9hcHBob3N0aW5nLk1lbWNhY2hlU2VydmljZUVycm9y"))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class MemcacheStatsResponse(ProtocolBuffer.ProtocolMessage):
  has_stats_ = 0
  stats_ = None

  def __init__(self, contents=None):
    self.lazy_init_lock_ = thread.allocate_lock()
    if contents is not None: self.MergeFromString(contents)

  def stats(self):
    if self.stats_ is None:
      self.lazy_init_lock_.acquire()
      try:
        if self.stats_ is None: self.stats_ = MergedNamespaceStats()
      finally:
        self.lazy_init_lock_.release()
    return self.stats_

  def mutable_stats(self): self.has_stats_ = 1; return self.stats()

  def clear_stats(self):

    if self.has_stats_:
      self.has_stats_ = 0;
      if self.stats_ is not None: self.stats_.Clear()

  def has_stats(self): return self.has_stats_


  def MergeFrom(self, x):
    assert x is not self
    if (x.has_stats()): self.mutable_stats().MergeFrom(x.stats())

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.MemcacheStatsResponse', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.MemcacheStatsResponse')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.MemcacheStatsResponse')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.MemcacheStatsResponse', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.MemcacheStatsResponse', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.MemcacheStatsResponse', s)


  def Equals(self, x):
    if x is self: return 1
    if self.has_stats_ != x.has_stats_: return 0
    if self.has_stats_ and self.stats_ != x.stats_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    if (self.has_stats_ and not self.stats_.IsInitialized(debug_strs)): initialized = 0
    return initialized

  def ByteSize(self):
    n = 0
    if (self.has_stats_): n += 1 + self.lengthString(self.stats_.ByteSize())
    return n

  def ByteSizePartial(self):
    n = 0
    if (self.has_stats_): n += 1 + self.lengthString(self.stats_.ByteSizePartial())
    return n

  def Clear(self):
    self.clear_stats()

  def OutputUnchecked(self, out):
    if (self.has_stats_):
      out.putVarInt32(10)
      out.putVarInt32(self.stats_.ByteSize())
      self.stats_.OutputUnchecked(out)

  def OutputPartial(self, out):
    if (self.has_stats_):
      out.putVarInt32(10)
      out.putVarInt32(self.stats_.ByteSizePartial())
      self.stats_.OutputPartial(out)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 10:
        length = d.getVarInt32()
        tmp = ProtocolBuffer.Decoder(d.buffer(), d.pos(), d.pos() + length)
        d.skip(length)
        self.mutable_stats().TryMerge(tmp)
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    if self.has_stats_:
      res+=prefix+"stats <\n"
      res+=self.stats_.__str__(prefix + "  ", printElemNumber)
      res+=prefix+">\n"
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  kstats = 1

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "stats",
  }, 1)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.STRING,
  }, 1, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("Wi5hcHBob3N0aW5nL2FwaS9tZW1jYWNoZS9tZW1jYWNoZV9zZXJ2aWNlLnByb3RvCiBhcHBob3N0aW5nLk1lbWNhY2hlU3RhdHNSZXNwb25zZRMaBXN0YXRzIAEoAjALOAFKH2FwcGhvc3RpbmcuTWVyZ2VkTmFtZXNwYWNlU3RhdHMUwgEfYXBwaG9zdGluZy5NZW1jYWNoZVNlcnZpY2VFcnJvcg=="))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class MemcacheGrabTailRequest(ProtocolBuffer.ProtocolMessage):
  has_item_count_ = 0
  item_count_ = 0
  has_name_space_ = 0
  name_space_ = ""
  has_override_ = 0
  override_ = None

  def __init__(self, contents=None):
    self.lazy_init_lock_ = thread.allocate_lock()
    if contents is not None: self.MergeFromString(contents)

  def item_count(self): return self.item_count_

  def set_item_count(self, x):
    self.has_item_count_ = 1
    self.item_count_ = x

  def clear_item_count(self):
    if self.has_item_count_:
      self.has_item_count_ = 0
      self.item_count_ = 0

  def has_item_count(self): return self.has_item_count_

  def name_space(self): return self.name_space_

  def set_name_space(self, x):
    self.has_name_space_ = 1
    self.name_space_ = x

  def clear_name_space(self):
    if self.has_name_space_:
      self.has_name_space_ = 0
      self.name_space_ = ""

  def has_name_space(self): return self.has_name_space_

  def override(self):
    if self.override_ is None:
      self.lazy_init_lock_.acquire()
      try:
        if self.override_ is None: self.override_ = AppOverride()
      finally:
        self.lazy_init_lock_.release()
    return self.override_

  def mutable_override(self): self.has_override_ = 1; return self.override()

  def clear_override(self):

    if self.has_override_:
      self.has_override_ = 0;
      if self.override_ is not None: self.override_.Clear()

  def has_override(self): return self.has_override_


  def MergeFrom(self, x):
    assert x is not self
    if (x.has_item_count()): self.set_item_count(x.item_count())
    if (x.has_name_space()): self.set_name_space(x.name_space())
    if (x.has_override()): self.mutable_override().MergeFrom(x.override())

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.MemcacheGrabTailRequest', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.MemcacheGrabTailRequest')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.MemcacheGrabTailRequest')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.MemcacheGrabTailRequest', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.MemcacheGrabTailRequest', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.MemcacheGrabTailRequest', s)


  def Equals(self, x):
    if x is self: return 1
    if self.has_item_count_ != x.has_item_count_: return 0
    if self.has_item_count_ and self.item_count_ != x.item_count_: return 0
    if self.has_name_space_ != x.has_name_space_: return 0
    if self.has_name_space_ and self.name_space_ != x.name_space_: return 0
    if self.has_override_ != x.has_override_: return 0
    if self.has_override_ and self.override_ != x.override_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    if (not self.has_item_count_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: item_count not set.')
    if (self.has_override_ and not self.override_.IsInitialized(debug_strs)): initialized = 0
    return initialized

  def ByteSize(self):
    n = 0
    n += self.lengthVarInt64(self.item_count_)
    if (self.has_name_space_): n += 1 + self.lengthString(len(self.name_space_))
    if (self.has_override_): n += 1 + self.lengthString(self.override_.ByteSize())
    return n + 1

  def ByteSizePartial(self):
    n = 0
    if (self.has_item_count_):
      n += 1
      n += self.lengthVarInt64(self.item_count_)
    if (self.has_name_space_): n += 1 + self.lengthString(len(self.name_space_))
    if (self.has_override_): n += 1 + self.lengthString(self.override_.ByteSizePartial())
    return n

  def Clear(self):
    self.clear_item_count()
    self.clear_name_space()
    self.clear_override()

  def OutputUnchecked(self, out):
    out.putVarInt32(8)
    out.putVarInt32(self.item_count_)
    if (self.has_name_space_):
      out.putVarInt32(18)
      out.putPrefixedString(self.name_space_)
    if (self.has_override_):
      out.putVarInt32(26)
      out.putVarInt32(self.override_.ByteSize())
      self.override_.OutputUnchecked(out)

  def OutputPartial(self, out):
    if (self.has_item_count_):
      out.putVarInt32(8)
      out.putVarInt32(self.item_count_)
    if (self.has_name_space_):
      out.putVarInt32(18)
      out.putPrefixedString(self.name_space_)
    if (self.has_override_):
      out.putVarInt32(26)
      out.putVarInt32(self.override_.ByteSizePartial())
      self.override_.OutputPartial(out)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 8:
        self.set_item_count(d.getVarInt32())
        continue
      if tt == 18:
        self.set_name_space(d.getPrefixedString())
        continue
      if tt == 26:
        length = d.getVarInt32()
        tmp = ProtocolBuffer.Decoder(d.buffer(), d.pos(), d.pos() + length)
        d.skip(length)
        self.mutable_override().TryMerge(tmp)
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    if self.has_item_count_: res+=prefix+("item_count: %s\n" % self.DebugFormatInt32(self.item_count_))
    if self.has_name_space_: res+=prefix+("name_space: %s\n" % self.DebugFormatString(self.name_space_))
    if self.has_override_:
      res+=prefix+"override <\n"
      res+=self.override_.__str__(prefix + "  ", printElemNumber)
      res+=prefix+">\n"
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  kitem_count = 1
  kname_space = 2
  koverride = 3

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "item_count",
    2: "name_space",
    3: "override",
  }, 3)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.NUMERIC,
    2: ProtocolBuffer.Encoder.STRING,
    3: ProtocolBuffer.Encoder.STRING,
  }, 3, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("Wi5hcHBob3N0aW5nL2FwaS9tZW1jYWNoZS9tZW1jYWNoZV9zZXJ2aWNlLnByb3RvCiJhcHBob3N0aW5nLk1lbWNhY2hlR3JhYlRhaWxSZXF1ZXN0ExoKaXRlbV9jb3VudCABKAAwBTgCFBMaCm5hbWVfc3BhY2UgAigCMAk4AUIAowGqAQdkZWZhdWx0sgECIiKkARQTGghvdmVycmlkZSADKAIwCzgBShZhcHBob3N0aW5nLkFwcE92ZXJyaWRlFMIBH2FwcGhvc3RpbmcuTWVtY2FjaGVTZXJ2aWNlRXJyb3I="))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class MemcacheGrabTailResponse_Item(ProtocolBuffer.ProtocolMessage):
  has_value_ = 0
  value_ = ""
  has_flags_ = 0
  flags_ = 0

  def __init__(self, contents=None):
    if contents is not None: self.MergeFromString(contents)

  def value(self): return self.value_

  def set_value(self, x):
    self.has_value_ = 1
    self.value_ = x

  def clear_value(self):
    if self.has_value_:
      self.has_value_ = 0
      self.value_ = ""

  def has_value(self): return self.has_value_

  def flags(self): return self.flags_

  def set_flags(self, x):
    self.has_flags_ = 1
    self.flags_ = x

  def clear_flags(self):
    if self.has_flags_:
      self.has_flags_ = 0
      self.flags_ = 0

  def has_flags(self): return self.has_flags_


  def MergeFrom(self, x):
    assert x is not self
    if (x.has_value()): self.set_value(x.value())
    if (x.has_flags()): self.set_flags(x.flags())

  def Equals(self, x):
    if x is self: return 1
    if self.has_value_ != x.has_value_: return 0
    if self.has_value_ and self.value_ != x.value_: return 0
    if self.has_flags_ != x.has_flags_: return 0
    if self.has_flags_ and self.flags_ != x.flags_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    if (not self.has_value_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: value not set.')
    return initialized

  def ByteSize(self):
    n = 0
    n += self.lengthString(len(self.value_))
    if (self.has_flags_): n += 5
    return n + 1

  def ByteSizePartial(self):
    n = 0
    if (self.has_value_):
      n += 1
      n += self.lengthString(len(self.value_))
    if (self.has_flags_): n += 5
    return n

  def Clear(self):
    self.clear_value()
    self.clear_flags()

  def OutputUnchecked(self, out):
    out.putVarInt32(18)
    out.putPrefixedString(self.value_)
    if (self.has_flags_):
      out.putVarInt32(29)
      out.put32(self.flags_)

  def OutputPartial(self, out):
    if (self.has_value_):
      out.putVarInt32(18)
      out.putPrefixedString(self.value_)
    if (self.has_flags_):
      out.putVarInt32(29)
      out.put32(self.flags_)

  def TryMerge(self, d):
    while 1:
      tt = d.getVarInt32()
      if tt == 12: break
      if tt == 18:
        self.set_value(d.getPrefixedString())
        continue
      if tt == 29:
        self.set_flags(d.get32())
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    if self.has_value_: res+=prefix+("value: %s\n" % self.DebugFormatString(self.value_))
    if self.has_flags_: res+=prefix+("flags: %s\n" % self.DebugFormatFixed32(self.flags_))
    return res

class MemcacheGrabTailResponse(ProtocolBuffer.ProtocolMessage):

  def __init__(self, contents=None):
    self.item_ = []
    if contents is not None: self.MergeFromString(contents)

  def item_size(self): return len(self.item_)
  def item_list(self): return self.item_

  def item(self, i):
    return self.item_[i]

  def mutable_item(self, i):
    return self.item_[i]

  def add_item(self):
    x = MemcacheGrabTailResponse_Item()
    self.item_.append(x)
    return x

  def clear_item(self):
    self.item_ = []

  def MergeFrom(self, x):
    assert x is not self
    for i in xrange(x.item_size()): self.add_item().CopyFrom(x.item(i))

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.MemcacheGrabTailResponse', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.MemcacheGrabTailResponse')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.MemcacheGrabTailResponse')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.MemcacheGrabTailResponse', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.MemcacheGrabTailResponse', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.MemcacheGrabTailResponse', s)


  def Equals(self, x):
    if x is self: return 1
    if len(self.item_) != len(x.item_): return 0
    for e1, e2 in zip(self.item_, x.item_):
      if e1 != e2: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    for p in self.item_:
      if not p.IsInitialized(debug_strs): initialized=0
    return initialized

  def ByteSize(self):
    n = 0
    n += 2 * len(self.item_)
    for i in xrange(len(self.item_)): n += self.item_[i].ByteSize()
    return n

  def ByteSizePartial(self):
    n = 0
    n += 2 * len(self.item_)
    for i in xrange(len(self.item_)): n += self.item_[i].ByteSizePartial()
    return n

  def Clear(self):
    self.clear_item()

  def OutputUnchecked(self, out):
    for i in xrange(len(self.item_)):
      out.putVarInt32(11)
      self.item_[i].OutputUnchecked(out)
      out.putVarInt32(12)

  def OutputPartial(self, out):
    for i in xrange(len(self.item_)):
      out.putVarInt32(11)
      self.item_[i].OutputPartial(out)
      out.putVarInt32(12)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 11:
        self.add_item().TryMerge(d)
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    cnt=0
    for e in self.item_:
      elm=""
      if printElemNumber: elm="(%d)" % cnt
      res+=prefix+("Item%s {\n" % elm)
      res+=e.__str__(prefix + "  ", printElemNumber)
      res+=prefix+"}\n"
      cnt+=1
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  kItemGroup = 1
  kItemvalue = 2
  kItemflags = 3

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "Item",
    2: "value",
    3: "flags",
  }, 3)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.STARTGROUP,
    2: ProtocolBuffer.Encoder.STRING,
    3: ProtocolBuffer.Encoder.FLOAT,
  }, 3, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("Wi5hcHBob3N0aW5nL2FwaS9tZW1jYWNoZS9tZW1jYWNoZV9zZXJ2aWNlLnByb3RvCiNhcHBob3N0aW5nLk1lbWNhY2hlR3JhYlRhaWxSZXNwb25zZRMaBEl0ZW0gASgDMAo4AxQTGgpJdGVtLnZhbHVlIAIoAjAJOAJgABQTGgpJdGVtLmZsYWdzIAMoBTAHOAFgABTCAR9hcHBob3N0aW5nLk1lbWNhY2hlU2VydmljZUVycm9y"))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())



class _MemcacheService_ClientBaseStub(_client_stub_base_class):
  """Makes Stubby RPC calls to a MemcacheService server."""

  __slots__ = (
      '_protorpc_Get', '_full_name_Get',
      '_protorpc_Set', '_full_name_Set',
      '_protorpc_Delete', '_full_name_Delete',
      '_protorpc_Increment', '_full_name_Increment',
      '_protorpc_BatchIncrement', '_full_name_BatchIncrement',
      '_protorpc_FlushAll', '_full_name_FlushAll',
      '_protorpc_Stats', '_full_name_Stats',
      '_protorpc_GrabTail', '_full_name_GrabTail',
  )

  def __init__(self, rpc_stub):
    self._stub = rpc_stub

    self._protorpc_Get = pywraprpc.RPC()
    self._full_name_Get = self._stub.GetFullMethodName(
        'Get')

    self._protorpc_Set = pywraprpc.RPC()
    self._full_name_Set = self._stub.GetFullMethodName(
        'Set')

    self._protorpc_Delete = pywraprpc.RPC()
    self._full_name_Delete = self._stub.GetFullMethodName(
        'Delete')

    self._protorpc_Increment = pywraprpc.RPC()
    self._full_name_Increment = self._stub.GetFullMethodName(
        'Increment')

    self._protorpc_BatchIncrement = pywraprpc.RPC()
    self._full_name_BatchIncrement = self._stub.GetFullMethodName(
        'BatchIncrement')

    self._protorpc_FlushAll = pywraprpc.RPC()
    self._full_name_FlushAll = self._stub.GetFullMethodName(
        'FlushAll')

    self._protorpc_Stats = pywraprpc.RPC()
    self._full_name_Stats = self._stub.GetFullMethodName(
        'Stats')

    self._protorpc_GrabTail = pywraprpc.RPC()
    self._full_name_GrabTail = self._stub.GetFullMethodName(
        'GrabTail')

  def Get(self, request, rpc=None, callback=None, response=None):
    """Make a Get RPC call.

    Args:
      request: a MemcacheGetRequest instance.
      rpc: Optional RPC instance to use for the call.
      callback: Optional final callback. Will be called as
          callback(rpc, result) when the rpc completes. If None, the
          call is synchronous.
      response: Optional ProtocolMessage to be filled in with response.

    Returns:
      The MemcacheGetResponse if callback is None. Otherwise, returns None.
    """

    if response is None:
      response = MemcacheGetResponse
    return self._MakeCall(rpc,
                          self._full_name_Get,
                          'Get',
                          request,
                          response,
                          callback,
                          self._protorpc_Get)

  def Set(self, request, rpc=None, callback=None, response=None):
    """Make a Set RPC call.

    Args:
      request: a MemcacheSetRequest instance.
      rpc: Optional RPC instance to use for the call.
      callback: Optional final callback. Will be called as
          callback(rpc, result) when the rpc completes. If None, the
          call is synchronous.
      response: Optional ProtocolMessage to be filled in with response.

    Returns:
      The MemcacheSetResponse if callback is None. Otherwise, returns None.
    """

    if response is None:
      response = MemcacheSetResponse
    return self._MakeCall(rpc,
                          self._full_name_Set,
                          'Set',
                          request,
                          response,
                          callback,
                          self._protorpc_Set)

  def Delete(self, request, rpc=None, callback=None, response=None):
    """Make a Delete RPC call.

    Args:
      request: a MemcacheDeleteRequest instance.
      rpc: Optional RPC instance to use for the call.
      callback: Optional final callback. Will be called as
          callback(rpc, result) when the rpc completes. If None, the
          call is synchronous.
      response: Optional ProtocolMessage to be filled in with response.

    Returns:
      The MemcacheDeleteResponse if callback is None. Otherwise, returns None.
    """

    if response is None:
      response = MemcacheDeleteResponse
    return self._MakeCall(rpc,
                          self._full_name_Delete,
                          'Delete',
                          request,
                          response,
                          callback,
                          self._protorpc_Delete)

  def Increment(self, request, rpc=None, callback=None, response=None):
    """Make a Increment RPC call.

    Args:
      request: a MemcacheIncrementRequest instance.
      rpc: Optional RPC instance to use for the call.
      callback: Optional final callback. Will be called as
          callback(rpc, result) when the rpc completes. If None, the
          call is synchronous.
      response: Optional ProtocolMessage to be filled in with response.

    Returns:
      The MemcacheIncrementResponse if callback is None. Otherwise, returns None.
    """

    if response is None:
      response = MemcacheIncrementResponse
    return self._MakeCall(rpc,
                          self._full_name_Increment,
                          'Increment',
                          request,
                          response,
                          callback,
                          self._protorpc_Increment)

  def BatchIncrement(self, request, rpc=None, callback=None, response=None):
    """Make a BatchIncrement RPC call.

    Args:
      request: a MemcacheBatchIncrementRequest instance.
      rpc: Optional RPC instance to use for the call.
      callback: Optional final callback. Will be called as
          callback(rpc, result) when the rpc completes. If None, the
          call is synchronous.
      response: Optional ProtocolMessage to be filled in with response.

    Returns:
      The MemcacheBatchIncrementResponse if callback is None. Otherwise, returns None.
    """

    if response is None:
      response = MemcacheBatchIncrementResponse
    return self._MakeCall(rpc,
                          self._full_name_BatchIncrement,
                          'BatchIncrement',
                          request,
                          response,
                          callback,
                          self._protorpc_BatchIncrement)

  def FlushAll(self, request, rpc=None, callback=None, response=None):
    """Make a FlushAll RPC call.

    Args:
      request: a MemcacheFlushRequest instance.
      rpc: Optional RPC instance to use for the call.
      callback: Optional final callback. Will be called as
          callback(rpc, result) when the rpc completes. If None, the
          call is synchronous.
      response: Optional ProtocolMessage to be filled in with response.

    Returns:
      The MemcacheFlushResponse if callback is None. Otherwise, returns None.
    """

    if response is None:
      response = MemcacheFlushResponse
    return self._MakeCall(rpc,
                          self._full_name_FlushAll,
                          'FlushAll',
                          request,
                          response,
                          callback,
                          self._protorpc_FlushAll)

  def Stats(self, request, rpc=None, callback=None, response=None):
    """Make a Stats RPC call.

    Args:
      request: a MemcacheStatsRequest instance.
      rpc: Optional RPC instance to use for the call.
      callback: Optional final callback. Will be called as
          callback(rpc, result) when the rpc completes. If None, the
          call is synchronous.
      response: Optional ProtocolMessage to be filled in with response.

    Returns:
      The MemcacheStatsResponse if callback is None. Otherwise, returns None.
    """

    if response is None:
      response = MemcacheStatsResponse
    return self._MakeCall(rpc,
                          self._full_name_Stats,
                          'Stats',
                          request,
                          response,
                          callback,
                          self._protorpc_Stats)

  def GrabTail(self, request, rpc=None, callback=None, response=None):
    """Make a GrabTail RPC call.

    Args:
      request: a MemcacheGrabTailRequest instance.
      rpc: Optional RPC instance to use for the call.
      callback: Optional final callback. Will be called as
          callback(rpc, result) when the rpc completes. If None, the
          call is synchronous.
      response: Optional ProtocolMessage to be filled in with response.

    Returns:
      The MemcacheGrabTailResponse if callback is None. Otherwise, returns None.
    """

    if response is None:
      response = MemcacheGrabTailResponse
    return self._MakeCall(rpc,
                          self._full_name_GrabTail,
                          'GrabTail',
                          request,
                          response,
                          callback,
                          self._protorpc_GrabTail)


class _MemcacheService_ClientStub(_MemcacheService_ClientBaseStub):
  def __init__(self, rpc_stub_parameters, service_name):
    if service_name is None:
      service_name = 'MemcacheService'
    _MemcacheService_ClientBaseStub.__init__(self, pywraprpc.RPC_GenericStub(service_name, rpc_stub_parameters))
    self._params = rpc_stub_parameters


class _MemcacheService_RPC2ClientStub(_MemcacheService_ClientBaseStub):
  def __init__(self, server, channel, service_name):
    if service_name is None:
      service_name = 'MemcacheService'
    if channel is not None:
      if channel.version() == 1:
        raise RuntimeError('Expecting an RPC2 channel to create the stub')
      _MemcacheService_ClientBaseStub.__init__(self, pywraprpc.RPC_GenericStub(service_name, channel))
    elif server is not None:
      _MemcacheService_ClientBaseStub.__init__(self, pywraprpc.RPC_GenericStub(service_name, pywraprpc.NewClientChannel(server)))
    else:
      raise RuntimeError('Invalid argument combination to create a stub')


class MemcacheService(_server_stub_base_class):
  """Base class for MemcacheService Stubby servers."""

  def __init__(self, *args, **kwargs):
    """Creates a Stubby RPC server.

    See BaseRpcServer.__init__ in rpcserver.py for detail on arguments.
    """
    if _server_stub_base_class is object:
      raise NotImplementedError('Add //net/rpc/python:rpcserver as a '
                                'dependency for Stubby server support.')
    _server_stub_base_class.__init__(self, 'apphosting.MemcacheService', *args, **kwargs)

  @staticmethod
  def NewStub(rpc_stub_parameters, service_name=None):
    """Creates a new MemcacheService Stubby client stub.

    Args:
      rpc_stub_parameters: an RPC_StubParameter instance.
      service_name: the service name used by the Stubby server.
    """

    if _client_stub_base_class is object:
      raise RuntimeError('Add //net/rpc/python as a dependency to use Stubby')
    return _MemcacheService_ClientStub(rpc_stub_parameters, service_name)

  @staticmethod
  def NewRPC2Stub(server=None, channel=None, service_name=None):
    """Creates a new MemcacheService Stubby2 client stub.

    Args:
      server: host:port or bns address.
      channel: directly use a channel to create a stub. Will ignore server
          argument if this is specified.
      service_name: the service name used by the Stubby server.
    """

    if _client_stub_base_class is object:
      raise RuntimeError('Add //net/rpc/python as a dependency to use Stubby')
    return _MemcacheService_RPC2ClientStub(server, channel, service_name)

  def Get(self, rpc, request, response):
    """Handles a Get RPC call. You should override this.

    Args:
      rpc: a Stubby RPC object
      request: a MemcacheGetRequest that contains the client request
      response: a MemcacheGetResponse that should be modified to send the response
    """
    raise NotImplementedError


  def Set(self, rpc, request, response):
    """Handles a Set RPC call. You should override this.

    Args:
      rpc: a Stubby RPC object
      request: a MemcacheSetRequest that contains the client request
      response: a MemcacheSetResponse that should be modified to send the response
    """
    raise NotImplementedError


  def Delete(self, rpc, request, response):
    """Handles a Delete RPC call. You should override this.

    Args:
      rpc: a Stubby RPC object
      request: a MemcacheDeleteRequest that contains the client request
      response: a MemcacheDeleteResponse that should be modified to send the response
    """
    raise NotImplementedError


  def Increment(self, rpc, request, response):
    """Handles a Increment RPC call. You should override this.

    Args:
      rpc: a Stubby RPC object
      request: a MemcacheIncrementRequest that contains the client request
      response: a MemcacheIncrementResponse that should be modified to send the response
    """
    raise NotImplementedError


  def BatchIncrement(self, rpc, request, response):
    """Handles a BatchIncrement RPC call. You should override this.

    Args:
      rpc: a Stubby RPC object
      request: a MemcacheBatchIncrementRequest that contains the client request
      response: a MemcacheBatchIncrementResponse that should be modified to send the response
    """
    raise NotImplementedError


  def FlushAll(self, rpc, request, response):
    """Handles a FlushAll RPC call. You should override this.

    Args:
      rpc: a Stubby RPC object
      request: a MemcacheFlushRequest that contains the client request
      response: a MemcacheFlushResponse that should be modified to send the response
    """
    raise NotImplementedError


  def Stats(self, rpc, request, response):
    """Handles a Stats RPC call. You should override this.

    Args:
      rpc: a Stubby RPC object
      request: a MemcacheStatsRequest that contains the client request
      response: a MemcacheStatsResponse that should be modified to send the response
    """
    raise NotImplementedError


  def GrabTail(self, rpc, request, response):
    """Handles a GrabTail RPC call. You should override this.

    Args:
      rpc: a Stubby RPC object
      request: a MemcacheGrabTailRequest that contains the client request
      response: a MemcacheGrabTailResponse that should be modified to send the response
    """
    raise NotImplementedError

  def _AddMethodAttributes(self):
    """Sets attributes on Python RPC handlers.

    See BaseRpcServer in rpcserver.py for details.
    """
    rpcserver._GetHandlerDecorator(
        self.Get.im_func,
        MemcacheGetRequest,
        MemcacheGetResponse,
        None,
        'none')
    rpcserver._GetHandlerDecorator(
        self.Set.im_func,
        MemcacheSetRequest,
        MemcacheSetResponse,
        None,
        'none')
    rpcserver._GetHandlerDecorator(
        self.Delete.im_func,
        MemcacheDeleteRequest,
        MemcacheDeleteResponse,
        None,
        'none')
    rpcserver._GetHandlerDecorator(
        self.Increment.im_func,
        MemcacheIncrementRequest,
        MemcacheIncrementResponse,
        None,
        'none')
    rpcserver._GetHandlerDecorator(
        self.BatchIncrement.im_func,
        MemcacheBatchIncrementRequest,
        MemcacheBatchIncrementResponse,
        None,
        'none')
    rpcserver._GetHandlerDecorator(
        self.FlushAll.im_func,
        MemcacheFlushRequest,
        MemcacheFlushResponse,
        None,
        'none')
    rpcserver._GetHandlerDecorator(
        self.Stats.im_func,
        MemcacheStatsRequest,
        MemcacheStatsResponse,
        None,
        'none')
    rpcserver._GetHandlerDecorator(
        self.GrabTail.im_func,
        MemcacheGrabTailRequest,
        MemcacheGrabTailResponse,
        None,
        'none')


__all__ = ['MemcacheServiceError','AppOverride','MemcacheGetRequest','MemcacheGetResponse','MemcacheGetResponse_Item','MemcacheSetRequest','MemcacheSetRequest_Item','MemcacheSetResponse','MemcacheDeleteRequest','MemcacheDeleteRequest_Item','MemcacheDeleteResponse','MemcacheIncrementRequest','MemcacheIncrementResponse','MemcacheBatchIncrementRequest','MemcacheBatchIncrementResponse','MemcacheFlushRequest','MemcacheFlushResponse','MemcacheStatsRequest','MergedNamespaceStats','MemcacheStatsResponse','MemcacheGrabTailRequest','MemcacheGrabTailResponse','MemcacheGrabTailResponse_Item','MemcacheService']
