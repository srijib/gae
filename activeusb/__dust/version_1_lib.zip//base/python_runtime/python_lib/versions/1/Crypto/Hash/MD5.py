
# Just use the MD5 module from the Python standard library

__revision__ = "$Id: MD5.py,v 1.4 2002/07/11 14:31:19 akuchling Exp $"

import hashlib

digest_size = 16
new = hashlib.md5
md5 = hashlib.md5
