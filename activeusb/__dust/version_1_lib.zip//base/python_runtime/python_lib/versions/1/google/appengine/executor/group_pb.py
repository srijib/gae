#!/usr/bin/env python
#
# Copyright 2007 Google Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#



from google.net.proto import ProtocolBuffer
import array
import base64
import dummy_thread as thread
try:
  from google3.net.proto import _net_proto___parse__python
except ImportError:
  _net_proto___parse__python = None

__pychecker__ = """maxreturns=0 maxbranches=0 no-callinit
                   unusednames=printElemNumber,debug_strs no-special"""

class GroupRef(ProtocolBuffer.ProtocolMessage):
  has_customer_ = 0
  customer_ = ""
  has_name_ = 0
  name_ = ""

  def __init__(self, contents=None):
    if contents is not None: self.MergeFromString(contents)

  def customer(self): return self.customer_

  def set_customer(self, x):
    self.has_customer_ = 1
    self.customer_ = x

  def clear_customer(self):
    if self.has_customer_:
      self.has_customer_ = 0
      self.customer_ = ""

  def has_customer(self): return self.has_customer_

  def name(self): return self.name_

  def set_name(self, x):
    self.has_name_ = 1
    self.name_ = x

  def clear_name(self):
    if self.has_name_:
      self.has_name_ = 0
      self.name_ = ""

  def has_name(self): return self.has_name_


  def MergeFrom(self, x):
    assert x is not self
    if (x.has_customer()): self.set_customer(x.customer())
    if (x.has_name()): self.set_name(x.name())

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.GroupRef', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.GroupRef')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.GroupRef')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.GroupRef', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.GroupRef', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.GroupRef', s)


  def Equals(self, x):
    if x is self: return 1
    if self.has_customer_ != x.has_customer_: return 0
    if self.has_customer_ and self.customer_ != x.customer_: return 0
    if self.has_name_ != x.has_name_: return 0
    if self.has_name_ and self.name_ != x.name_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    if (not self.has_customer_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: customer not set.')
    if (not self.has_name_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: name not set.')
    return initialized

  def ByteSize(self):
    n = 0
    n += self.lengthString(len(self.customer_))
    n += self.lengthString(len(self.name_))
    return n + 2

  def ByteSizePartial(self):
    n = 0
    if (self.has_customer_):
      n += 1
      n += self.lengthString(len(self.customer_))
    if (self.has_name_):
      n += 1
      n += self.lengthString(len(self.name_))
    return n

  def Clear(self):
    self.clear_customer()
    self.clear_name()

  def OutputUnchecked(self, out):
    out.putVarInt32(10)
    out.putPrefixedString(self.customer_)
    out.putVarInt32(18)
    out.putPrefixedString(self.name_)

  def OutputPartial(self, out):
    if (self.has_customer_):
      out.putVarInt32(10)
      out.putPrefixedString(self.customer_)
    if (self.has_name_):
      out.putVarInt32(18)
      out.putPrefixedString(self.name_)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 10:
        self.set_customer(d.getPrefixedString())
        continue
      if tt == 18:
        self.set_name(d.getPrefixedString())
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    if self.has_customer_: res+=prefix+("customer: %s\n" % self.DebugFormatString(self.customer_))
    if self.has_name_: res+=prefix+("name: %s\n" % self.DebugFormatString(self.name_))
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  kcustomer = 1
  kname = 2

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "customer",
    2: "name",
  }, 2)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.STRING,
    2: ProtocolBuffer.Encoder.STRING,
  }, 2, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("Wh9hcHBob3N0aW5nL2V4ZWN1dG9yL2dyb3VwLnByb3RvChNhcHBob3N0aW5nLkdyb3VwUmVmExoIY3VzdG9tZXIgASgCMAk4AhQTGgRuYW1lIAIoAjAJOAIUugG9AQofYXBwaG9zdGluZy9leGVjdXRvci9ncm91cC5wcm90bxIKYXBwaG9zdGluZyIqCghHcm91cFJlZhIQCghjdXN0b21lchgBIAIoDBIMCgRuYW1lGAIgAigMIjoKD0dyb3VwRGVmaW5pdGlvbhInCglncm91cF9yZWYYASACKAsyFC5hcHBob3N0aW5nLkdyb3VwUmVmQiYKHmNvbS5nb29nbGUuYXBwaG9zdGluZy5leGVjdXRvchABIAEoAQ=="))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class GroupDefinition(ProtocolBuffer.ProtocolMessage):
  has_group_ref_ = 0

  def __init__(self, contents=None):
    self.group_ref_ = GroupRef()
    if contents is not None: self.MergeFromString(contents)

  def group_ref(self): return self.group_ref_

  def mutable_group_ref(self): self.has_group_ref_ = 1; return self.group_ref_

  def clear_group_ref(self):self.has_group_ref_ = 0; self.group_ref_.Clear()

  def has_group_ref(self): return self.has_group_ref_


  def MergeFrom(self, x):
    assert x is not self
    if (x.has_group_ref()): self.mutable_group_ref().MergeFrom(x.group_ref())

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.GroupDefinition', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.GroupDefinition')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.GroupDefinition')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.GroupDefinition', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.GroupDefinition', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.GroupDefinition', s)


  def Equals(self, x):
    if x is self: return 1
    if self.has_group_ref_ != x.has_group_ref_: return 0
    if self.has_group_ref_ and self.group_ref_ != x.group_ref_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    if (not self.has_group_ref_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: group_ref not set.')
    elif not self.group_ref_.IsInitialized(debug_strs): initialized = 0
    return initialized

  def ByteSize(self):
    n = 0
    n += self.lengthString(self.group_ref_.ByteSize())
    return n + 1

  def ByteSizePartial(self):
    n = 0
    if (self.has_group_ref_):
      n += 1
      n += self.lengthString(self.group_ref_.ByteSizePartial())
    return n

  def Clear(self):
    self.clear_group_ref()

  def OutputUnchecked(self, out):
    out.putVarInt32(10)
    out.putVarInt32(self.group_ref_.ByteSize())
    self.group_ref_.OutputUnchecked(out)

  def OutputPartial(self, out):
    if (self.has_group_ref_):
      out.putVarInt32(10)
      out.putVarInt32(self.group_ref_.ByteSizePartial())
      self.group_ref_.OutputPartial(out)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 10:
        length = d.getVarInt32()
        tmp = ProtocolBuffer.Decoder(d.buffer(), d.pos(), d.pos() + length)
        d.skip(length)
        self.mutable_group_ref().TryMerge(tmp)
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    if self.has_group_ref_:
      res+=prefix+"group_ref <\n"
      res+=self.group_ref_.__str__(prefix + "  ", printElemNumber)
      res+=prefix+">\n"
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  kgroup_ref = 1

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "group_ref",
  }, 1)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.STRING,
  }, 1, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("Wh9hcHBob3N0aW5nL2V4ZWN1dG9yL2dyb3VwLnByb3RvChphcHBob3N0aW5nLkdyb3VwRGVmaW5pdGlvbhMaCWdyb3VwX3JlZiABKAIwCzgCShNhcHBob3N0aW5nLkdyb3VwUmVmFMIBE2FwcGhvc3RpbmcuR3JvdXBSZWY="))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())


__all__ = ['GroupRef','GroupDefinition']
