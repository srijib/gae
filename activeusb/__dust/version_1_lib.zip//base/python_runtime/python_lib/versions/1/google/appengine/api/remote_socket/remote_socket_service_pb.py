#!/usr/bin/env python
#
# Copyright 2007 Google Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#



from google.net.proto import ProtocolBuffer
import array
import base64
import dummy_thread as thread
try:
  from google3.net.proto import _net_proto___parse__python
except ImportError:
  _net_proto___parse__python = None
import sys
try:
  __import__('google.net.rpc.python.rpc_internals_lite')
  __import__('google.net.rpc.python.pywraprpc_lite')
  rpc_internals = sys.modules.get('google.net.rpc.python.rpc_internals_lite')
  pywraprpc = sys.modules.get('google.net.rpc.python.pywraprpc_lite')
  _client_stub_base_class = rpc_internals.StubbyRPCBaseStub
except ImportError:
  _client_stub_base_class = object
try:
  __import__('google.net.rpc.python.rpcserver')
  rpcserver = sys.modules.get('google.net.rpc.python.rpcserver')
  _server_stub_base_class = rpcserver.BaseRpcServer
except ImportError:
  _server_stub_base_class = object

__pychecker__ = """maxreturns=0 maxbranches=0 no-callinit
                   unusednames=printElemNumber,debug_strs no-special"""

class RemoteSocketServiceError(ProtocolBuffer.ProtocolMessage):


  SYSTEM_ERROR =    1
  GAI_ERROR    =    2
  SSL_ERROR    =    3
  FAILURE      =    4
  PERMISSION_DENIED =    5
  INVALID_REQUEST =    6
  SOCKET_CLOSED =    7

  _ErrorCode_NAMES = {
    1: "SYSTEM_ERROR",
    2: "GAI_ERROR",
    3: "SSL_ERROR",
    4: "FAILURE",
    5: "PERMISSION_DENIED",
    6: "INVALID_REQUEST",
    7: "SOCKET_CLOSED",
  }

  def ErrorCode_Name(cls, x): return cls._ErrorCode_NAMES.get(x, "")
  ErrorCode_Name = classmethod(ErrorCode_Name)

  has_system_error_ = 0
  system_error_ = 0
  has_error_detail_ = 0
  error_detail_ = ""

  def __init__(self, contents=None):
    if contents is not None: self.MergeFromString(contents)

  def system_error(self): return self.system_error_

  def set_system_error(self, x):
    self.has_system_error_ = 1
    self.system_error_ = x

  def clear_system_error(self):
    if self.has_system_error_:
      self.has_system_error_ = 0
      self.system_error_ = 0

  def has_system_error(self): return self.has_system_error_

  def error_detail(self): return self.error_detail_

  def set_error_detail(self, x):
    self.has_error_detail_ = 1
    self.error_detail_ = x

  def clear_error_detail(self):
    if self.has_error_detail_:
      self.has_error_detail_ = 0
      self.error_detail_ = ""

  def has_error_detail(self): return self.has_error_detail_


  def MergeFrom(self, x):
    assert x is not self
    if (x.has_system_error()): self.set_system_error(x.system_error())
    if (x.has_error_detail()): self.set_error_detail(x.error_detail())

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.RemoteSocketServiceError', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.RemoteSocketServiceError')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.RemoteSocketServiceError')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.RemoteSocketServiceError', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.RemoteSocketServiceError', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.RemoteSocketServiceError', s)


  def Equals(self, x):
    if x is self: return 1
    if self.has_system_error_ != x.has_system_error_: return 0
    if self.has_system_error_ and self.system_error_ != x.system_error_: return 0
    if self.has_error_detail_ != x.has_error_detail_: return 0
    if self.has_error_detail_ and self.error_detail_ != x.error_detail_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    return initialized

  def ByteSize(self):
    n = 0
    if (self.has_system_error_): n += 1 + self.lengthVarInt64(self.system_error_)
    if (self.has_error_detail_): n += 1 + self.lengthString(len(self.error_detail_))
    return n

  def ByteSizePartial(self):
    n = 0
    if (self.has_system_error_): n += 1 + self.lengthVarInt64(self.system_error_)
    if (self.has_error_detail_): n += 1 + self.lengthString(len(self.error_detail_))
    return n

  def Clear(self):
    self.clear_system_error()
    self.clear_error_detail()

  def OutputUnchecked(self, out):
    if (self.has_system_error_):
      out.putVarInt32(8)
      out.putVarInt32(self.system_error_)
    if (self.has_error_detail_):
      out.putVarInt32(18)
      out.putPrefixedString(self.error_detail_)

  def OutputPartial(self, out):
    if (self.has_system_error_):
      out.putVarInt32(8)
      out.putVarInt32(self.system_error_)
    if (self.has_error_detail_):
      out.putVarInt32(18)
      out.putPrefixedString(self.error_detail_)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 8:
        self.set_system_error(d.getVarInt32())
        continue
      if tt == 18:
        self.set_error_detail(d.getPrefixedString())
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    if self.has_system_error_: res+=prefix+("system_error: %s\n" % self.DebugFormatInt32(self.system_error_))
    if self.has_error_detail_: res+=prefix+("error_detail: %s\n" % self.DebugFormatString(self.error_detail_))
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  ksystem_error = 1
  kerror_detail = 2

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "system_error",
    2: "error_detail",
  }, 2)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.NUMERIC,
    2: ProtocolBuffer.Encoder.STRING,
  }, 2, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("WjhhcHBob3N0aW5nL2FwaS9yZW1vdGVfc29ja2V0L3JlbW90ZV9zb2NrZXRfc2VydmljZS5wcm90bwojYXBwaG9zdGluZy5SZW1vdGVTb2NrZXRTZXJ2aWNlRXJyb3ITGgxzeXN0ZW1fZXJyb3IgASgAMAU4AUIBMKMBqgEHZGVmYXVsdLIBATCkARQTGgxlcnJvcl9kZXRhaWwgAigCMAk4ARRzeglFcnJvckNvZGWLAZIBDFNZU1RFTV9FUlJPUpgBAYwBiwGSAQlHQUlfRVJST1KYAQKMAYsBkgEJU1NMX0VSUk9SmAEDjAGLAZIBB0ZBSUxVUkWYAQSMAYsBkgERUEVSTUlTU0lPTl9ERU5JRUSYAQWMAYsBkgEPSU5WQUxJRF9SRVFVRVNUmAEGjAGLAZIBDVNPQ0tFVF9DTE9TRUSYAQeMAXS6AYQ3CjhhcHBob3N0aW5nL2FwaS9yZW1vdGVfc29ja2V0L3JlbW90ZV9zb2NrZXRfc2VydmljZS5wcm90bxIKYXBwaG9zdGluZyLTAQoYUmVtb3RlU29ja2V0U2VydmljZUVycm9yEhcKDHN5c3RlbV9lcnJvchgBIAEoBToBMBIUCgxlcnJvcl9kZXRhaWwYAiABKAkihwEKCUVycm9yQ29kZRIQCgxTWVNURU1fRVJST1IQARINCglHQUlfRVJST1IQAhINCglTU0xfRVJST1IQAxILCgdGQUlMVVJFEAQSFQoRUEVSTUlTU0lPTl9ERU5JRUQQBRITCg9JTlZBTElEX1JFUVVFU1QQBhIRCg1TT0NLRVRfQ0xPU0VEEAciMwoLQWRkcmVzc1BvcnQSDAoEcG9ydBgBIAIoBRIWCg5wYWNrZWRfYWRkcmVzcxgCIAEoDCLTAwoKU1NMQ29udGV4dBIzCgtzc2xfdmVyc2lvbhgBIAEoDjIeLmFwcGhvc3RpbmcuU1NMQ29udGV4dC5WZXJzaW9uEjYKDXNzbF9wZWVyX2F1dGgYAiABKA4yHy5hcHBob3N0aW5nLlNTTENvbnRleHQuUGVlckF1dGgSEwoLc3NsX2NpcGhlcnMYAyABKAkSFwoPc2VydmVyX2hvc3RuYW1lGAQgASgJEhoKEmNsaWVudF9jZXJ0aWZpY2F0ZRgFIAEoCRIaChJjbGllbnRfcHJpdmF0ZV9rZXkYBiABKAkSHgoWdHJ1c3RlZF9jYV9jZXJ0aWZpY2F0ZRgHIAMoCSKEAQoHVmVyc2lvbhIWChJTU0xfUFJPVE9DT0xfU1NMdjIQARIWChJTU0xfUFJPVE9DT0xfU1NMdjMQAhIXChNTU0xfUFJPVE9DT0xfU1NMdjIzEAMSFgoSU1NMX1BST1RPQ09MX1RMU3YxEAQSGAoUU1NMX1BST1RPQ09MX05PU1NMdjIQBSJLCghQZWVyQXV0aBIRCg1TU0xfQ0VSVF9OT05FEAESFQoRU1NMX0NFUlRfT1BUSU9OQUwQAhIVChFTU0xfQ0VSVF9SRVFVSVJFRBADIvgDCgpTU0xTZXNzaW9uEhgKEHBlZXJfY2VydGlmaWNhdGUYASABKAkSIAoYcGVlcl9jZXJ0aWZpY2F0ZV9zdWJqZWN0GAIgASgJEh8KF3BlZXJfY2VydGlmaWNhdGVfaXNzdWVyGAMgASgJEikKIXBlZXJfY2VydGlmaWNhdGVfc3ViamVjdF9hbHRfbmFtZRgEIAMoCRIeChZwZWVyX2NlcnRpZmljYXRlX2NoYWluGAUgAygJEhIKCnNzbF9jaXBoZXIYBiABKAkSGgoSc3NsX2NpcGhlcl92ZXJzaW9uGAcgASgJEhsKE3NzbF9jaXBoZXJfa2V5X2JpdHMYCCABKAUi9AEKCUVycm9yQ29kZRIZChVTU0xfRVJST1JfWkVST19SRVRVUk4QARIXChNTU0xfRVJST1JfV0FOVF9SRUFEEAISGAoUU1NMX0VSUk9SX1dBTlRfV1JJVEUQAxIeChpTU0xfRVJST1JfV0FOVF9YNTA5X0xPT0tVUBAEEhUKEVNTTF9FUlJPUl9TWVNDQUxMEAUSEQoNU1NMX0VSUk9SX1NTTBAGEhoKFlNTTF9FUlJPUl9XQU5UX0NPTk5FQ1QQBxIRCg1TU0xfRVJST1JfRU9GEAgSIAocU1NMX0VSUk9SX0lOVkFMSURfRVJST1JfQ09ERRAJItADChNDcmVhdGVTb2NrZXRSZXF1ZXN0EjwKBmZhbWlseRgBIAIoDjIsLmFwcGhvc3RpbmcuQ3JlYXRlU29ja2V0UmVxdWVzdC5Tb2NrZXRGYW1pbHkSQAoIcHJvdG9jb2wYAiACKA4yLi5hcHBob3N0aW5nLkNyZWF0ZVNvY2tldFJlcXVlc3QuU29ja2V0UHJvdG9jb2wSMAoOc29ja2V0X29wdGlvbnMYAyADKAsyGC5hcHBob3N0aW5nLlNvY2tldE9wdGlvbhIyChFwcm94eV9leHRlcm5hbF9pcBgEIAEoCzIXLmFwcGhvc3RpbmcuQWRkcmVzc1BvcnQSGQoObGlzdGVuX2JhY2tsb2cYBSABKAU6ATASKgoJcmVtb3RlX2lwGAYgASgLMhcuYXBwaG9zdGluZy5BZGRyZXNzUG9ydBIbCg90aW1lb3V0X3NlY29uZHMYByABKAE6Ai0xEicKB3NzbF9jdHgYCCABKAsyFi5hcHBob3N0aW5nLlNTTENvbnRleHQiIgoMU29ja2V0RmFtaWx5EggKBElQdjQQARIICgRJUHY2EAIiIgoOU29ja2V0UHJvdG9jb2wSBwoDVENQEAESBwoDVURQEAIiWwoRQ3JlYXRlU29ja2V0UmVwbHkSGQoRc29ja2V0X2Rlc2NyaXB0b3IYASABKAkSKwoLc3NsX3Nlc3Npb24YAiABKAsyFi5hcHBob3N0aW5nLlNTTFNlc3Npb24iXAoLQmluZFJlcXVlc3QSGQoRc29ja2V0X2Rlc2NyaXB0b3IYASACKAkSMgoRcHJveHlfZXh0ZXJuYWxfaXAYAiACKAsyFy5hcHBob3N0aW5nLkFkZHJlc3NQb3J0IgsKCUJpbmRSZXBseSIxChRHZXRTb2NrZXROYW1lUmVxdWVzdBIZChFzb2NrZXRfZGVzY3JpcHRvchgBIAIoCSJIChJHZXRTb2NrZXROYW1lUmVwbHkSMgoRcHJveHlfZXh0ZXJuYWxfaXAYAiABKAsyFy5hcHBob3N0aW5nLkFkZHJlc3NQb3J0Ii8KEkdldFBlZXJOYW1lUmVxdWVzdBIZChFzb2NrZXRfZGVzY3JpcHRvchgBIAIoCSI8ChBHZXRQZWVyTmFtZVJlcGx5EigKB3BlZXJfaXAYAiABKAsyFy5hcHBob3N0aW5nLkFkZHJlc3NQb3J0ItcGCgxTb2NrZXRPcHRpb24SOQoFbGV2ZWwYASACKA4yKi5hcHBob3N0aW5nLlNvY2tldE9wdGlvbi5Tb2NrZXRPcHRpb25MZXZlbBI5CgZvcHRpb24YAiACKA4yKS5hcHBob3N0aW5nLlNvY2tldE9wdGlvbi5Tb2NrZXRPcHRpb25OYW1lEg0KBXZhbHVlGAMgAigMImUKEVNvY2tldE9wdGlvbkxldmVsEhEKDVNPQ0tFVF9TT0xfSVAQABIVChFTT0NLRVRfU09MX1NPQ0tFVBABEhIKDlNPQ0tFVF9TT0xfVENQEAYSEgoOU09DS0VUX1NPTF9VRFAQESLaBAoQU29ja2V0T3B0aW9uTmFtZRITCg9TT0NLRVRfU09fREVCVUcQARIXChNTT0NLRVRfU09fUkVVU0VBRERSEAISEgoOU09DS0VUX1NPX1RZUEUQAxITCg9TT0NLRVRfU09fRVJST1IQBBIXChNTT0NLRVRfU09fRE9OVFJPVVRFEAUSFwoTU09DS0VUX1NPX0JST0FEQ0FTVBAGEhQKEFNPQ0tFVF9TT19TTkRCVUYQBxIUChBTT0NLRVRfU09fUkNWQlVGEAgSFwoTU09DS0VUX1NPX0tFRVBBTElWRRAJEhEKDVNPQ0tFVF9JUF9UT1MQARIRCg1TT0NLRVRfSVBfVFRMEAISFQoRU09DS0VUX0lQX0hEUklOQ0wQAxIVChFTT0NLRVRfSVBfT1BUSU9OUxAEEhYKElNPQ0tFVF9UQ1BfTk9ERUxBWRABEhUKEVNPQ0tFVF9UQ1BfTUFYU0VHEAISEwoPU09DS0VUX1RDUF9DT1JLEAMSFwoTU09DS0VUX1RDUF9LRUVQSURMRRAEEhgKFFNPQ0tFVF9UQ1BfS0VFUElOVFZMEAUSFgoSU09DS0VUX1RDUF9LRUVQQ05UEAYSFQoRU09DS0VUX1RDUF9TWU5DTlQQBxIWChJTT0NLRVRfVENQX0xJTkdFUjIQCBIbChdTT0NLRVRfVENQX0RFRkVSX0FDQ0VQVBAJEhsKF1NPQ0tFVF9UQ1BfV0lORE9XX0NMQU1QEAoSEwoPU09DS0VUX1RDUF9JTkZPEAsSFwoTU09DS0VUX1RDUF9RVUlDS0FDSxAMIl8KF1NldFNvY2tldE9wdGlvbnNSZXF1ZXN0EhkKEXNvY2tldF9kZXNjcmlwdG9yGAEgAigJEikKB29wdGlvbnMYAiADKAsyGC5hcHBob3N0aW5nLlNvY2tldE9wdGlvbiIXChVTZXRTb2NrZXRPcHRpb25zUmVwbHkiXwoXR2V0U29ja2V0T3B0aW9uc1JlcXVlc3QSGQoRc29ja2V0X2Rlc2NyaXB0b3IYASACKAkSKQoHb3B0aW9ucxgCIAMoCzIYLmFwcGhvc3RpbmcuU29ja2V0T3B0aW9uIkIKFUdldFNvY2tldE9wdGlvbnNSZXBseRIpCgdvcHRpb25zGAIgAygLMhguYXBwaG9zdGluZy5Tb2NrZXRPcHRpb24idAoOQ29ubmVjdFJlcXVlc3QSGQoRc29ja2V0X2Rlc2NyaXB0b3IYASACKAkSKgoJcmVtb3RlX2lwGAIgAigLMhcuYXBwaG9zdGluZy5BZGRyZXNzUG9ydBIbCg90aW1lb3V0X3NlY29uZHMYAyABKAE6Ai0xIjsKDENvbm5lY3RSZXBseRIrCgtzc2xfc2Vzc2lvbhgBIAEoCzIWLmFwcGhvc3RpbmcuU1NMU2Vzc2lvbiI7Cg1MaXN0ZW5SZXF1ZXN0EhkKEXNvY2tldF9kZXNjcmlwdG9yGAEgAigJEg8KB2JhY2tsb2cYAiACKAUiDQoLTGlzdGVuUmVwbHkiRwoNQWNjZXB0UmVxdWVzdBIZChFzb2NrZXRfZGVzY3JpcHRvchgBIAIoCRIbCg90aW1lb3V0X3NlY29uZHMYAiABKAE6Ai0xIl0KC0FjY2VwdFJlcGx5Eh0KFW5ld19zb2NrZXRfZGVzY3JpcHRvchgCIAEoDBIvCg5yZW1vdGVfYWRkcmVzcxgDIAEoCzIXLmFwcGhvc3RpbmcuQWRkcmVzc1BvcnQitAEKD1NodXREb3duUmVxdWVzdBIZChFzb2NrZXRfZGVzY3JpcHRvchgBIAIoCRIsCgNob3cYAiACKA4yHy5hcHBob3N0aW5nLlNodXREb3duUmVxdWVzdC5Ib3cSEwoLc2VuZF9vZmZzZXQYAyACKAMiQwoDSG93EhIKDlNPQ0tFVF9TSFVUX1JEEAESEgoOU09DS0VUX1NIVVRfV1IQAhIUChBTT0NLRVRfU0hVVF9SRFdSEAMiDwoNU2h1dERvd25SZXBseSJCCgxDbG9zZVJlcXVlc3QSGQoRc29ja2V0X2Rlc2NyaXB0b3IYASACKAkSFwoLc2VuZF9vZmZzZXQYAiABKAM6Ai0xIgwKCkNsb3NlUmVwbHkiqgEKC1NlbmRSZXF1ZXN0EhkKEXNvY2tldF9kZXNjcmlwdG9yGAEgAigJEhAKBGRhdGEYAiACKAxCAggBEhUKDXN0cmVhbV9vZmZzZXQYAyACKAMSEAoFZmxhZ3MYBCABKAU6ATASKAoHc2VuZF90bxgFIAEoCzIXLmFwcGhvc3RpbmcuQWRkcmVzc1BvcnQSGwoPdGltZW91dF9zZWNvbmRzGAYgASgBOgItMSIeCglTZW5kUmVwbHkSEQoJZGF0YV9zZW50GAEgASgFIoMBCg5SZWNlaXZlUmVxdWVzdBIZChFzb2NrZXRfZGVzY3JpcHRvchgBIAIoCRIRCglkYXRhX3NpemUYAiACKAUSEAoFZmxhZ3MYAyABKAU6ATASFAoMcmVjZWl2ZV9mcm9tGAQgASgIEhsKD3RpbWVvdXRfc2Vjb25kcxgFIAEoAToCLTEiZwoMUmVjZWl2ZVJlcGx5EhUKDXN0cmVhbV9vZmZzZXQYAiABKAMSEAoEZGF0YRgDIAEoDEICCAESLgoNcmVjZWl2ZWRfZnJvbRgEIAEoCzIXLmFwcGhvc3RpbmcuQWRkcmVzc1BvcnQihwQKCVBvbGxFdmVudBIZChFzb2NrZXRfZGVzY3JpcHRvchgBIAIoCRJOChByZXF1ZXN0ZWRfZXZlbnRzGAIgAigOMiMuYXBwaG9zdGluZy5Qb2xsRXZlbnQuUG9sbEV2ZW50RmxhZzoPU09DS0VUX1BPTExOT05FEk0KD29ic2VydmVkX2V2ZW50cxgDIAIoDjIjLmFwcGhvc3RpbmcuUG9sbEV2ZW50LlBvbGxFdmVudEZsYWc6D1NPQ0tFVF9QT0xMTk9ORSK/AgoNUG9sbEV2ZW50RmxhZxITCg9TT0NLRVRfUE9MTE5PTkUQABIRCg1TT0NLRVRfUE9MTElOEAESEgoOU09DS0VUX1BPTExQUkkQAhISCg5TT0NLRVRfUE9MTE9VVBAEEhIKDlNPQ0tFVF9QT0xMRVJSEAgSEgoOU09DS0VUX1BPTExIVVAQEBITCg9TT0NLRVRfUE9MTE5WQUwQIBIVChFTT0NLRVRfUE9MTFJETk9STRBAEhYKEVNPQ0tFVF9QT0xMUkRCQU5EEIABEhYKEVNPQ0tFVF9QT0xMV1JOT1JNEIACEhYKEVNPQ0tFVF9QT0xMV1JCQU5EEIAEEhMKDlNPQ0tFVF9QT0xMTVNHEIAIEhYKEVNPQ0tFVF9QT0xMUkVNT1ZFEIAgEhUKEFNPQ0tFVF9QT0xMUkRIVVAQgEAiUQoLUG9sbFJlcXVlc3QSJQoGZXZlbnRzGAEgAygLMhUuYXBwaG9zdGluZy5Qb2xsRXZlbnQSGwoPdGltZW91dF9zZWNvbmRzGAIgASgBOgItMSIyCglQb2xsUmVwbHkSJQoGZXZlbnRzGAIgAygLMhUuYXBwaG9zdGluZy5Qb2xsRXZlbnQiTwoUVXBkYXRlU2Vzc2lvblJlcXVlc3QSGQoRc29ja2V0X2Rlc2NyaXB0b3IYASADKAkSHAoPdGltZW91dF9zZWNvbmRzGAIgASgBOgMxMjAiFAoSVXBkYXRlU2Vzc2lvblJlcGx5ImYKDlJlc29sdmVSZXF1ZXN0EgwKBG5hbWUYASACKAkSRgoQYWRkcmVzc19mYW1pbGllcxgCIAMoDjIsLmFwcGhvc3RpbmcuQ3JlYXRlU29ja2V0UmVxdWVzdC5Tb2NrZXRGYW1pbHkivwMKDFJlc29sdmVSZXBseRIWCg5wYWNrZWRfYWRkcmVzcxgCIAMoCRIWCg5jYW5vbmljYWxfbmFtZRgDIAEoCRIPCgdhbGlhc2VzGAQgAygJIu0CCglFcnJvckNvZGUSGQoVU09DS0VUX0VBSV9BRERSRkFNSUxZEAESFAoQU09DS0VUX0VBSV9BR0FJThACEhcKE1NPQ0tFVF9FQUlfQkFERkxBR1MQAxITCg9TT0NLRVRfRUFJX0ZBSUwQBBIVChFTT0NLRVRfRUFJX0ZBTUlMWRAFEhUKEVNPQ0tFVF9FQUlfTUVNT1JZEAYSFQoRU09DS0VUX0VBSV9OT0RBVEEQBxIVChFTT0NLRVRfRUFJX05PTkFNRRAIEhYKElNPQ0tFVF9FQUlfU0VSVklDRRAJEhcKE1NPQ0tFVF9FQUlfU09DS1RZUEUQChIVChFTT0NLRVRfRUFJX1NZU1RFTRALEhcKE1NPQ0tFVF9FQUlfQkFESElOVFMQDBIXChNTT0NLRVRfRUFJX1BST1RPQ09MEA0SFwoTU09DS0VUX0VBSV9PVkVSRkxPVxAOEhIKDlNPQ0tFVF9FQUlfTUFYEA8y9ggKE1JlbW90ZVNvY2tldFNlcnZpY2USTgoMQ3JlYXRlU29ja2V0Eh8uYXBwaG9zdGluZy5DcmVhdGVTb2NrZXRSZXF1ZXN0Gh0uYXBwaG9zdGluZy5DcmVhdGVTb2NrZXRSZXBseRI2CgRCaW5kEhcuYXBwaG9zdGluZy5CaW5kUmVxdWVzdBoVLmFwcGhvc3RpbmcuQmluZFJlcGx5ElEKDUdldFNvY2tldE5hbWUSIC5hcHBob3N0aW5nLkdldFNvY2tldE5hbWVSZXF1ZXN0Gh4uYXBwaG9zdGluZy5HZXRTb2NrZXROYW1lUmVwbHkSSwoLR2V0UGVlck5hbWUSHi5hcHBob3N0aW5nLkdldFBlZXJOYW1lUmVxdWVzdBocLmFwcGhvc3RpbmcuR2V0UGVlck5hbWVSZXBseRJaChBTZXRTb2NrZXRPcHRpb25zEiMuYXBwaG9zdGluZy5TZXRTb2NrZXRPcHRpb25zUmVxdWVzdBohLmFwcGhvc3RpbmcuU2V0U29ja2V0T3B0aW9uc1JlcGx5EloKEEdldFNvY2tldE9wdGlvbnMSIy5hcHBob3N0aW5nLkdldFNvY2tldE9wdGlvbnNSZXF1ZXN0GiEuYXBwaG9zdGluZy5HZXRTb2NrZXRPcHRpb25zUmVwbHkSPwoHQ29ubmVjdBIaLmFwcGhvc3RpbmcuQ29ubmVjdFJlcXVlc3QaGC5hcHBob3N0aW5nLkNvbm5lY3RSZXBseRI8CgZMaXN0ZW4SGS5hcHBob3N0aW5nLkxpc3RlblJlcXVlc3QaFy5hcHBob3N0aW5nLkxpc3RlblJlcGx5EjwKBkFjY2VwdBIZLmFwcGhvc3RpbmcuQWNjZXB0UmVxdWVzdBoXLmFwcGhvc3RpbmcuQWNjZXB0UmVwbHkSQgoIU2h1dERvd24SGy5hcHBob3N0aW5nLlNodXREb3duUmVxdWVzdBoZLmFwcGhvc3RpbmcuU2h1dERvd25SZXBseRI5CgVDbG9zZRIYLmFwcGhvc3RpbmcuQ2xvc2VSZXF1ZXN0GhYuYXBwaG9zdGluZy5DbG9zZVJlcGx5EjYKBFNlbmQSFy5hcHBob3N0aW5nLlNlbmRSZXF1ZXN0GhUuYXBwaG9zdGluZy5TZW5kUmVwbHkSPwoHUmVjZWl2ZRIaLmFwcGhvc3RpbmcuUmVjZWl2ZVJlcXVlc3QaGC5hcHBob3N0aW5nLlJlY2VpdmVSZXBseRI2CgRQb2xsEhcuYXBwaG9zdGluZy5Qb2xsUmVxdWVzdBoVLmFwcGhvc3RpbmcuUG9sbFJlcGx5ElEKDVVwZGF0ZVNlc3Npb24SIC5hcHBob3N0aW5nLlVwZGF0ZVNlc3Npb25SZXF1ZXN0Gh4uYXBwaG9zdGluZy5VcGRhdGVTZXNzaW9uUmVwbHkSPwoHUmVzb2x2ZRIaLmFwcGhvc3RpbmcuUmVzb2x2ZVJlcXVlc3QaGC5hcHBob3N0aW5nLlJlc29sdmVSZXBseUJICidjb20uZ29vZ2xlLmFwcGhvc3RpbmcuYXBpLnJlbW90ZV9zb2NrZXQQASABKAFCFVJlbW90ZVNvY2tldFNlcnZpY2VQYkgB"))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class AddressPort(ProtocolBuffer.ProtocolMessage):
  has_port_ = 0
  port_ = 0
  has_packed_address_ = 0
  packed_address_ = ""

  def __init__(self, contents=None):
    if contents is not None: self.MergeFromString(contents)

  def port(self): return self.port_

  def set_port(self, x):
    self.has_port_ = 1
    self.port_ = x

  def clear_port(self):
    if self.has_port_:
      self.has_port_ = 0
      self.port_ = 0

  def has_port(self): return self.has_port_

  def packed_address(self): return self.packed_address_

  def set_packed_address(self, x):
    self.has_packed_address_ = 1
    self.packed_address_ = x

  def clear_packed_address(self):
    if self.has_packed_address_:
      self.has_packed_address_ = 0
      self.packed_address_ = ""

  def has_packed_address(self): return self.has_packed_address_


  def MergeFrom(self, x):
    assert x is not self
    if (x.has_port()): self.set_port(x.port())
    if (x.has_packed_address()): self.set_packed_address(x.packed_address())

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.AddressPort', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.AddressPort')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.AddressPort')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.AddressPort', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.AddressPort', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.AddressPort', s)


  def Equals(self, x):
    if x is self: return 1
    if self.has_port_ != x.has_port_: return 0
    if self.has_port_ and self.port_ != x.port_: return 0
    if self.has_packed_address_ != x.has_packed_address_: return 0
    if self.has_packed_address_ and self.packed_address_ != x.packed_address_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    if (not self.has_port_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: port not set.')
    return initialized

  def ByteSize(self):
    n = 0
    n += self.lengthVarInt64(self.port_)
    if (self.has_packed_address_): n += 1 + self.lengthString(len(self.packed_address_))
    return n + 1

  def ByteSizePartial(self):
    n = 0
    if (self.has_port_):
      n += 1
      n += self.lengthVarInt64(self.port_)
    if (self.has_packed_address_): n += 1 + self.lengthString(len(self.packed_address_))
    return n

  def Clear(self):
    self.clear_port()
    self.clear_packed_address()

  def OutputUnchecked(self, out):
    out.putVarInt32(8)
    out.putVarInt32(self.port_)
    if (self.has_packed_address_):
      out.putVarInt32(18)
      out.putPrefixedString(self.packed_address_)

  def OutputPartial(self, out):
    if (self.has_port_):
      out.putVarInt32(8)
      out.putVarInt32(self.port_)
    if (self.has_packed_address_):
      out.putVarInt32(18)
      out.putPrefixedString(self.packed_address_)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 8:
        self.set_port(d.getVarInt32())
        continue
      if tt == 18:
        self.set_packed_address(d.getPrefixedString())
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    if self.has_port_: res+=prefix+("port: %s\n" % self.DebugFormatInt32(self.port_))
    if self.has_packed_address_: res+=prefix+("packed_address: %s\n" % self.DebugFormatString(self.packed_address_))
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  kport = 1
  kpacked_address = 2

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "port",
    2: "packed_address",
  }, 2)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.NUMERIC,
    2: ProtocolBuffer.Encoder.STRING,
  }, 2, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("WjhhcHBob3N0aW5nL2FwaS9yZW1vdGVfc29ja2V0L3JlbW90ZV9zb2NrZXRfc2VydmljZS5wcm90bwoWYXBwaG9zdGluZy5BZGRyZXNzUG9ydBMaBHBvcnQgASgAMAU4AhQTGg5wYWNrZWRfYWRkcmVzcyACKAIwCTgBFMIBI2FwcGhvc3RpbmcuUmVtb3RlU29ja2V0U2VydmljZUVycm9y"))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class SSLContext(ProtocolBuffer.ProtocolMessage):


  SSL_PROTOCOL_SSLv2 =    1
  SSL_PROTOCOL_SSLv3 =    2
  SSL_PROTOCOL_SSLv23 =    3
  SSL_PROTOCOL_TLSv1 =    4
  SSL_PROTOCOL_NOSSLv2 =    5

  _Version_NAMES = {
    1: "SSL_PROTOCOL_SSLv2",
    2: "SSL_PROTOCOL_SSLv3",
    3: "SSL_PROTOCOL_SSLv23",
    4: "SSL_PROTOCOL_TLSv1",
    5: "SSL_PROTOCOL_NOSSLv2",
  }

  def Version_Name(cls, x): return cls._Version_NAMES.get(x, "")
  Version_Name = classmethod(Version_Name)



  SSL_CERT_NONE =    1
  SSL_CERT_OPTIONAL =    2
  SSL_CERT_REQUIRED =    3

  _PeerAuth_NAMES = {
    1: "SSL_CERT_NONE",
    2: "SSL_CERT_OPTIONAL",
    3: "SSL_CERT_REQUIRED",
  }

  def PeerAuth_Name(cls, x): return cls._PeerAuth_NAMES.get(x, "")
  PeerAuth_Name = classmethod(PeerAuth_Name)

  has_ssl_version_ = 0
  ssl_version_ = 0
  has_ssl_peer_auth_ = 0
  ssl_peer_auth_ = 0
  has_ssl_ciphers_ = 0
  ssl_ciphers_ = ""
  has_server_hostname_ = 0
  server_hostname_ = ""
  has_client_certificate_ = 0
  client_certificate_ = ""
  has_client_private_key_ = 0
  client_private_key_ = ""

  def __init__(self, contents=None):
    self.trusted_ca_certificate_ = []
    if contents is not None: self.MergeFromString(contents)

  def ssl_version(self): return self.ssl_version_

  def set_ssl_version(self, x):
    self.has_ssl_version_ = 1
    self.ssl_version_ = x

  def clear_ssl_version(self):
    if self.has_ssl_version_:
      self.has_ssl_version_ = 0
      self.ssl_version_ = 0

  def has_ssl_version(self): return self.has_ssl_version_

  def ssl_peer_auth(self): return self.ssl_peer_auth_

  def set_ssl_peer_auth(self, x):
    self.has_ssl_peer_auth_ = 1
    self.ssl_peer_auth_ = x

  def clear_ssl_peer_auth(self):
    if self.has_ssl_peer_auth_:
      self.has_ssl_peer_auth_ = 0
      self.ssl_peer_auth_ = 0

  def has_ssl_peer_auth(self): return self.has_ssl_peer_auth_

  def ssl_ciphers(self): return self.ssl_ciphers_

  def set_ssl_ciphers(self, x):
    self.has_ssl_ciphers_ = 1
    self.ssl_ciphers_ = x

  def clear_ssl_ciphers(self):
    if self.has_ssl_ciphers_:
      self.has_ssl_ciphers_ = 0
      self.ssl_ciphers_ = ""

  def has_ssl_ciphers(self): return self.has_ssl_ciphers_

  def server_hostname(self): return self.server_hostname_

  def set_server_hostname(self, x):
    self.has_server_hostname_ = 1
    self.server_hostname_ = x

  def clear_server_hostname(self):
    if self.has_server_hostname_:
      self.has_server_hostname_ = 0
      self.server_hostname_ = ""

  def has_server_hostname(self): return self.has_server_hostname_

  def client_certificate(self): return self.client_certificate_

  def set_client_certificate(self, x):
    self.has_client_certificate_ = 1
    self.client_certificate_ = x

  def clear_client_certificate(self):
    if self.has_client_certificate_:
      self.has_client_certificate_ = 0
      self.client_certificate_ = ""

  def has_client_certificate(self): return self.has_client_certificate_

  def client_private_key(self): return self.client_private_key_

  def set_client_private_key(self, x):
    self.has_client_private_key_ = 1
    self.client_private_key_ = x

  def clear_client_private_key(self):
    if self.has_client_private_key_:
      self.has_client_private_key_ = 0
      self.client_private_key_ = ""

  def has_client_private_key(self): return self.has_client_private_key_

  def trusted_ca_certificate_size(self): return len(self.trusted_ca_certificate_)
  def trusted_ca_certificate_list(self): return self.trusted_ca_certificate_

  def trusted_ca_certificate(self, i):
    return self.trusted_ca_certificate_[i]

  def set_trusted_ca_certificate(self, i, x):
    self.trusted_ca_certificate_[i] = x

  def add_trusted_ca_certificate(self, x):
    self.trusted_ca_certificate_.append(x)

  def clear_trusted_ca_certificate(self):
    self.trusted_ca_certificate_ = []


  def MergeFrom(self, x):
    assert x is not self
    if (x.has_ssl_version()): self.set_ssl_version(x.ssl_version())
    if (x.has_ssl_peer_auth()): self.set_ssl_peer_auth(x.ssl_peer_auth())
    if (x.has_ssl_ciphers()): self.set_ssl_ciphers(x.ssl_ciphers())
    if (x.has_server_hostname()): self.set_server_hostname(x.server_hostname())
    if (x.has_client_certificate()): self.set_client_certificate(x.client_certificate())
    if (x.has_client_private_key()): self.set_client_private_key(x.client_private_key())
    for i in xrange(x.trusted_ca_certificate_size()): self.add_trusted_ca_certificate(x.trusted_ca_certificate(i))

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.SSLContext', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.SSLContext')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.SSLContext')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.SSLContext', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.SSLContext', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.SSLContext', s)


  def Equals(self, x):
    if x is self: return 1
    if self.has_ssl_version_ != x.has_ssl_version_: return 0
    if self.has_ssl_version_ and self.ssl_version_ != x.ssl_version_: return 0
    if self.has_ssl_peer_auth_ != x.has_ssl_peer_auth_: return 0
    if self.has_ssl_peer_auth_ and self.ssl_peer_auth_ != x.ssl_peer_auth_: return 0
    if self.has_ssl_ciphers_ != x.has_ssl_ciphers_: return 0
    if self.has_ssl_ciphers_ and self.ssl_ciphers_ != x.ssl_ciphers_: return 0
    if self.has_server_hostname_ != x.has_server_hostname_: return 0
    if self.has_server_hostname_ and self.server_hostname_ != x.server_hostname_: return 0
    if self.has_client_certificate_ != x.has_client_certificate_: return 0
    if self.has_client_certificate_ and self.client_certificate_ != x.client_certificate_: return 0
    if self.has_client_private_key_ != x.has_client_private_key_: return 0
    if self.has_client_private_key_ and self.client_private_key_ != x.client_private_key_: return 0
    if len(self.trusted_ca_certificate_) != len(x.trusted_ca_certificate_): return 0
    for e1, e2 in zip(self.trusted_ca_certificate_, x.trusted_ca_certificate_):
      if e1 != e2: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    return initialized

  def ByteSize(self):
    n = 0
    if (self.has_ssl_version_): n += 1 + self.lengthVarInt64(self.ssl_version_)
    if (self.has_ssl_peer_auth_): n += 1 + self.lengthVarInt64(self.ssl_peer_auth_)
    if (self.has_ssl_ciphers_): n += 1 + self.lengthString(len(self.ssl_ciphers_))
    if (self.has_server_hostname_): n += 1 + self.lengthString(len(self.server_hostname_))
    if (self.has_client_certificate_): n += 1 + self.lengthString(len(self.client_certificate_))
    if (self.has_client_private_key_): n += 1 + self.lengthString(len(self.client_private_key_))
    n += 1 * len(self.trusted_ca_certificate_)
    for i in xrange(len(self.trusted_ca_certificate_)): n += self.lengthString(len(self.trusted_ca_certificate_[i]))
    return n

  def ByteSizePartial(self):
    n = 0
    if (self.has_ssl_version_): n += 1 + self.lengthVarInt64(self.ssl_version_)
    if (self.has_ssl_peer_auth_): n += 1 + self.lengthVarInt64(self.ssl_peer_auth_)
    if (self.has_ssl_ciphers_): n += 1 + self.lengthString(len(self.ssl_ciphers_))
    if (self.has_server_hostname_): n += 1 + self.lengthString(len(self.server_hostname_))
    if (self.has_client_certificate_): n += 1 + self.lengthString(len(self.client_certificate_))
    if (self.has_client_private_key_): n += 1 + self.lengthString(len(self.client_private_key_))
    n += 1 * len(self.trusted_ca_certificate_)
    for i in xrange(len(self.trusted_ca_certificate_)): n += self.lengthString(len(self.trusted_ca_certificate_[i]))
    return n

  def Clear(self):
    self.clear_ssl_version()
    self.clear_ssl_peer_auth()
    self.clear_ssl_ciphers()
    self.clear_server_hostname()
    self.clear_client_certificate()
    self.clear_client_private_key()
    self.clear_trusted_ca_certificate()

  def OutputUnchecked(self, out):
    if (self.has_ssl_version_):
      out.putVarInt32(8)
      out.putVarInt32(self.ssl_version_)
    if (self.has_ssl_peer_auth_):
      out.putVarInt32(16)
      out.putVarInt32(self.ssl_peer_auth_)
    if (self.has_ssl_ciphers_):
      out.putVarInt32(26)
      out.putPrefixedString(self.ssl_ciphers_)
    if (self.has_server_hostname_):
      out.putVarInt32(34)
      out.putPrefixedString(self.server_hostname_)
    if (self.has_client_certificate_):
      out.putVarInt32(42)
      out.putPrefixedString(self.client_certificate_)
    if (self.has_client_private_key_):
      out.putVarInt32(50)
      out.putPrefixedString(self.client_private_key_)
    for i in xrange(len(self.trusted_ca_certificate_)):
      out.putVarInt32(58)
      out.putPrefixedString(self.trusted_ca_certificate_[i])

  def OutputPartial(self, out):
    if (self.has_ssl_version_):
      out.putVarInt32(8)
      out.putVarInt32(self.ssl_version_)
    if (self.has_ssl_peer_auth_):
      out.putVarInt32(16)
      out.putVarInt32(self.ssl_peer_auth_)
    if (self.has_ssl_ciphers_):
      out.putVarInt32(26)
      out.putPrefixedString(self.ssl_ciphers_)
    if (self.has_server_hostname_):
      out.putVarInt32(34)
      out.putPrefixedString(self.server_hostname_)
    if (self.has_client_certificate_):
      out.putVarInt32(42)
      out.putPrefixedString(self.client_certificate_)
    if (self.has_client_private_key_):
      out.putVarInt32(50)
      out.putPrefixedString(self.client_private_key_)
    for i in xrange(len(self.trusted_ca_certificate_)):
      out.putVarInt32(58)
      out.putPrefixedString(self.trusted_ca_certificate_[i])

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 8:
        self.set_ssl_version(d.getVarInt32())
        continue
      if tt == 16:
        self.set_ssl_peer_auth(d.getVarInt32())
        continue
      if tt == 26:
        self.set_ssl_ciphers(d.getPrefixedString())
        continue
      if tt == 34:
        self.set_server_hostname(d.getPrefixedString())
        continue
      if tt == 42:
        self.set_client_certificate(d.getPrefixedString())
        continue
      if tt == 50:
        self.set_client_private_key(d.getPrefixedString())
        continue
      if tt == 58:
        self.add_trusted_ca_certificate(d.getPrefixedString())
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    if self.has_ssl_version_: res+=prefix+("ssl_version: %s\n" % self.DebugFormatInt32(self.ssl_version_))
    if self.has_ssl_peer_auth_: res+=prefix+("ssl_peer_auth: %s\n" % self.DebugFormatInt32(self.ssl_peer_auth_))
    if self.has_ssl_ciphers_: res+=prefix+("ssl_ciphers: %s\n" % self.DebugFormatString(self.ssl_ciphers_))
    if self.has_server_hostname_: res+=prefix+("server_hostname: %s\n" % self.DebugFormatString(self.server_hostname_))
    if self.has_client_certificate_: res+=prefix+("client_certificate: %s\n" % self.DebugFormatString(self.client_certificate_))
    if self.has_client_private_key_: res+=prefix+("client_private_key: %s\n" % self.DebugFormatString(self.client_private_key_))
    cnt=0
    for e in self.trusted_ca_certificate_:
      elm=""
      if printElemNumber: elm="(%d)" % cnt
      res+=prefix+("trusted_ca_certificate%s: %s\n" % (elm, self.DebugFormatString(e)))
      cnt+=1
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  kssl_version = 1
  kssl_peer_auth = 2
  kssl_ciphers = 3
  kserver_hostname = 4
  kclient_certificate = 5
  kclient_private_key = 6
  ktrusted_ca_certificate = 7

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "ssl_version",
    2: "ssl_peer_auth",
    3: "ssl_ciphers",
    4: "server_hostname",
    5: "client_certificate",
    6: "client_private_key",
    7: "trusted_ca_certificate",
  }, 7)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.NUMERIC,
    2: ProtocolBuffer.Encoder.NUMERIC,
    3: ProtocolBuffer.Encoder.STRING,
    4: ProtocolBuffer.Encoder.STRING,
    5: ProtocolBuffer.Encoder.STRING,
    6: ProtocolBuffer.Encoder.STRING,
    7: ProtocolBuffer.Encoder.STRING,
  }, 7, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("WjhhcHBob3N0aW5nL2FwaS9yZW1vdGVfc29ja2V0L3JlbW90ZV9zb2NrZXRfc2VydmljZS5wcm90bwoVYXBwaG9zdGluZy5TU0xDb250ZXh0ExoLc3NsX3ZlcnNpb24gASgAMAU4AWgAFBMaDXNzbF9wZWVyX2F1dGggAigAMAU4AWgBFBMaC3NzbF9jaXBoZXJzIAMoAjAJOAEUExoPc2VydmVyX2hvc3RuYW1lIAQoAjAJOAEUExoSY2xpZW50X2NlcnRpZmljYXRlIAUoAjAJOAEUExoSY2xpZW50X3ByaXZhdGVfa2V5IAYoAjAJOAEUExoWdHJ1c3RlZF9jYV9jZXJ0aWZpY2F0ZSAHKAIwCTgDFHN6B1ZlcnNpb26LAZIBElNTTF9QUk9UT0NPTF9TU0x2MpgBAYwBiwGSARJTU0xfUFJPVE9DT0xfU1NMdjOYAQKMAYsBkgETU1NMX1BST1RPQ09MX1NTTHYyM5gBA4wBiwGSARJTU0xfUFJPVE9DT0xfVExTdjGYAQSMAYsBkgEUU1NMX1BST1RPQ09MX05PU1NMdjKYAQWMAXRzeghQZWVyQXV0aIsBkgENU1NMX0NFUlRfTk9ORZgBAYwBiwGSARFTU0xfQ0VSVF9PUFRJT05BTJgBAowBiwGSARFTU0xfQ0VSVF9SRVFVSVJFRJgBA4wBdMIBI2FwcGhvc3RpbmcuUmVtb3RlU29ja2V0U2VydmljZUVycm9y"))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class SSLSession(ProtocolBuffer.ProtocolMessage):


  SSL_ERROR_ZERO_RETURN =    1
  SSL_ERROR_WANT_READ =    2
  SSL_ERROR_WANT_WRITE =    3
  SSL_ERROR_WANT_X509_LOOKUP =    4
  SSL_ERROR_SYSCALL =    5
  SSL_ERROR_SSL =    6
  SSL_ERROR_WANT_CONNECT =    7
  SSL_ERROR_EOF =    8
  SSL_ERROR_INVALID_ERROR_CODE =    9

  _ErrorCode_NAMES = {
    1: "SSL_ERROR_ZERO_RETURN",
    2: "SSL_ERROR_WANT_READ",
    3: "SSL_ERROR_WANT_WRITE",
    4: "SSL_ERROR_WANT_X509_LOOKUP",
    5: "SSL_ERROR_SYSCALL",
    6: "SSL_ERROR_SSL",
    7: "SSL_ERROR_WANT_CONNECT",
    8: "SSL_ERROR_EOF",
    9: "SSL_ERROR_INVALID_ERROR_CODE",
  }

  def ErrorCode_Name(cls, x): return cls._ErrorCode_NAMES.get(x, "")
  ErrorCode_Name = classmethod(ErrorCode_Name)

  has_peer_certificate_ = 0
  peer_certificate_ = ""
  has_peer_certificate_subject_ = 0
  peer_certificate_subject_ = ""
  has_peer_certificate_issuer_ = 0
  peer_certificate_issuer_ = ""
  has_ssl_cipher_ = 0
  ssl_cipher_ = ""
  has_ssl_cipher_version_ = 0
  ssl_cipher_version_ = ""
  has_ssl_cipher_key_bits_ = 0
  ssl_cipher_key_bits_ = 0

  def __init__(self, contents=None):
    self.peer_certificate_subject_alt_name_ = []
    self.peer_certificate_chain_ = []
    if contents is not None: self.MergeFromString(contents)

  def peer_certificate(self): return self.peer_certificate_

  def set_peer_certificate(self, x):
    self.has_peer_certificate_ = 1
    self.peer_certificate_ = x

  def clear_peer_certificate(self):
    if self.has_peer_certificate_:
      self.has_peer_certificate_ = 0
      self.peer_certificate_ = ""

  def has_peer_certificate(self): return self.has_peer_certificate_

  def peer_certificate_subject(self): return self.peer_certificate_subject_

  def set_peer_certificate_subject(self, x):
    self.has_peer_certificate_subject_ = 1
    self.peer_certificate_subject_ = x

  def clear_peer_certificate_subject(self):
    if self.has_peer_certificate_subject_:
      self.has_peer_certificate_subject_ = 0
      self.peer_certificate_subject_ = ""

  def has_peer_certificate_subject(self): return self.has_peer_certificate_subject_

  def peer_certificate_issuer(self): return self.peer_certificate_issuer_

  def set_peer_certificate_issuer(self, x):
    self.has_peer_certificate_issuer_ = 1
    self.peer_certificate_issuer_ = x

  def clear_peer_certificate_issuer(self):
    if self.has_peer_certificate_issuer_:
      self.has_peer_certificate_issuer_ = 0
      self.peer_certificate_issuer_ = ""

  def has_peer_certificate_issuer(self): return self.has_peer_certificate_issuer_

  def peer_certificate_subject_alt_name_size(self): return len(self.peer_certificate_subject_alt_name_)
  def peer_certificate_subject_alt_name_list(self): return self.peer_certificate_subject_alt_name_

  def peer_certificate_subject_alt_name(self, i):
    return self.peer_certificate_subject_alt_name_[i]

  def set_peer_certificate_subject_alt_name(self, i, x):
    self.peer_certificate_subject_alt_name_[i] = x

  def add_peer_certificate_subject_alt_name(self, x):
    self.peer_certificate_subject_alt_name_.append(x)

  def clear_peer_certificate_subject_alt_name(self):
    self.peer_certificate_subject_alt_name_ = []

  def peer_certificate_chain_size(self): return len(self.peer_certificate_chain_)
  def peer_certificate_chain_list(self): return self.peer_certificate_chain_

  def peer_certificate_chain(self, i):
    return self.peer_certificate_chain_[i]

  def set_peer_certificate_chain(self, i, x):
    self.peer_certificate_chain_[i] = x

  def add_peer_certificate_chain(self, x):
    self.peer_certificate_chain_.append(x)

  def clear_peer_certificate_chain(self):
    self.peer_certificate_chain_ = []

  def ssl_cipher(self): return self.ssl_cipher_

  def set_ssl_cipher(self, x):
    self.has_ssl_cipher_ = 1
    self.ssl_cipher_ = x

  def clear_ssl_cipher(self):
    if self.has_ssl_cipher_:
      self.has_ssl_cipher_ = 0
      self.ssl_cipher_ = ""

  def has_ssl_cipher(self): return self.has_ssl_cipher_

  def ssl_cipher_version(self): return self.ssl_cipher_version_

  def set_ssl_cipher_version(self, x):
    self.has_ssl_cipher_version_ = 1
    self.ssl_cipher_version_ = x

  def clear_ssl_cipher_version(self):
    if self.has_ssl_cipher_version_:
      self.has_ssl_cipher_version_ = 0
      self.ssl_cipher_version_ = ""

  def has_ssl_cipher_version(self): return self.has_ssl_cipher_version_

  def ssl_cipher_key_bits(self): return self.ssl_cipher_key_bits_

  def set_ssl_cipher_key_bits(self, x):
    self.has_ssl_cipher_key_bits_ = 1
    self.ssl_cipher_key_bits_ = x

  def clear_ssl_cipher_key_bits(self):
    if self.has_ssl_cipher_key_bits_:
      self.has_ssl_cipher_key_bits_ = 0
      self.ssl_cipher_key_bits_ = 0

  def has_ssl_cipher_key_bits(self): return self.has_ssl_cipher_key_bits_


  def MergeFrom(self, x):
    assert x is not self
    if (x.has_peer_certificate()): self.set_peer_certificate(x.peer_certificate())
    if (x.has_peer_certificate_subject()): self.set_peer_certificate_subject(x.peer_certificate_subject())
    if (x.has_peer_certificate_issuer()): self.set_peer_certificate_issuer(x.peer_certificate_issuer())
    for i in xrange(x.peer_certificate_subject_alt_name_size()): self.add_peer_certificate_subject_alt_name(x.peer_certificate_subject_alt_name(i))
    for i in xrange(x.peer_certificate_chain_size()): self.add_peer_certificate_chain(x.peer_certificate_chain(i))
    if (x.has_ssl_cipher()): self.set_ssl_cipher(x.ssl_cipher())
    if (x.has_ssl_cipher_version()): self.set_ssl_cipher_version(x.ssl_cipher_version())
    if (x.has_ssl_cipher_key_bits()): self.set_ssl_cipher_key_bits(x.ssl_cipher_key_bits())

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.SSLSession', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.SSLSession')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.SSLSession')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.SSLSession', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.SSLSession', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.SSLSession', s)


  def Equals(self, x):
    if x is self: return 1
    if self.has_peer_certificate_ != x.has_peer_certificate_: return 0
    if self.has_peer_certificate_ and self.peer_certificate_ != x.peer_certificate_: return 0
    if self.has_peer_certificate_subject_ != x.has_peer_certificate_subject_: return 0
    if self.has_peer_certificate_subject_ and self.peer_certificate_subject_ != x.peer_certificate_subject_: return 0
    if self.has_peer_certificate_issuer_ != x.has_peer_certificate_issuer_: return 0
    if self.has_peer_certificate_issuer_ and self.peer_certificate_issuer_ != x.peer_certificate_issuer_: return 0
    if len(self.peer_certificate_subject_alt_name_) != len(x.peer_certificate_subject_alt_name_): return 0
    for e1, e2 in zip(self.peer_certificate_subject_alt_name_, x.peer_certificate_subject_alt_name_):
      if e1 != e2: return 0
    if len(self.peer_certificate_chain_) != len(x.peer_certificate_chain_): return 0
    for e1, e2 in zip(self.peer_certificate_chain_, x.peer_certificate_chain_):
      if e1 != e2: return 0
    if self.has_ssl_cipher_ != x.has_ssl_cipher_: return 0
    if self.has_ssl_cipher_ and self.ssl_cipher_ != x.ssl_cipher_: return 0
    if self.has_ssl_cipher_version_ != x.has_ssl_cipher_version_: return 0
    if self.has_ssl_cipher_version_ and self.ssl_cipher_version_ != x.ssl_cipher_version_: return 0
    if self.has_ssl_cipher_key_bits_ != x.has_ssl_cipher_key_bits_: return 0
    if self.has_ssl_cipher_key_bits_ and self.ssl_cipher_key_bits_ != x.ssl_cipher_key_bits_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    return initialized

  def ByteSize(self):
    n = 0
    if (self.has_peer_certificate_): n += 1 + self.lengthString(len(self.peer_certificate_))
    if (self.has_peer_certificate_subject_): n += 1 + self.lengthString(len(self.peer_certificate_subject_))
    if (self.has_peer_certificate_issuer_): n += 1 + self.lengthString(len(self.peer_certificate_issuer_))
    n += 1 * len(self.peer_certificate_subject_alt_name_)
    for i in xrange(len(self.peer_certificate_subject_alt_name_)): n += self.lengthString(len(self.peer_certificate_subject_alt_name_[i]))
    n += 1 * len(self.peer_certificate_chain_)
    for i in xrange(len(self.peer_certificate_chain_)): n += self.lengthString(len(self.peer_certificate_chain_[i]))
    if (self.has_ssl_cipher_): n += 1 + self.lengthString(len(self.ssl_cipher_))
    if (self.has_ssl_cipher_version_): n += 1 + self.lengthString(len(self.ssl_cipher_version_))
    if (self.has_ssl_cipher_key_bits_): n += 1 + self.lengthVarInt64(self.ssl_cipher_key_bits_)
    return n

  def ByteSizePartial(self):
    n = 0
    if (self.has_peer_certificate_): n += 1 + self.lengthString(len(self.peer_certificate_))
    if (self.has_peer_certificate_subject_): n += 1 + self.lengthString(len(self.peer_certificate_subject_))
    if (self.has_peer_certificate_issuer_): n += 1 + self.lengthString(len(self.peer_certificate_issuer_))
    n += 1 * len(self.peer_certificate_subject_alt_name_)
    for i in xrange(len(self.peer_certificate_subject_alt_name_)): n += self.lengthString(len(self.peer_certificate_subject_alt_name_[i]))
    n += 1 * len(self.peer_certificate_chain_)
    for i in xrange(len(self.peer_certificate_chain_)): n += self.lengthString(len(self.peer_certificate_chain_[i]))
    if (self.has_ssl_cipher_): n += 1 + self.lengthString(len(self.ssl_cipher_))
    if (self.has_ssl_cipher_version_): n += 1 + self.lengthString(len(self.ssl_cipher_version_))
    if (self.has_ssl_cipher_key_bits_): n += 1 + self.lengthVarInt64(self.ssl_cipher_key_bits_)
    return n

  def Clear(self):
    self.clear_peer_certificate()
    self.clear_peer_certificate_subject()
    self.clear_peer_certificate_issuer()
    self.clear_peer_certificate_subject_alt_name()
    self.clear_peer_certificate_chain()
    self.clear_ssl_cipher()
    self.clear_ssl_cipher_version()
    self.clear_ssl_cipher_key_bits()

  def OutputUnchecked(self, out):
    if (self.has_peer_certificate_):
      out.putVarInt32(10)
      out.putPrefixedString(self.peer_certificate_)
    if (self.has_peer_certificate_subject_):
      out.putVarInt32(18)
      out.putPrefixedString(self.peer_certificate_subject_)
    if (self.has_peer_certificate_issuer_):
      out.putVarInt32(26)
      out.putPrefixedString(self.peer_certificate_issuer_)
    for i in xrange(len(self.peer_certificate_subject_alt_name_)):
      out.putVarInt32(34)
      out.putPrefixedString(self.peer_certificate_subject_alt_name_[i])
    for i in xrange(len(self.peer_certificate_chain_)):
      out.putVarInt32(42)
      out.putPrefixedString(self.peer_certificate_chain_[i])
    if (self.has_ssl_cipher_):
      out.putVarInt32(50)
      out.putPrefixedString(self.ssl_cipher_)
    if (self.has_ssl_cipher_version_):
      out.putVarInt32(58)
      out.putPrefixedString(self.ssl_cipher_version_)
    if (self.has_ssl_cipher_key_bits_):
      out.putVarInt32(64)
      out.putVarInt32(self.ssl_cipher_key_bits_)

  def OutputPartial(self, out):
    if (self.has_peer_certificate_):
      out.putVarInt32(10)
      out.putPrefixedString(self.peer_certificate_)
    if (self.has_peer_certificate_subject_):
      out.putVarInt32(18)
      out.putPrefixedString(self.peer_certificate_subject_)
    if (self.has_peer_certificate_issuer_):
      out.putVarInt32(26)
      out.putPrefixedString(self.peer_certificate_issuer_)
    for i in xrange(len(self.peer_certificate_subject_alt_name_)):
      out.putVarInt32(34)
      out.putPrefixedString(self.peer_certificate_subject_alt_name_[i])
    for i in xrange(len(self.peer_certificate_chain_)):
      out.putVarInt32(42)
      out.putPrefixedString(self.peer_certificate_chain_[i])
    if (self.has_ssl_cipher_):
      out.putVarInt32(50)
      out.putPrefixedString(self.ssl_cipher_)
    if (self.has_ssl_cipher_version_):
      out.putVarInt32(58)
      out.putPrefixedString(self.ssl_cipher_version_)
    if (self.has_ssl_cipher_key_bits_):
      out.putVarInt32(64)
      out.putVarInt32(self.ssl_cipher_key_bits_)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 10:
        self.set_peer_certificate(d.getPrefixedString())
        continue
      if tt == 18:
        self.set_peer_certificate_subject(d.getPrefixedString())
        continue
      if tt == 26:
        self.set_peer_certificate_issuer(d.getPrefixedString())
        continue
      if tt == 34:
        self.add_peer_certificate_subject_alt_name(d.getPrefixedString())
        continue
      if tt == 42:
        self.add_peer_certificate_chain(d.getPrefixedString())
        continue
      if tt == 50:
        self.set_ssl_cipher(d.getPrefixedString())
        continue
      if tt == 58:
        self.set_ssl_cipher_version(d.getPrefixedString())
        continue
      if tt == 64:
        self.set_ssl_cipher_key_bits(d.getVarInt32())
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    if self.has_peer_certificate_: res+=prefix+("peer_certificate: %s\n" % self.DebugFormatString(self.peer_certificate_))
    if self.has_peer_certificate_subject_: res+=prefix+("peer_certificate_subject: %s\n" % self.DebugFormatString(self.peer_certificate_subject_))
    if self.has_peer_certificate_issuer_: res+=prefix+("peer_certificate_issuer: %s\n" % self.DebugFormatString(self.peer_certificate_issuer_))
    cnt=0
    for e in self.peer_certificate_subject_alt_name_:
      elm=""
      if printElemNumber: elm="(%d)" % cnt
      res+=prefix+("peer_certificate_subject_alt_name%s: %s\n" % (elm, self.DebugFormatString(e)))
      cnt+=1
    cnt=0
    for e in self.peer_certificate_chain_:
      elm=""
      if printElemNumber: elm="(%d)" % cnt
      res+=prefix+("peer_certificate_chain%s: %s\n" % (elm, self.DebugFormatString(e)))
      cnt+=1
    if self.has_ssl_cipher_: res+=prefix+("ssl_cipher: %s\n" % self.DebugFormatString(self.ssl_cipher_))
    if self.has_ssl_cipher_version_: res+=prefix+("ssl_cipher_version: %s\n" % self.DebugFormatString(self.ssl_cipher_version_))
    if self.has_ssl_cipher_key_bits_: res+=prefix+("ssl_cipher_key_bits: %s\n" % self.DebugFormatInt32(self.ssl_cipher_key_bits_))
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  kpeer_certificate = 1
  kpeer_certificate_subject = 2
  kpeer_certificate_issuer = 3
  kpeer_certificate_subject_alt_name = 4
  kpeer_certificate_chain = 5
  kssl_cipher = 6
  kssl_cipher_version = 7
  kssl_cipher_key_bits = 8

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "peer_certificate",
    2: "peer_certificate_subject",
    3: "peer_certificate_issuer",
    4: "peer_certificate_subject_alt_name",
    5: "peer_certificate_chain",
    6: "ssl_cipher",
    7: "ssl_cipher_version",
    8: "ssl_cipher_key_bits",
  }, 8)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.STRING,
    2: ProtocolBuffer.Encoder.STRING,
    3: ProtocolBuffer.Encoder.STRING,
    4: ProtocolBuffer.Encoder.STRING,
    5: ProtocolBuffer.Encoder.STRING,
    6: ProtocolBuffer.Encoder.STRING,
    7: ProtocolBuffer.Encoder.STRING,
    8: ProtocolBuffer.Encoder.NUMERIC,
  }, 8, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("WjhhcHBob3N0aW5nL2FwaS9yZW1vdGVfc29ja2V0L3JlbW90ZV9zb2NrZXRfc2VydmljZS5wcm90bwoVYXBwaG9zdGluZy5TU0xTZXNzaW9uExoQcGVlcl9jZXJ0aWZpY2F0ZSABKAIwCTgBFBMaGHBlZXJfY2VydGlmaWNhdGVfc3ViamVjdCACKAIwCTgBFBMaF3BlZXJfY2VydGlmaWNhdGVfaXNzdWVyIAMoAjAJOAEUExohcGVlcl9jZXJ0aWZpY2F0ZV9zdWJqZWN0X2FsdF9uYW1lIAQoAjAJOAMUExoWcGVlcl9jZXJ0aWZpY2F0ZV9jaGFpbiAFKAIwCTgDFBMaCnNzbF9jaXBoZXIgBigCMAk4ARQTGhJzc2xfY2lwaGVyX3ZlcnNpb24gBygCMAk4ARQTGhNzc2xfY2lwaGVyX2tleV9iaXRzIAgoADAFOAEUc3oJRXJyb3JDb2RliwGSARVTU0xfRVJST1JfWkVST19SRVRVUk6YAQGMAYsBkgETU1NMX0VSUk9SX1dBTlRfUkVBRJgBAowBiwGSARRTU0xfRVJST1JfV0FOVF9XUklURZgBA4wBiwGSARpTU0xfRVJST1JfV0FOVF9YNTA5X0xPT0tVUJgBBIwBiwGSARFTU0xfRVJST1JfU1lTQ0FMTJgBBYwBiwGSAQ1TU0xfRVJST1JfU1NMmAEGjAGLAZIBFlNTTF9FUlJPUl9XQU5UX0NPTk5FQ1SYAQeMAYsBkgENU1NMX0VSUk9SX0VPRpgBCIwBiwGSARxTU0xfRVJST1JfSU5WQUxJRF9FUlJPUl9DT0RFmAEJjAF0wgEjYXBwaG9zdGluZy5SZW1vdGVTb2NrZXRTZXJ2aWNlRXJyb3I="))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class CreateSocketRequest(ProtocolBuffer.ProtocolMessage):


  IPv4         =    1
  IPv6         =    2

  _SocketFamily_NAMES = {
    1: "IPv4",
    2: "IPv6",
  }

  def SocketFamily_Name(cls, x): return cls._SocketFamily_NAMES.get(x, "")
  SocketFamily_Name = classmethod(SocketFamily_Name)



  TCP          =    1
  UDP          =    2

  _SocketProtocol_NAMES = {
    1: "TCP",
    2: "UDP",
  }

  def SocketProtocol_Name(cls, x): return cls._SocketProtocol_NAMES.get(x, "")
  SocketProtocol_Name = classmethod(SocketProtocol_Name)

  has_family_ = 0
  family_ = 0
  has_protocol_ = 0
  protocol_ = 0
  has_proxy_external_ip_ = 0
  proxy_external_ip_ = None
  has_listen_backlog_ = 0
  listen_backlog_ = 0
  has_remote_ip_ = 0
  remote_ip_ = None
  has_timeout_seconds_ = 0
  timeout_seconds_ = -1.0
  has_ssl_ctx_ = 0
  ssl_ctx_ = None

  def __init__(self, contents=None):
    self.socket_options_ = []
    self.lazy_init_lock_ = thread.allocate_lock()
    if contents is not None: self.MergeFromString(contents)

  def family(self): return self.family_

  def set_family(self, x):
    self.has_family_ = 1
    self.family_ = x

  def clear_family(self):
    if self.has_family_:
      self.has_family_ = 0
      self.family_ = 0

  def has_family(self): return self.has_family_

  def protocol(self): return self.protocol_

  def set_protocol(self, x):
    self.has_protocol_ = 1
    self.protocol_ = x

  def clear_protocol(self):
    if self.has_protocol_:
      self.has_protocol_ = 0
      self.protocol_ = 0

  def has_protocol(self): return self.has_protocol_

  def socket_options_size(self): return len(self.socket_options_)
  def socket_options_list(self): return self.socket_options_

  def socket_options(self, i):
    return self.socket_options_[i]

  def mutable_socket_options(self, i):
    return self.socket_options_[i]

  def add_socket_options(self):
    x = SocketOption()
    self.socket_options_.append(x)
    return x

  def clear_socket_options(self):
    self.socket_options_ = []
  def proxy_external_ip(self):
    if self.proxy_external_ip_ is None:
      self.lazy_init_lock_.acquire()
      try:
        if self.proxy_external_ip_ is None: self.proxy_external_ip_ = AddressPort()
      finally:
        self.lazy_init_lock_.release()
    return self.proxy_external_ip_

  def mutable_proxy_external_ip(self): self.has_proxy_external_ip_ = 1; return self.proxy_external_ip()

  def clear_proxy_external_ip(self):

    if self.has_proxy_external_ip_:
      self.has_proxy_external_ip_ = 0;
      if self.proxy_external_ip_ is not None: self.proxy_external_ip_.Clear()

  def has_proxy_external_ip(self): return self.has_proxy_external_ip_

  def listen_backlog(self): return self.listen_backlog_

  def set_listen_backlog(self, x):
    self.has_listen_backlog_ = 1
    self.listen_backlog_ = x

  def clear_listen_backlog(self):
    if self.has_listen_backlog_:
      self.has_listen_backlog_ = 0
      self.listen_backlog_ = 0

  def has_listen_backlog(self): return self.has_listen_backlog_

  def remote_ip(self):
    if self.remote_ip_ is None:
      self.lazy_init_lock_.acquire()
      try:
        if self.remote_ip_ is None: self.remote_ip_ = AddressPort()
      finally:
        self.lazy_init_lock_.release()
    return self.remote_ip_

  def mutable_remote_ip(self): self.has_remote_ip_ = 1; return self.remote_ip()

  def clear_remote_ip(self):

    if self.has_remote_ip_:
      self.has_remote_ip_ = 0;
      if self.remote_ip_ is not None: self.remote_ip_.Clear()

  def has_remote_ip(self): return self.has_remote_ip_

  def timeout_seconds(self): return self.timeout_seconds_

  def set_timeout_seconds(self, x):
    self.has_timeout_seconds_ = 1
    self.timeout_seconds_ = x

  def clear_timeout_seconds(self):
    if self.has_timeout_seconds_:
      self.has_timeout_seconds_ = 0
      self.timeout_seconds_ = -1.0

  def has_timeout_seconds(self): return self.has_timeout_seconds_

  def ssl_ctx(self):
    if self.ssl_ctx_ is None:
      self.lazy_init_lock_.acquire()
      try:
        if self.ssl_ctx_ is None: self.ssl_ctx_ = SSLContext()
      finally:
        self.lazy_init_lock_.release()
    return self.ssl_ctx_

  def mutable_ssl_ctx(self): self.has_ssl_ctx_ = 1; return self.ssl_ctx()

  def clear_ssl_ctx(self):

    if self.has_ssl_ctx_:
      self.has_ssl_ctx_ = 0;
      if self.ssl_ctx_ is not None: self.ssl_ctx_.Clear()

  def has_ssl_ctx(self): return self.has_ssl_ctx_


  def MergeFrom(self, x):
    assert x is not self
    if (x.has_family()): self.set_family(x.family())
    if (x.has_protocol()): self.set_protocol(x.protocol())
    for i in xrange(x.socket_options_size()): self.add_socket_options().CopyFrom(x.socket_options(i))
    if (x.has_proxy_external_ip()): self.mutable_proxy_external_ip().MergeFrom(x.proxy_external_ip())
    if (x.has_listen_backlog()): self.set_listen_backlog(x.listen_backlog())
    if (x.has_remote_ip()): self.mutable_remote_ip().MergeFrom(x.remote_ip())
    if (x.has_timeout_seconds()): self.set_timeout_seconds(x.timeout_seconds())
    if (x.has_ssl_ctx()): self.mutable_ssl_ctx().MergeFrom(x.ssl_ctx())

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.CreateSocketRequest', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.CreateSocketRequest')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.CreateSocketRequest')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.CreateSocketRequest', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.CreateSocketRequest', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.CreateSocketRequest', s)


  def Equals(self, x):
    if x is self: return 1
    if self.has_family_ != x.has_family_: return 0
    if self.has_family_ and self.family_ != x.family_: return 0
    if self.has_protocol_ != x.has_protocol_: return 0
    if self.has_protocol_ and self.protocol_ != x.protocol_: return 0
    if len(self.socket_options_) != len(x.socket_options_): return 0
    for e1, e2 in zip(self.socket_options_, x.socket_options_):
      if e1 != e2: return 0
    if self.has_proxy_external_ip_ != x.has_proxy_external_ip_: return 0
    if self.has_proxy_external_ip_ and self.proxy_external_ip_ != x.proxy_external_ip_: return 0
    if self.has_listen_backlog_ != x.has_listen_backlog_: return 0
    if self.has_listen_backlog_ and self.listen_backlog_ != x.listen_backlog_: return 0
    if self.has_remote_ip_ != x.has_remote_ip_: return 0
    if self.has_remote_ip_ and self.remote_ip_ != x.remote_ip_: return 0
    if self.has_timeout_seconds_ != x.has_timeout_seconds_: return 0
    if self.has_timeout_seconds_ and self.timeout_seconds_ != x.timeout_seconds_: return 0
    if self.has_ssl_ctx_ != x.has_ssl_ctx_: return 0
    if self.has_ssl_ctx_ and self.ssl_ctx_ != x.ssl_ctx_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    if (not self.has_family_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: family not set.')
    if (not self.has_protocol_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: protocol not set.')
    for p in self.socket_options_:
      if not p.IsInitialized(debug_strs): initialized=0
    if (self.has_proxy_external_ip_ and not self.proxy_external_ip_.IsInitialized(debug_strs)): initialized = 0
    if (self.has_remote_ip_ and not self.remote_ip_.IsInitialized(debug_strs)): initialized = 0
    if (self.has_ssl_ctx_ and not self.ssl_ctx_.IsInitialized(debug_strs)): initialized = 0
    return initialized

  def ByteSize(self):
    n = 0
    n += self.lengthVarInt64(self.family_)
    n += self.lengthVarInt64(self.protocol_)
    n += 1 * len(self.socket_options_)
    for i in xrange(len(self.socket_options_)): n += self.lengthString(self.socket_options_[i].ByteSize())
    if (self.has_proxy_external_ip_): n += 1 + self.lengthString(self.proxy_external_ip_.ByteSize())
    if (self.has_listen_backlog_): n += 1 + self.lengthVarInt64(self.listen_backlog_)
    if (self.has_remote_ip_): n += 1 + self.lengthString(self.remote_ip_.ByteSize())
    if (self.has_timeout_seconds_): n += 9
    if (self.has_ssl_ctx_): n += 1 + self.lengthString(self.ssl_ctx_.ByteSize())
    return n + 2

  def ByteSizePartial(self):
    n = 0
    if (self.has_family_):
      n += 1
      n += self.lengthVarInt64(self.family_)
    if (self.has_protocol_):
      n += 1
      n += self.lengthVarInt64(self.protocol_)
    n += 1 * len(self.socket_options_)
    for i in xrange(len(self.socket_options_)): n += self.lengthString(self.socket_options_[i].ByteSizePartial())
    if (self.has_proxy_external_ip_): n += 1 + self.lengthString(self.proxy_external_ip_.ByteSizePartial())
    if (self.has_listen_backlog_): n += 1 + self.lengthVarInt64(self.listen_backlog_)
    if (self.has_remote_ip_): n += 1 + self.lengthString(self.remote_ip_.ByteSizePartial())
    if (self.has_timeout_seconds_): n += 9
    if (self.has_ssl_ctx_): n += 1 + self.lengthString(self.ssl_ctx_.ByteSizePartial())
    return n

  def Clear(self):
    self.clear_family()
    self.clear_protocol()
    self.clear_socket_options()
    self.clear_proxy_external_ip()
    self.clear_listen_backlog()
    self.clear_remote_ip()
    self.clear_timeout_seconds()
    self.clear_ssl_ctx()

  def OutputUnchecked(self, out):
    out.putVarInt32(8)
    out.putVarInt32(self.family_)
    out.putVarInt32(16)
    out.putVarInt32(self.protocol_)
    for i in xrange(len(self.socket_options_)):
      out.putVarInt32(26)
      out.putVarInt32(self.socket_options_[i].ByteSize())
      self.socket_options_[i].OutputUnchecked(out)
    if (self.has_proxy_external_ip_):
      out.putVarInt32(34)
      out.putVarInt32(self.proxy_external_ip_.ByteSize())
      self.proxy_external_ip_.OutputUnchecked(out)
    if (self.has_listen_backlog_):
      out.putVarInt32(40)
      out.putVarInt32(self.listen_backlog_)
    if (self.has_remote_ip_):
      out.putVarInt32(50)
      out.putVarInt32(self.remote_ip_.ByteSize())
      self.remote_ip_.OutputUnchecked(out)
    if (self.has_timeout_seconds_):
      out.putVarInt32(57)
      out.putDouble(self.timeout_seconds_)
    if (self.has_ssl_ctx_):
      out.putVarInt32(66)
      out.putVarInt32(self.ssl_ctx_.ByteSize())
      self.ssl_ctx_.OutputUnchecked(out)

  def OutputPartial(self, out):
    if (self.has_family_):
      out.putVarInt32(8)
      out.putVarInt32(self.family_)
    if (self.has_protocol_):
      out.putVarInt32(16)
      out.putVarInt32(self.protocol_)
    for i in xrange(len(self.socket_options_)):
      out.putVarInt32(26)
      out.putVarInt32(self.socket_options_[i].ByteSizePartial())
      self.socket_options_[i].OutputPartial(out)
    if (self.has_proxy_external_ip_):
      out.putVarInt32(34)
      out.putVarInt32(self.proxy_external_ip_.ByteSizePartial())
      self.proxy_external_ip_.OutputPartial(out)
    if (self.has_listen_backlog_):
      out.putVarInt32(40)
      out.putVarInt32(self.listen_backlog_)
    if (self.has_remote_ip_):
      out.putVarInt32(50)
      out.putVarInt32(self.remote_ip_.ByteSizePartial())
      self.remote_ip_.OutputPartial(out)
    if (self.has_timeout_seconds_):
      out.putVarInt32(57)
      out.putDouble(self.timeout_seconds_)
    if (self.has_ssl_ctx_):
      out.putVarInt32(66)
      out.putVarInt32(self.ssl_ctx_.ByteSizePartial())
      self.ssl_ctx_.OutputPartial(out)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 8:
        self.set_family(d.getVarInt32())
        continue
      if tt == 16:
        self.set_protocol(d.getVarInt32())
        continue
      if tt == 26:
        length = d.getVarInt32()
        tmp = ProtocolBuffer.Decoder(d.buffer(), d.pos(), d.pos() + length)
        d.skip(length)
        self.add_socket_options().TryMerge(tmp)
        continue
      if tt == 34:
        length = d.getVarInt32()
        tmp = ProtocolBuffer.Decoder(d.buffer(), d.pos(), d.pos() + length)
        d.skip(length)
        self.mutable_proxy_external_ip().TryMerge(tmp)
        continue
      if tt == 40:
        self.set_listen_backlog(d.getVarInt32())
        continue
      if tt == 50:
        length = d.getVarInt32()
        tmp = ProtocolBuffer.Decoder(d.buffer(), d.pos(), d.pos() + length)
        d.skip(length)
        self.mutable_remote_ip().TryMerge(tmp)
        continue
      if tt == 57:
        self.set_timeout_seconds(d.getDouble())
        continue
      if tt == 66:
        length = d.getVarInt32()
        tmp = ProtocolBuffer.Decoder(d.buffer(), d.pos(), d.pos() + length)
        d.skip(length)
        self.mutable_ssl_ctx().TryMerge(tmp)
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    if self.has_family_: res+=prefix+("family: %s\n" % self.DebugFormatInt32(self.family_))
    if self.has_protocol_: res+=prefix+("protocol: %s\n" % self.DebugFormatInt32(self.protocol_))
    cnt=0
    for e in self.socket_options_:
      elm=""
      if printElemNumber: elm="(%d)" % cnt
      res+=prefix+("socket_options%s <\n" % elm)
      res+=e.__str__(prefix + "  ", printElemNumber)
      res+=prefix+">\n"
      cnt+=1
    if self.has_proxy_external_ip_:
      res+=prefix+"proxy_external_ip <\n"
      res+=self.proxy_external_ip_.__str__(prefix + "  ", printElemNumber)
      res+=prefix+">\n"
    if self.has_listen_backlog_: res+=prefix+("listen_backlog: %s\n" % self.DebugFormatInt32(self.listen_backlog_))
    if self.has_remote_ip_:
      res+=prefix+"remote_ip <\n"
      res+=self.remote_ip_.__str__(prefix + "  ", printElemNumber)
      res+=prefix+">\n"
    if self.has_timeout_seconds_: res+=prefix+("timeout_seconds: %s\n" % self.DebugFormat(self.timeout_seconds_))
    if self.has_ssl_ctx_:
      res+=prefix+"ssl_ctx <\n"
      res+=self.ssl_ctx_.__str__(prefix + "  ", printElemNumber)
      res+=prefix+">\n"
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  kfamily = 1
  kprotocol = 2
  ksocket_options = 3
  kproxy_external_ip = 4
  klisten_backlog = 5
  kremote_ip = 6
  ktimeout_seconds = 7
  kssl_ctx = 8

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "family",
    2: "protocol",
    3: "socket_options",
    4: "proxy_external_ip",
    5: "listen_backlog",
    6: "remote_ip",
    7: "timeout_seconds",
    8: "ssl_ctx",
  }, 8)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.NUMERIC,
    2: ProtocolBuffer.Encoder.NUMERIC,
    3: ProtocolBuffer.Encoder.STRING,
    4: ProtocolBuffer.Encoder.STRING,
    5: ProtocolBuffer.Encoder.NUMERIC,
    6: ProtocolBuffer.Encoder.STRING,
    7: ProtocolBuffer.Encoder.DOUBLE,
    8: ProtocolBuffer.Encoder.STRING,
  }, 8, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("WjhhcHBob3N0aW5nL2FwaS9yZW1vdGVfc29ja2V0L3JlbW90ZV9zb2NrZXRfc2VydmljZS5wcm90bwoeYXBwaG9zdGluZy5DcmVhdGVTb2NrZXRSZXF1ZXN0ExoGZmFtaWx5IAEoADAFOAJoABQTGghwcm90b2NvbCACKAAwBTgCaAEUExoOc29ja2V0X29wdGlvbnMgAygCMAs4A0oXYXBwaG9zdGluZy5Tb2NrZXRPcHRpb24UExoRcHJveHlfZXh0ZXJuYWxfaXAgBCgCMAs4AUoWYXBwaG9zdGluZy5BZGRyZXNzUG9ydBQTGg5saXN0ZW5fYmFja2xvZyAFKAAwBTgBQgEwowGqAQdkZWZhdWx0sgEBMKQBFBMaCXJlbW90ZV9pcCAGKAIwCzgBShZhcHBob3N0aW5nLkFkZHJlc3NQb3J0FBMaD3RpbWVvdXRfc2Vjb25kcyAHKAEwATgBQgQtMS4wowGqAQdkZWZhdWx0sgEELTEuMKQBFBMaB3NzbF9jdHggCCgCMAs4AUoVYXBwaG9zdGluZy5TU0xDb250ZXh0FHN6DFNvY2tldEZhbWlseYsBkgEESVB2NJgBAYwBiwGSAQRJUHY2mAECjAF0c3oOU29ja2V0UHJvdG9jb2yLAZIBA1RDUJgBAYwBiwGSAQNVRFCYAQKMAXTCASNhcHBob3N0aW5nLlJlbW90ZVNvY2tldFNlcnZpY2VFcnJvcg=="))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class CreateSocketReply(ProtocolBuffer.ProtocolMessage):
  has_socket_descriptor_ = 0
  socket_descriptor_ = ""
  has_ssl_session_ = 0
  ssl_session_ = None

  def __init__(self, contents=None):
    self.lazy_init_lock_ = thread.allocate_lock()
    if contents is not None: self.MergeFromString(contents)

  def socket_descriptor(self): return self.socket_descriptor_

  def set_socket_descriptor(self, x):
    self.has_socket_descriptor_ = 1
    self.socket_descriptor_ = x

  def clear_socket_descriptor(self):
    if self.has_socket_descriptor_:
      self.has_socket_descriptor_ = 0
      self.socket_descriptor_ = ""

  def has_socket_descriptor(self): return self.has_socket_descriptor_

  def ssl_session(self):
    if self.ssl_session_ is None:
      self.lazy_init_lock_.acquire()
      try:
        if self.ssl_session_ is None: self.ssl_session_ = SSLSession()
      finally:
        self.lazy_init_lock_.release()
    return self.ssl_session_

  def mutable_ssl_session(self): self.has_ssl_session_ = 1; return self.ssl_session()

  def clear_ssl_session(self):

    if self.has_ssl_session_:
      self.has_ssl_session_ = 0;
      if self.ssl_session_ is not None: self.ssl_session_.Clear()

  def has_ssl_session(self): return self.has_ssl_session_


  def MergeFrom(self, x):
    assert x is not self
    if (x.has_socket_descriptor()): self.set_socket_descriptor(x.socket_descriptor())
    if (x.has_ssl_session()): self.mutable_ssl_session().MergeFrom(x.ssl_session())

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.CreateSocketReply', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.CreateSocketReply')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.CreateSocketReply')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.CreateSocketReply', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.CreateSocketReply', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.CreateSocketReply', s)


  def Equals(self, x):
    if x is self: return 1
    if self.has_socket_descriptor_ != x.has_socket_descriptor_: return 0
    if self.has_socket_descriptor_ and self.socket_descriptor_ != x.socket_descriptor_: return 0
    if self.has_ssl_session_ != x.has_ssl_session_: return 0
    if self.has_ssl_session_ and self.ssl_session_ != x.ssl_session_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    if (self.has_ssl_session_ and not self.ssl_session_.IsInitialized(debug_strs)): initialized = 0
    return initialized

  def ByteSize(self):
    n = 0
    if (self.has_socket_descriptor_): n += 1 + self.lengthString(len(self.socket_descriptor_))
    if (self.has_ssl_session_): n += 1 + self.lengthString(self.ssl_session_.ByteSize())
    return n

  def ByteSizePartial(self):
    n = 0
    if (self.has_socket_descriptor_): n += 1 + self.lengthString(len(self.socket_descriptor_))
    if (self.has_ssl_session_): n += 1 + self.lengthString(self.ssl_session_.ByteSizePartial())
    return n

  def Clear(self):
    self.clear_socket_descriptor()
    self.clear_ssl_session()

  def OutputUnchecked(self, out):
    if (self.has_socket_descriptor_):
      out.putVarInt32(10)
      out.putPrefixedString(self.socket_descriptor_)
    if (self.has_ssl_session_):
      out.putVarInt32(18)
      out.putVarInt32(self.ssl_session_.ByteSize())
      self.ssl_session_.OutputUnchecked(out)

  def OutputPartial(self, out):
    if (self.has_socket_descriptor_):
      out.putVarInt32(10)
      out.putPrefixedString(self.socket_descriptor_)
    if (self.has_ssl_session_):
      out.putVarInt32(18)
      out.putVarInt32(self.ssl_session_.ByteSizePartial())
      self.ssl_session_.OutputPartial(out)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 10:
        self.set_socket_descriptor(d.getPrefixedString())
        continue
      if tt == 18:
        length = d.getVarInt32()
        tmp = ProtocolBuffer.Decoder(d.buffer(), d.pos(), d.pos() + length)
        d.skip(length)
        self.mutable_ssl_session().TryMerge(tmp)
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    if self.has_socket_descriptor_: res+=prefix+("socket_descriptor: %s\n" % self.DebugFormatString(self.socket_descriptor_))
    if self.has_ssl_session_:
      res+=prefix+"ssl_session <\n"
      res+=self.ssl_session_.__str__(prefix + "  ", printElemNumber)
      res+=prefix+">\n"
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  ksocket_descriptor = 1
  kssl_session = 2

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "socket_descriptor",
    2: "ssl_session",
  }, 2)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.STRING,
    2: ProtocolBuffer.Encoder.STRING,
  }, 2, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("WjhhcHBob3N0aW5nL2FwaS9yZW1vdGVfc29ja2V0L3JlbW90ZV9zb2NrZXRfc2VydmljZS5wcm90bwocYXBwaG9zdGluZy5DcmVhdGVTb2NrZXRSZXBseRMaEXNvY2tldF9kZXNjcmlwdG9yIAEoAjAJOAEUExoLc3NsX3Nlc3Npb24gAigCMAs4AUoVYXBwaG9zdGluZy5TU0xTZXNzaW9uFMIBI2FwcGhvc3RpbmcuUmVtb3RlU29ja2V0U2VydmljZUVycm9y"))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class BindRequest(ProtocolBuffer.ProtocolMessage):
  has_socket_descriptor_ = 0
  socket_descriptor_ = ""
  has_proxy_external_ip_ = 0

  def __init__(self, contents=None):
    self.proxy_external_ip_ = AddressPort()
    if contents is not None: self.MergeFromString(contents)

  def socket_descriptor(self): return self.socket_descriptor_

  def set_socket_descriptor(self, x):
    self.has_socket_descriptor_ = 1
    self.socket_descriptor_ = x

  def clear_socket_descriptor(self):
    if self.has_socket_descriptor_:
      self.has_socket_descriptor_ = 0
      self.socket_descriptor_ = ""

  def has_socket_descriptor(self): return self.has_socket_descriptor_

  def proxy_external_ip(self): return self.proxy_external_ip_

  def mutable_proxy_external_ip(self): self.has_proxy_external_ip_ = 1; return self.proxy_external_ip_

  def clear_proxy_external_ip(self):self.has_proxy_external_ip_ = 0; self.proxy_external_ip_.Clear()

  def has_proxy_external_ip(self): return self.has_proxy_external_ip_


  def MergeFrom(self, x):
    assert x is not self
    if (x.has_socket_descriptor()): self.set_socket_descriptor(x.socket_descriptor())
    if (x.has_proxy_external_ip()): self.mutable_proxy_external_ip().MergeFrom(x.proxy_external_ip())

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.BindRequest', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.BindRequest')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.BindRequest')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.BindRequest', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.BindRequest', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.BindRequest', s)


  def Equals(self, x):
    if x is self: return 1
    if self.has_socket_descriptor_ != x.has_socket_descriptor_: return 0
    if self.has_socket_descriptor_ and self.socket_descriptor_ != x.socket_descriptor_: return 0
    if self.has_proxy_external_ip_ != x.has_proxy_external_ip_: return 0
    if self.has_proxy_external_ip_ and self.proxy_external_ip_ != x.proxy_external_ip_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    if (not self.has_socket_descriptor_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: socket_descriptor not set.')
    if (not self.has_proxy_external_ip_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: proxy_external_ip not set.')
    elif not self.proxy_external_ip_.IsInitialized(debug_strs): initialized = 0
    return initialized

  def ByteSize(self):
    n = 0
    n += self.lengthString(len(self.socket_descriptor_))
    n += self.lengthString(self.proxy_external_ip_.ByteSize())
    return n + 2

  def ByteSizePartial(self):
    n = 0
    if (self.has_socket_descriptor_):
      n += 1
      n += self.lengthString(len(self.socket_descriptor_))
    if (self.has_proxy_external_ip_):
      n += 1
      n += self.lengthString(self.proxy_external_ip_.ByteSizePartial())
    return n

  def Clear(self):
    self.clear_socket_descriptor()
    self.clear_proxy_external_ip()

  def OutputUnchecked(self, out):
    out.putVarInt32(10)
    out.putPrefixedString(self.socket_descriptor_)
    out.putVarInt32(18)
    out.putVarInt32(self.proxy_external_ip_.ByteSize())
    self.proxy_external_ip_.OutputUnchecked(out)

  def OutputPartial(self, out):
    if (self.has_socket_descriptor_):
      out.putVarInt32(10)
      out.putPrefixedString(self.socket_descriptor_)
    if (self.has_proxy_external_ip_):
      out.putVarInt32(18)
      out.putVarInt32(self.proxy_external_ip_.ByteSizePartial())
      self.proxy_external_ip_.OutputPartial(out)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 10:
        self.set_socket_descriptor(d.getPrefixedString())
        continue
      if tt == 18:
        length = d.getVarInt32()
        tmp = ProtocolBuffer.Decoder(d.buffer(), d.pos(), d.pos() + length)
        d.skip(length)
        self.mutable_proxy_external_ip().TryMerge(tmp)
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    if self.has_socket_descriptor_: res+=prefix+("socket_descriptor: %s\n" % self.DebugFormatString(self.socket_descriptor_))
    if self.has_proxy_external_ip_:
      res+=prefix+"proxy_external_ip <\n"
      res+=self.proxy_external_ip_.__str__(prefix + "  ", printElemNumber)
      res+=prefix+">\n"
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  ksocket_descriptor = 1
  kproxy_external_ip = 2

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "socket_descriptor",
    2: "proxy_external_ip",
  }, 2)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.STRING,
    2: ProtocolBuffer.Encoder.STRING,
  }, 2, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("WjhhcHBob3N0aW5nL2FwaS9yZW1vdGVfc29ja2V0L3JlbW90ZV9zb2NrZXRfc2VydmljZS5wcm90bwoWYXBwaG9zdGluZy5CaW5kUmVxdWVzdBMaEXNvY2tldF9kZXNjcmlwdG9yIAEoAjAJOAIUExoRcHJveHlfZXh0ZXJuYWxfaXAgAigCMAs4AkoWYXBwaG9zdGluZy5BZGRyZXNzUG9ydBTCASNhcHBob3N0aW5nLlJlbW90ZVNvY2tldFNlcnZpY2VFcnJvcg=="))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class BindReply(ProtocolBuffer.ProtocolMessage):

  def __init__(self, contents=None):
    pass
    if contents is not None: self.MergeFromString(contents)


  def MergeFrom(self, x):
    assert x is not self

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.BindReply', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.BindReply')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.BindReply')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.BindReply', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.BindReply', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.BindReply', s)


  def Equals(self, x):
    if x is self: return 1
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    return initialized

  def ByteSize(self):
    n = 0
    return n

  def ByteSizePartial(self):
    n = 0
    return n

  def Clear(self):
    pass

  def OutputUnchecked(self, out):
    pass

  def OutputPartial(self, out):
    pass

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])


  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
  }, 0)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
  }, 0, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("WjhhcHBob3N0aW5nL2FwaS9yZW1vdGVfc29ja2V0L3JlbW90ZV9zb2NrZXRfc2VydmljZS5wcm90bwoUYXBwaG9zdGluZy5CaW5kUmVwbHnCASNhcHBob3N0aW5nLlJlbW90ZVNvY2tldFNlcnZpY2VFcnJvcg=="))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class GetSocketNameRequest(ProtocolBuffer.ProtocolMessage):
  has_socket_descriptor_ = 0
  socket_descriptor_ = ""

  def __init__(self, contents=None):
    if contents is not None: self.MergeFromString(contents)

  def socket_descriptor(self): return self.socket_descriptor_

  def set_socket_descriptor(self, x):
    self.has_socket_descriptor_ = 1
    self.socket_descriptor_ = x

  def clear_socket_descriptor(self):
    if self.has_socket_descriptor_:
      self.has_socket_descriptor_ = 0
      self.socket_descriptor_ = ""

  def has_socket_descriptor(self): return self.has_socket_descriptor_


  def MergeFrom(self, x):
    assert x is not self
    if (x.has_socket_descriptor()): self.set_socket_descriptor(x.socket_descriptor())

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.GetSocketNameRequest', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.GetSocketNameRequest')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.GetSocketNameRequest')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.GetSocketNameRequest', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.GetSocketNameRequest', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.GetSocketNameRequest', s)


  def Equals(self, x):
    if x is self: return 1
    if self.has_socket_descriptor_ != x.has_socket_descriptor_: return 0
    if self.has_socket_descriptor_ and self.socket_descriptor_ != x.socket_descriptor_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    if (not self.has_socket_descriptor_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: socket_descriptor not set.')
    return initialized

  def ByteSize(self):
    n = 0
    n += self.lengthString(len(self.socket_descriptor_))
    return n + 1

  def ByteSizePartial(self):
    n = 0
    if (self.has_socket_descriptor_):
      n += 1
      n += self.lengthString(len(self.socket_descriptor_))
    return n

  def Clear(self):
    self.clear_socket_descriptor()

  def OutputUnchecked(self, out):
    out.putVarInt32(10)
    out.putPrefixedString(self.socket_descriptor_)

  def OutputPartial(self, out):
    if (self.has_socket_descriptor_):
      out.putVarInt32(10)
      out.putPrefixedString(self.socket_descriptor_)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 10:
        self.set_socket_descriptor(d.getPrefixedString())
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    if self.has_socket_descriptor_: res+=prefix+("socket_descriptor: %s\n" % self.DebugFormatString(self.socket_descriptor_))
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  ksocket_descriptor = 1

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "socket_descriptor",
  }, 1)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.STRING,
  }, 1, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("WjhhcHBob3N0aW5nL2FwaS9yZW1vdGVfc29ja2V0L3JlbW90ZV9zb2NrZXRfc2VydmljZS5wcm90bwofYXBwaG9zdGluZy5HZXRTb2NrZXROYW1lUmVxdWVzdBMaEXNvY2tldF9kZXNjcmlwdG9yIAEoAjAJOAIUwgEjYXBwaG9zdGluZy5SZW1vdGVTb2NrZXRTZXJ2aWNlRXJyb3I="))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class GetSocketNameReply(ProtocolBuffer.ProtocolMessage):
  has_proxy_external_ip_ = 0
  proxy_external_ip_ = None

  def __init__(self, contents=None):
    self.lazy_init_lock_ = thread.allocate_lock()
    if contents is not None: self.MergeFromString(contents)

  def proxy_external_ip(self):
    if self.proxy_external_ip_ is None:
      self.lazy_init_lock_.acquire()
      try:
        if self.proxy_external_ip_ is None: self.proxy_external_ip_ = AddressPort()
      finally:
        self.lazy_init_lock_.release()
    return self.proxy_external_ip_

  def mutable_proxy_external_ip(self): self.has_proxy_external_ip_ = 1; return self.proxy_external_ip()

  def clear_proxy_external_ip(self):

    if self.has_proxy_external_ip_:
      self.has_proxy_external_ip_ = 0;
      if self.proxy_external_ip_ is not None: self.proxy_external_ip_.Clear()

  def has_proxy_external_ip(self): return self.has_proxy_external_ip_


  def MergeFrom(self, x):
    assert x is not self
    if (x.has_proxy_external_ip()): self.mutable_proxy_external_ip().MergeFrom(x.proxy_external_ip())

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.GetSocketNameReply', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.GetSocketNameReply')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.GetSocketNameReply')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.GetSocketNameReply', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.GetSocketNameReply', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.GetSocketNameReply', s)


  def Equals(self, x):
    if x is self: return 1
    if self.has_proxy_external_ip_ != x.has_proxy_external_ip_: return 0
    if self.has_proxy_external_ip_ and self.proxy_external_ip_ != x.proxy_external_ip_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    if (self.has_proxy_external_ip_ and not self.proxy_external_ip_.IsInitialized(debug_strs)): initialized = 0
    return initialized

  def ByteSize(self):
    n = 0
    if (self.has_proxy_external_ip_): n += 1 + self.lengthString(self.proxy_external_ip_.ByteSize())
    return n

  def ByteSizePartial(self):
    n = 0
    if (self.has_proxy_external_ip_): n += 1 + self.lengthString(self.proxy_external_ip_.ByteSizePartial())
    return n

  def Clear(self):
    self.clear_proxy_external_ip()

  def OutputUnchecked(self, out):
    if (self.has_proxy_external_ip_):
      out.putVarInt32(18)
      out.putVarInt32(self.proxy_external_ip_.ByteSize())
      self.proxy_external_ip_.OutputUnchecked(out)

  def OutputPartial(self, out):
    if (self.has_proxy_external_ip_):
      out.putVarInt32(18)
      out.putVarInt32(self.proxy_external_ip_.ByteSizePartial())
      self.proxy_external_ip_.OutputPartial(out)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 18:
        length = d.getVarInt32()
        tmp = ProtocolBuffer.Decoder(d.buffer(), d.pos(), d.pos() + length)
        d.skip(length)
        self.mutable_proxy_external_ip().TryMerge(tmp)
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    if self.has_proxy_external_ip_:
      res+=prefix+"proxy_external_ip <\n"
      res+=self.proxy_external_ip_.__str__(prefix + "  ", printElemNumber)
      res+=prefix+">\n"
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  kproxy_external_ip = 2

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    2: "proxy_external_ip",
  }, 2)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    2: ProtocolBuffer.Encoder.STRING,
  }, 2, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("WjhhcHBob3N0aW5nL2FwaS9yZW1vdGVfc29ja2V0L3JlbW90ZV9zb2NrZXRfc2VydmljZS5wcm90bwodYXBwaG9zdGluZy5HZXRTb2NrZXROYW1lUmVwbHkTGhFwcm94eV9leHRlcm5hbF9pcCACKAIwCzgBShZhcHBob3N0aW5nLkFkZHJlc3NQb3J0FMIBI2FwcGhvc3RpbmcuUmVtb3RlU29ja2V0U2VydmljZUVycm9y"))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class GetPeerNameRequest(ProtocolBuffer.ProtocolMessage):
  has_socket_descriptor_ = 0
  socket_descriptor_ = ""

  def __init__(self, contents=None):
    if contents is not None: self.MergeFromString(contents)

  def socket_descriptor(self): return self.socket_descriptor_

  def set_socket_descriptor(self, x):
    self.has_socket_descriptor_ = 1
    self.socket_descriptor_ = x

  def clear_socket_descriptor(self):
    if self.has_socket_descriptor_:
      self.has_socket_descriptor_ = 0
      self.socket_descriptor_ = ""

  def has_socket_descriptor(self): return self.has_socket_descriptor_


  def MergeFrom(self, x):
    assert x is not self
    if (x.has_socket_descriptor()): self.set_socket_descriptor(x.socket_descriptor())

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.GetPeerNameRequest', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.GetPeerNameRequest')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.GetPeerNameRequest')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.GetPeerNameRequest', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.GetPeerNameRequest', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.GetPeerNameRequest', s)


  def Equals(self, x):
    if x is self: return 1
    if self.has_socket_descriptor_ != x.has_socket_descriptor_: return 0
    if self.has_socket_descriptor_ and self.socket_descriptor_ != x.socket_descriptor_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    if (not self.has_socket_descriptor_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: socket_descriptor not set.')
    return initialized

  def ByteSize(self):
    n = 0
    n += self.lengthString(len(self.socket_descriptor_))
    return n + 1

  def ByteSizePartial(self):
    n = 0
    if (self.has_socket_descriptor_):
      n += 1
      n += self.lengthString(len(self.socket_descriptor_))
    return n

  def Clear(self):
    self.clear_socket_descriptor()

  def OutputUnchecked(self, out):
    out.putVarInt32(10)
    out.putPrefixedString(self.socket_descriptor_)

  def OutputPartial(self, out):
    if (self.has_socket_descriptor_):
      out.putVarInt32(10)
      out.putPrefixedString(self.socket_descriptor_)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 10:
        self.set_socket_descriptor(d.getPrefixedString())
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    if self.has_socket_descriptor_: res+=prefix+("socket_descriptor: %s\n" % self.DebugFormatString(self.socket_descriptor_))
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  ksocket_descriptor = 1

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "socket_descriptor",
  }, 1)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.STRING,
  }, 1, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("WjhhcHBob3N0aW5nL2FwaS9yZW1vdGVfc29ja2V0L3JlbW90ZV9zb2NrZXRfc2VydmljZS5wcm90bwodYXBwaG9zdGluZy5HZXRQZWVyTmFtZVJlcXVlc3QTGhFzb2NrZXRfZGVzY3JpcHRvciABKAIwCTgCFMIBI2FwcGhvc3RpbmcuUmVtb3RlU29ja2V0U2VydmljZUVycm9y"))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class GetPeerNameReply(ProtocolBuffer.ProtocolMessage):
  has_peer_ip_ = 0
  peer_ip_ = None

  def __init__(self, contents=None):
    self.lazy_init_lock_ = thread.allocate_lock()
    if contents is not None: self.MergeFromString(contents)

  def peer_ip(self):
    if self.peer_ip_ is None:
      self.lazy_init_lock_.acquire()
      try:
        if self.peer_ip_ is None: self.peer_ip_ = AddressPort()
      finally:
        self.lazy_init_lock_.release()
    return self.peer_ip_

  def mutable_peer_ip(self): self.has_peer_ip_ = 1; return self.peer_ip()

  def clear_peer_ip(self):

    if self.has_peer_ip_:
      self.has_peer_ip_ = 0;
      if self.peer_ip_ is not None: self.peer_ip_.Clear()

  def has_peer_ip(self): return self.has_peer_ip_


  def MergeFrom(self, x):
    assert x is not self
    if (x.has_peer_ip()): self.mutable_peer_ip().MergeFrom(x.peer_ip())

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.GetPeerNameReply', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.GetPeerNameReply')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.GetPeerNameReply')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.GetPeerNameReply', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.GetPeerNameReply', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.GetPeerNameReply', s)


  def Equals(self, x):
    if x is self: return 1
    if self.has_peer_ip_ != x.has_peer_ip_: return 0
    if self.has_peer_ip_ and self.peer_ip_ != x.peer_ip_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    if (self.has_peer_ip_ and not self.peer_ip_.IsInitialized(debug_strs)): initialized = 0
    return initialized

  def ByteSize(self):
    n = 0
    if (self.has_peer_ip_): n += 1 + self.lengthString(self.peer_ip_.ByteSize())
    return n

  def ByteSizePartial(self):
    n = 0
    if (self.has_peer_ip_): n += 1 + self.lengthString(self.peer_ip_.ByteSizePartial())
    return n

  def Clear(self):
    self.clear_peer_ip()

  def OutputUnchecked(self, out):
    if (self.has_peer_ip_):
      out.putVarInt32(18)
      out.putVarInt32(self.peer_ip_.ByteSize())
      self.peer_ip_.OutputUnchecked(out)

  def OutputPartial(self, out):
    if (self.has_peer_ip_):
      out.putVarInt32(18)
      out.putVarInt32(self.peer_ip_.ByteSizePartial())
      self.peer_ip_.OutputPartial(out)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 18:
        length = d.getVarInt32()
        tmp = ProtocolBuffer.Decoder(d.buffer(), d.pos(), d.pos() + length)
        d.skip(length)
        self.mutable_peer_ip().TryMerge(tmp)
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    if self.has_peer_ip_:
      res+=prefix+"peer_ip <\n"
      res+=self.peer_ip_.__str__(prefix + "  ", printElemNumber)
      res+=prefix+">\n"
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  kpeer_ip = 2

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    2: "peer_ip",
  }, 2)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    2: ProtocolBuffer.Encoder.STRING,
  }, 2, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("WjhhcHBob3N0aW5nL2FwaS9yZW1vdGVfc29ja2V0L3JlbW90ZV9zb2NrZXRfc2VydmljZS5wcm90bwobYXBwaG9zdGluZy5HZXRQZWVyTmFtZVJlcGx5ExoHcGVlcl9pcCACKAIwCzgBShZhcHBob3N0aW5nLkFkZHJlc3NQb3J0FMIBI2FwcGhvc3RpbmcuUmVtb3RlU29ja2V0U2VydmljZUVycm9y"))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class SocketOption(ProtocolBuffer.ProtocolMessage):


  SOCKET_SOL_IP =    0
  SOCKET_SOL_SOCKET =    1
  SOCKET_SOL_TCP =    6
  SOCKET_SOL_UDP =   17

  _SocketOptionLevel_NAMES = {
    0: "SOCKET_SOL_IP",
    1: "SOCKET_SOL_SOCKET",
    6: "SOCKET_SOL_TCP",
    17: "SOCKET_SOL_UDP",
  }

  def SocketOptionLevel_Name(cls, x): return cls._SocketOptionLevel_NAMES.get(x, "")
  SocketOptionLevel_Name = classmethod(SocketOptionLevel_Name)



  SOCKET_SO_DEBUG =    1
  SOCKET_SO_REUSEADDR =    2
  SOCKET_SO_TYPE =    3
  SOCKET_SO_ERROR =    4
  SOCKET_SO_DONTROUTE =    5
  SOCKET_SO_BROADCAST =    6
  SOCKET_SO_SNDBUF =    7
  SOCKET_SO_RCVBUF =    8
  SOCKET_SO_KEEPALIVE =    9
  SOCKET_IP_TOS =    1
  SOCKET_IP_TTL =    2
  SOCKET_IP_HDRINCL =    3
  SOCKET_IP_OPTIONS =    4
  SOCKET_TCP_NODELAY =    1
  SOCKET_TCP_MAXSEG =    2
  SOCKET_TCP_CORK =    3
  SOCKET_TCP_KEEPIDLE =    4
  SOCKET_TCP_KEEPINTVL =    5
  SOCKET_TCP_KEEPCNT =    6
  SOCKET_TCP_SYNCNT =    7
  SOCKET_TCP_LINGER2 =    8
  SOCKET_TCP_DEFER_ACCEPT =    9
  SOCKET_TCP_WINDOW_CLAMP =   10
  SOCKET_TCP_INFO =   11
  SOCKET_TCP_QUICKACK =   12

  _SocketOptionName_NAMES = {
    1: "SOCKET_SO_DEBUG",
    2: "SOCKET_SO_REUSEADDR",
    3: "SOCKET_SO_TYPE",
    4: "SOCKET_SO_ERROR",
    5: "SOCKET_SO_DONTROUTE",
    6: "SOCKET_SO_BROADCAST",
    7: "SOCKET_SO_SNDBUF",
    8: "SOCKET_SO_RCVBUF",
    9: "SOCKET_SO_KEEPALIVE",
    1: "SOCKET_IP_TOS",
    2: "SOCKET_IP_TTL",
    3: "SOCKET_IP_HDRINCL",
    4: "SOCKET_IP_OPTIONS",
    1: "SOCKET_TCP_NODELAY",
    2: "SOCKET_TCP_MAXSEG",
    3: "SOCKET_TCP_CORK",
    4: "SOCKET_TCP_KEEPIDLE",
    5: "SOCKET_TCP_KEEPINTVL",
    6: "SOCKET_TCP_KEEPCNT",
    7: "SOCKET_TCP_SYNCNT",
    8: "SOCKET_TCP_LINGER2",
    9: "SOCKET_TCP_DEFER_ACCEPT",
    10: "SOCKET_TCP_WINDOW_CLAMP",
    11: "SOCKET_TCP_INFO",
    12: "SOCKET_TCP_QUICKACK",
  }

  def SocketOptionName_Name(cls, x): return cls._SocketOptionName_NAMES.get(x, "")
  SocketOptionName_Name = classmethod(SocketOptionName_Name)

  has_level_ = 0
  level_ = 0
  has_option_ = 0
  option_ = 0
  has_value_ = 0
  value_ = ""

  def __init__(self, contents=None):
    if contents is not None: self.MergeFromString(contents)

  def level(self): return self.level_

  def set_level(self, x):
    self.has_level_ = 1
    self.level_ = x

  def clear_level(self):
    if self.has_level_:
      self.has_level_ = 0
      self.level_ = 0

  def has_level(self): return self.has_level_

  def option(self): return self.option_

  def set_option(self, x):
    self.has_option_ = 1
    self.option_ = x

  def clear_option(self):
    if self.has_option_:
      self.has_option_ = 0
      self.option_ = 0

  def has_option(self): return self.has_option_

  def value(self): return self.value_

  def set_value(self, x):
    self.has_value_ = 1
    self.value_ = x

  def clear_value(self):
    if self.has_value_:
      self.has_value_ = 0
      self.value_ = ""

  def has_value(self): return self.has_value_


  def MergeFrom(self, x):
    assert x is not self
    if (x.has_level()): self.set_level(x.level())
    if (x.has_option()): self.set_option(x.option())
    if (x.has_value()): self.set_value(x.value())

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.SocketOption', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.SocketOption')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.SocketOption')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.SocketOption', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.SocketOption', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.SocketOption', s)


  def Equals(self, x):
    if x is self: return 1
    if self.has_level_ != x.has_level_: return 0
    if self.has_level_ and self.level_ != x.level_: return 0
    if self.has_option_ != x.has_option_: return 0
    if self.has_option_ and self.option_ != x.option_: return 0
    if self.has_value_ != x.has_value_: return 0
    if self.has_value_ and self.value_ != x.value_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    if (not self.has_level_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: level not set.')
    if (not self.has_option_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: option not set.')
    if (not self.has_value_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: value not set.')
    return initialized

  def ByteSize(self):
    n = 0
    n += self.lengthVarInt64(self.level_)
    n += self.lengthVarInt64(self.option_)
    n += self.lengthString(len(self.value_))
    return n + 3

  def ByteSizePartial(self):
    n = 0
    if (self.has_level_):
      n += 1
      n += self.lengthVarInt64(self.level_)
    if (self.has_option_):
      n += 1
      n += self.lengthVarInt64(self.option_)
    if (self.has_value_):
      n += 1
      n += self.lengthString(len(self.value_))
    return n

  def Clear(self):
    self.clear_level()
    self.clear_option()
    self.clear_value()

  def OutputUnchecked(self, out):
    out.putVarInt32(8)
    out.putVarInt32(self.level_)
    out.putVarInt32(16)
    out.putVarInt32(self.option_)
    out.putVarInt32(26)
    out.putPrefixedString(self.value_)

  def OutputPartial(self, out):
    if (self.has_level_):
      out.putVarInt32(8)
      out.putVarInt32(self.level_)
    if (self.has_option_):
      out.putVarInt32(16)
      out.putVarInt32(self.option_)
    if (self.has_value_):
      out.putVarInt32(26)
      out.putPrefixedString(self.value_)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 8:
        self.set_level(d.getVarInt32())
        continue
      if tt == 16:
        self.set_option(d.getVarInt32())
        continue
      if tt == 26:
        self.set_value(d.getPrefixedString())
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    if self.has_level_: res+=prefix+("level: %s\n" % self.DebugFormatInt32(self.level_))
    if self.has_option_: res+=prefix+("option: %s\n" % self.DebugFormatInt32(self.option_))
    if self.has_value_: res+=prefix+("value: %s\n" % self.DebugFormatString(self.value_))
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  klevel = 1
  koption = 2
  kvalue = 3

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "level",
    2: "option",
    3: "value",
  }, 3)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.NUMERIC,
    2: ProtocolBuffer.Encoder.NUMERIC,
    3: ProtocolBuffer.Encoder.STRING,
  }, 3, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("WjhhcHBob3N0aW5nL2FwaS9yZW1vdGVfc29ja2V0L3JlbW90ZV9zb2NrZXRfc2VydmljZS5wcm90bwoXYXBwaG9zdGluZy5Tb2NrZXRPcHRpb24TGgVsZXZlbCABKAAwBTgCaAAUExoGb3B0aW9uIAIoADAFOAJoARQTGgV2YWx1ZSADKAIwCTgCFHN6EVNvY2tldE9wdGlvbkxldmVsiwGSAQ1TT0NLRVRfU09MX0lQmAEAjAGLAZIBEVNPQ0tFVF9TT0xfU09DS0VUmAEBjAGLAZIBDlNPQ0tFVF9TT0xfVENQmAEGjAGLAZIBDlNPQ0tFVF9TT0xfVURQmAERjAF0c3oQU29ja2V0T3B0aW9uTmFtZYsBkgEPU09DS0VUX1NPX0RFQlVHmAEBjAGLAZIBE1NPQ0tFVF9TT19SRVVTRUFERFKYAQKMAYsBkgEOU09DS0VUX1NPX1RZUEWYAQOMAYsBkgEPU09DS0VUX1NPX0VSUk9SmAEEjAGLAZIBE1NPQ0tFVF9TT19ET05UUk9VVEWYAQWMAYsBkgETU09DS0VUX1NPX0JST0FEQ0FTVJgBBowBiwGSARBTT0NLRVRfU09fU05EQlVGmAEHjAGLAZIBEFNPQ0tFVF9TT19SQ1ZCVUaYAQiMAYsBkgETU09DS0VUX1NPX0tFRVBBTElWRZgBCYwBiwGSAQ1TT0NLRVRfSVBfVE9TmAEBjAGLAZIBDVNPQ0tFVF9JUF9UVEyYAQKMAYsBkgERU09DS0VUX0lQX0hEUklOQ0yYAQOMAYsBkgERU09DS0VUX0lQX09QVElPTlOYAQSMAYsBkgESU09DS0VUX1RDUF9OT0RFTEFZmAEBjAGLAZIBEVNPQ0tFVF9UQ1BfTUFYU0VHmAECjAGLAZIBD1NPQ0tFVF9UQ1BfQ09SS5gBA4wBiwGSARNTT0NLRVRfVENQX0tFRVBJRExFmAEEjAGLAZIBFFNPQ0tFVF9UQ1BfS0VFUElOVFZMmAEFjAGLAZIBElNPQ0tFVF9UQ1BfS0VFUENOVJgBBowBiwGSARFTT0NLRVRfVENQX1NZTkNOVJgBB4wBiwGSARJTT0NLRVRfVENQX0xJTkdFUjKYAQiMAYsBkgEXU09DS0VUX1RDUF9ERUZFUl9BQ0NFUFSYAQmMAYsBkgEXU09DS0VUX1RDUF9XSU5ET1dfQ0xBTVCYAQqMAYsBkgEPU09DS0VUX1RDUF9JTkZPmAELjAGLAZIBE1NPQ0tFVF9UQ1BfUVVJQ0tBQ0uYAQyMAXTCASNhcHBob3N0aW5nLlJlbW90ZVNvY2tldFNlcnZpY2VFcnJvcg=="))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class SetSocketOptionsRequest(ProtocolBuffer.ProtocolMessage):
  has_socket_descriptor_ = 0
  socket_descriptor_ = ""

  def __init__(self, contents=None):
    self.options_ = []
    if contents is not None: self.MergeFromString(contents)

  def socket_descriptor(self): return self.socket_descriptor_

  def set_socket_descriptor(self, x):
    self.has_socket_descriptor_ = 1
    self.socket_descriptor_ = x

  def clear_socket_descriptor(self):
    if self.has_socket_descriptor_:
      self.has_socket_descriptor_ = 0
      self.socket_descriptor_ = ""

  def has_socket_descriptor(self): return self.has_socket_descriptor_

  def options_size(self): return len(self.options_)
  def options_list(self): return self.options_

  def options(self, i):
    return self.options_[i]

  def mutable_options(self, i):
    return self.options_[i]

  def add_options(self):
    x = SocketOption()
    self.options_.append(x)
    return x

  def clear_options(self):
    self.options_ = []

  def MergeFrom(self, x):
    assert x is not self
    if (x.has_socket_descriptor()): self.set_socket_descriptor(x.socket_descriptor())
    for i in xrange(x.options_size()): self.add_options().CopyFrom(x.options(i))

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.SetSocketOptionsRequest', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.SetSocketOptionsRequest')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.SetSocketOptionsRequest')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.SetSocketOptionsRequest', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.SetSocketOptionsRequest', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.SetSocketOptionsRequest', s)


  def Equals(self, x):
    if x is self: return 1
    if self.has_socket_descriptor_ != x.has_socket_descriptor_: return 0
    if self.has_socket_descriptor_ and self.socket_descriptor_ != x.socket_descriptor_: return 0
    if len(self.options_) != len(x.options_): return 0
    for e1, e2 in zip(self.options_, x.options_):
      if e1 != e2: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    if (not self.has_socket_descriptor_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: socket_descriptor not set.')
    for p in self.options_:
      if not p.IsInitialized(debug_strs): initialized=0
    return initialized

  def ByteSize(self):
    n = 0
    n += self.lengthString(len(self.socket_descriptor_))
    n += 1 * len(self.options_)
    for i in xrange(len(self.options_)): n += self.lengthString(self.options_[i].ByteSize())
    return n + 1

  def ByteSizePartial(self):
    n = 0
    if (self.has_socket_descriptor_):
      n += 1
      n += self.lengthString(len(self.socket_descriptor_))
    n += 1 * len(self.options_)
    for i in xrange(len(self.options_)): n += self.lengthString(self.options_[i].ByteSizePartial())
    return n

  def Clear(self):
    self.clear_socket_descriptor()
    self.clear_options()

  def OutputUnchecked(self, out):
    out.putVarInt32(10)
    out.putPrefixedString(self.socket_descriptor_)
    for i in xrange(len(self.options_)):
      out.putVarInt32(18)
      out.putVarInt32(self.options_[i].ByteSize())
      self.options_[i].OutputUnchecked(out)

  def OutputPartial(self, out):
    if (self.has_socket_descriptor_):
      out.putVarInt32(10)
      out.putPrefixedString(self.socket_descriptor_)
    for i in xrange(len(self.options_)):
      out.putVarInt32(18)
      out.putVarInt32(self.options_[i].ByteSizePartial())
      self.options_[i].OutputPartial(out)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 10:
        self.set_socket_descriptor(d.getPrefixedString())
        continue
      if tt == 18:
        length = d.getVarInt32()
        tmp = ProtocolBuffer.Decoder(d.buffer(), d.pos(), d.pos() + length)
        d.skip(length)
        self.add_options().TryMerge(tmp)
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    if self.has_socket_descriptor_: res+=prefix+("socket_descriptor: %s\n" % self.DebugFormatString(self.socket_descriptor_))
    cnt=0
    for e in self.options_:
      elm=""
      if printElemNumber: elm="(%d)" % cnt
      res+=prefix+("options%s <\n" % elm)
      res+=e.__str__(prefix + "  ", printElemNumber)
      res+=prefix+">\n"
      cnt+=1
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  ksocket_descriptor = 1
  koptions = 2

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "socket_descriptor",
    2: "options",
  }, 2)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.STRING,
    2: ProtocolBuffer.Encoder.STRING,
  }, 2, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("WjhhcHBob3N0aW5nL2FwaS9yZW1vdGVfc29ja2V0L3JlbW90ZV9zb2NrZXRfc2VydmljZS5wcm90bwoiYXBwaG9zdGluZy5TZXRTb2NrZXRPcHRpb25zUmVxdWVzdBMaEXNvY2tldF9kZXNjcmlwdG9yIAEoAjAJOAIUExoHb3B0aW9ucyACKAIwCzgDShdhcHBob3N0aW5nLlNvY2tldE9wdGlvbhTCASNhcHBob3N0aW5nLlJlbW90ZVNvY2tldFNlcnZpY2VFcnJvcg=="))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class SetSocketOptionsReply(ProtocolBuffer.ProtocolMessage):

  def __init__(self, contents=None):
    pass
    if contents is not None: self.MergeFromString(contents)


  def MergeFrom(self, x):
    assert x is not self

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.SetSocketOptionsReply', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.SetSocketOptionsReply')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.SetSocketOptionsReply')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.SetSocketOptionsReply', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.SetSocketOptionsReply', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.SetSocketOptionsReply', s)


  def Equals(self, x):
    if x is self: return 1
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    return initialized

  def ByteSize(self):
    n = 0
    return n

  def ByteSizePartial(self):
    n = 0
    return n

  def Clear(self):
    pass

  def OutputUnchecked(self, out):
    pass

  def OutputPartial(self, out):
    pass

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])


  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
  }, 0)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
  }, 0, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("WjhhcHBob3N0aW5nL2FwaS9yZW1vdGVfc29ja2V0L3JlbW90ZV9zb2NrZXRfc2VydmljZS5wcm90bwogYXBwaG9zdGluZy5TZXRTb2NrZXRPcHRpb25zUmVwbHnCASNhcHBob3N0aW5nLlJlbW90ZVNvY2tldFNlcnZpY2VFcnJvcg=="))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class GetSocketOptionsRequest(ProtocolBuffer.ProtocolMessage):
  has_socket_descriptor_ = 0
  socket_descriptor_ = ""

  def __init__(self, contents=None):
    self.options_ = []
    if contents is not None: self.MergeFromString(contents)

  def socket_descriptor(self): return self.socket_descriptor_

  def set_socket_descriptor(self, x):
    self.has_socket_descriptor_ = 1
    self.socket_descriptor_ = x

  def clear_socket_descriptor(self):
    if self.has_socket_descriptor_:
      self.has_socket_descriptor_ = 0
      self.socket_descriptor_ = ""

  def has_socket_descriptor(self): return self.has_socket_descriptor_

  def options_size(self): return len(self.options_)
  def options_list(self): return self.options_

  def options(self, i):
    return self.options_[i]

  def mutable_options(self, i):
    return self.options_[i]

  def add_options(self):
    x = SocketOption()
    self.options_.append(x)
    return x

  def clear_options(self):
    self.options_ = []

  def MergeFrom(self, x):
    assert x is not self
    if (x.has_socket_descriptor()): self.set_socket_descriptor(x.socket_descriptor())
    for i in xrange(x.options_size()): self.add_options().CopyFrom(x.options(i))

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.GetSocketOptionsRequest', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.GetSocketOptionsRequest')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.GetSocketOptionsRequest')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.GetSocketOptionsRequest', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.GetSocketOptionsRequest', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.GetSocketOptionsRequest', s)


  def Equals(self, x):
    if x is self: return 1
    if self.has_socket_descriptor_ != x.has_socket_descriptor_: return 0
    if self.has_socket_descriptor_ and self.socket_descriptor_ != x.socket_descriptor_: return 0
    if len(self.options_) != len(x.options_): return 0
    for e1, e2 in zip(self.options_, x.options_):
      if e1 != e2: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    if (not self.has_socket_descriptor_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: socket_descriptor not set.')
    for p in self.options_:
      if not p.IsInitialized(debug_strs): initialized=0
    return initialized

  def ByteSize(self):
    n = 0
    n += self.lengthString(len(self.socket_descriptor_))
    n += 1 * len(self.options_)
    for i in xrange(len(self.options_)): n += self.lengthString(self.options_[i].ByteSize())
    return n + 1

  def ByteSizePartial(self):
    n = 0
    if (self.has_socket_descriptor_):
      n += 1
      n += self.lengthString(len(self.socket_descriptor_))
    n += 1 * len(self.options_)
    for i in xrange(len(self.options_)): n += self.lengthString(self.options_[i].ByteSizePartial())
    return n

  def Clear(self):
    self.clear_socket_descriptor()
    self.clear_options()

  def OutputUnchecked(self, out):
    out.putVarInt32(10)
    out.putPrefixedString(self.socket_descriptor_)
    for i in xrange(len(self.options_)):
      out.putVarInt32(18)
      out.putVarInt32(self.options_[i].ByteSize())
      self.options_[i].OutputUnchecked(out)

  def OutputPartial(self, out):
    if (self.has_socket_descriptor_):
      out.putVarInt32(10)
      out.putPrefixedString(self.socket_descriptor_)
    for i in xrange(len(self.options_)):
      out.putVarInt32(18)
      out.putVarInt32(self.options_[i].ByteSizePartial())
      self.options_[i].OutputPartial(out)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 10:
        self.set_socket_descriptor(d.getPrefixedString())
        continue
      if tt == 18:
        length = d.getVarInt32()
        tmp = ProtocolBuffer.Decoder(d.buffer(), d.pos(), d.pos() + length)
        d.skip(length)
        self.add_options().TryMerge(tmp)
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    if self.has_socket_descriptor_: res+=prefix+("socket_descriptor: %s\n" % self.DebugFormatString(self.socket_descriptor_))
    cnt=0
    for e in self.options_:
      elm=""
      if printElemNumber: elm="(%d)" % cnt
      res+=prefix+("options%s <\n" % elm)
      res+=e.__str__(prefix + "  ", printElemNumber)
      res+=prefix+">\n"
      cnt+=1
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  ksocket_descriptor = 1
  koptions = 2

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "socket_descriptor",
    2: "options",
  }, 2)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.STRING,
    2: ProtocolBuffer.Encoder.STRING,
  }, 2, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("WjhhcHBob3N0aW5nL2FwaS9yZW1vdGVfc29ja2V0L3JlbW90ZV9zb2NrZXRfc2VydmljZS5wcm90bwoiYXBwaG9zdGluZy5HZXRTb2NrZXRPcHRpb25zUmVxdWVzdBMaEXNvY2tldF9kZXNjcmlwdG9yIAEoAjAJOAIUExoHb3B0aW9ucyACKAIwCzgDShdhcHBob3N0aW5nLlNvY2tldE9wdGlvbhTCASNhcHBob3N0aW5nLlJlbW90ZVNvY2tldFNlcnZpY2VFcnJvcg=="))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class GetSocketOptionsReply(ProtocolBuffer.ProtocolMessage):

  def __init__(self, contents=None):
    self.options_ = []
    if contents is not None: self.MergeFromString(contents)

  def options_size(self): return len(self.options_)
  def options_list(self): return self.options_

  def options(self, i):
    return self.options_[i]

  def mutable_options(self, i):
    return self.options_[i]

  def add_options(self):
    x = SocketOption()
    self.options_.append(x)
    return x

  def clear_options(self):
    self.options_ = []

  def MergeFrom(self, x):
    assert x is not self
    for i in xrange(x.options_size()): self.add_options().CopyFrom(x.options(i))

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.GetSocketOptionsReply', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.GetSocketOptionsReply')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.GetSocketOptionsReply')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.GetSocketOptionsReply', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.GetSocketOptionsReply', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.GetSocketOptionsReply', s)


  def Equals(self, x):
    if x is self: return 1
    if len(self.options_) != len(x.options_): return 0
    for e1, e2 in zip(self.options_, x.options_):
      if e1 != e2: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    for p in self.options_:
      if not p.IsInitialized(debug_strs): initialized=0
    return initialized

  def ByteSize(self):
    n = 0
    n += 1 * len(self.options_)
    for i in xrange(len(self.options_)): n += self.lengthString(self.options_[i].ByteSize())
    return n

  def ByteSizePartial(self):
    n = 0
    n += 1 * len(self.options_)
    for i in xrange(len(self.options_)): n += self.lengthString(self.options_[i].ByteSizePartial())
    return n

  def Clear(self):
    self.clear_options()

  def OutputUnchecked(self, out):
    for i in xrange(len(self.options_)):
      out.putVarInt32(18)
      out.putVarInt32(self.options_[i].ByteSize())
      self.options_[i].OutputUnchecked(out)

  def OutputPartial(self, out):
    for i in xrange(len(self.options_)):
      out.putVarInt32(18)
      out.putVarInt32(self.options_[i].ByteSizePartial())
      self.options_[i].OutputPartial(out)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 18:
        length = d.getVarInt32()
        tmp = ProtocolBuffer.Decoder(d.buffer(), d.pos(), d.pos() + length)
        d.skip(length)
        self.add_options().TryMerge(tmp)
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    cnt=0
    for e in self.options_:
      elm=""
      if printElemNumber: elm="(%d)" % cnt
      res+=prefix+("options%s <\n" % elm)
      res+=e.__str__(prefix + "  ", printElemNumber)
      res+=prefix+">\n"
      cnt+=1
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  koptions = 2

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    2: "options",
  }, 2)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    2: ProtocolBuffer.Encoder.STRING,
  }, 2, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("WjhhcHBob3N0aW5nL2FwaS9yZW1vdGVfc29ja2V0L3JlbW90ZV9zb2NrZXRfc2VydmljZS5wcm90bwogYXBwaG9zdGluZy5HZXRTb2NrZXRPcHRpb25zUmVwbHkTGgdvcHRpb25zIAIoAjALOANKF2FwcGhvc3RpbmcuU29ja2V0T3B0aW9uFMIBI2FwcGhvc3RpbmcuUmVtb3RlU29ja2V0U2VydmljZUVycm9y"))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class ConnectRequest(ProtocolBuffer.ProtocolMessage):
  has_socket_descriptor_ = 0
  socket_descriptor_ = ""
  has_remote_ip_ = 0
  has_timeout_seconds_ = 0
  timeout_seconds_ = -1.0

  def __init__(self, contents=None):
    self.remote_ip_ = AddressPort()
    if contents is not None: self.MergeFromString(contents)

  def socket_descriptor(self): return self.socket_descriptor_

  def set_socket_descriptor(self, x):
    self.has_socket_descriptor_ = 1
    self.socket_descriptor_ = x

  def clear_socket_descriptor(self):
    if self.has_socket_descriptor_:
      self.has_socket_descriptor_ = 0
      self.socket_descriptor_ = ""

  def has_socket_descriptor(self): return self.has_socket_descriptor_

  def remote_ip(self): return self.remote_ip_

  def mutable_remote_ip(self): self.has_remote_ip_ = 1; return self.remote_ip_

  def clear_remote_ip(self):self.has_remote_ip_ = 0; self.remote_ip_.Clear()

  def has_remote_ip(self): return self.has_remote_ip_

  def timeout_seconds(self): return self.timeout_seconds_

  def set_timeout_seconds(self, x):
    self.has_timeout_seconds_ = 1
    self.timeout_seconds_ = x

  def clear_timeout_seconds(self):
    if self.has_timeout_seconds_:
      self.has_timeout_seconds_ = 0
      self.timeout_seconds_ = -1.0

  def has_timeout_seconds(self): return self.has_timeout_seconds_


  def MergeFrom(self, x):
    assert x is not self
    if (x.has_socket_descriptor()): self.set_socket_descriptor(x.socket_descriptor())
    if (x.has_remote_ip()): self.mutable_remote_ip().MergeFrom(x.remote_ip())
    if (x.has_timeout_seconds()): self.set_timeout_seconds(x.timeout_seconds())

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.ConnectRequest', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.ConnectRequest')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.ConnectRequest')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.ConnectRequest', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.ConnectRequest', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.ConnectRequest', s)


  def Equals(self, x):
    if x is self: return 1
    if self.has_socket_descriptor_ != x.has_socket_descriptor_: return 0
    if self.has_socket_descriptor_ and self.socket_descriptor_ != x.socket_descriptor_: return 0
    if self.has_remote_ip_ != x.has_remote_ip_: return 0
    if self.has_remote_ip_ and self.remote_ip_ != x.remote_ip_: return 0
    if self.has_timeout_seconds_ != x.has_timeout_seconds_: return 0
    if self.has_timeout_seconds_ and self.timeout_seconds_ != x.timeout_seconds_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    if (not self.has_socket_descriptor_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: socket_descriptor not set.')
    if (not self.has_remote_ip_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: remote_ip not set.')
    elif not self.remote_ip_.IsInitialized(debug_strs): initialized = 0
    return initialized

  def ByteSize(self):
    n = 0
    n += self.lengthString(len(self.socket_descriptor_))
    n += self.lengthString(self.remote_ip_.ByteSize())
    if (self.has_timeout_seconds_): n += 9
    return n + 2

  def ByteSizePartial(self):
    n = 0
    if (self.has_socket_descriptor_):
      n += 1
      n += self.lengthString(len(self.socket_descriptor_))
    if (self.has_remote_ip_):
      n += 1
      n += self.lengthString(self.remote_ip_.ByteSizePartial())
    if (self.has_timeout_seconds_): n += 9
    return n

  def Clear(self):
    self.clear_socket_descriptor()
    self.clear_remote_ip()
    self.clear_timeout_seconds()

  def OutputUnchecked(self, out):
    out.putVarInt32(10)
    out.putPrefixedString(self.socket_descriptor_)
    out.putVarInt32(18)
    out.putVarInt32(self.remote_ip_.ByteSize())
    self.remote_ip_.OutputUnchecked(out)
    if (self.has_timeout_seconds_):
      out.putVarInt32(25)
      out.putDouble(self.timeout_seconds_)

  def OutputPartial(self, out):
    if (self.has_socket_descriptor_):
      out.putVarInt32(10)
      out.putPrefixedString(self.socket_descriptor_)
    if (self.has_remote_ip_):
      out.putVarInt32(18)
      out.putVarInt32(self.remote_ip_.ByteSizePartial())
      self.remote_ip_.OutputPartial(out)
    if (self.has_timeout_seconds_):
      out.putVarInt32(25)
      out.putDouble(self.timeout_seconds_)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 10:
        self.set_socket_descriptor(d.getPrefixedString())
        continue
      if tt == 18:
        length = d.getVarInt32()
        tmp = ProtocolBuffer.Decoder(d.buffer(), d.pos(), d.pos() + length)
        d.skip(length)
        self.mutable_remote_ip().TryMerge(tmp)
        continue
      if tt == 25:
        self.set_timeout_seconds(d.getDouble())
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    if self.has_socket_descriptor_: res+=prefix+("socket_descriptor: %s\n" % self.DebugFormatString(self.socket_descriptor_))
    if self.has_remote_ip_:
      res+=prefix+"remote_ip <\n"
      res+=self.remote_ip_.__str__(prefix + "  ", printElemNumber)
      res+=prefix+">\n"
    if self.has_timeout_seconds_: res+=prefix+("timeout_seconds: %s\n" % self.DebugFormat(self.timeout_seconds_))
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  ksocket_descriptor = 1
  kremote_ip = 2
  ktimeout_seconds = 3

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "socket_descriptor",
    2: "remote_ip",
    3: "timeout_seconds",
  }, 3)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.STRING,
    2: ProtocolBuffer.Encoder.STRING,
    3: ProtocolBuffer.Encoder.DOUBLE,
  }, 3, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("WjhhcHBob3N0aW5nL2FwaS9yZW1vdGVfc29ja2V0L3JlbW90ZV9zb2NrZXRfc2VydmljZS5wcm90bwoZYXBwaG9zdGluZy5Db25uZWN0UmVxdWVzdBMaEXNvY2tldF9kZXNjcmlwdG9yIAEoAjAJOAIUExoJcmVtb3RlX2lwIAIoAjALOAJKFmFwcGhvc3RpbmcuQWRkcmVzc1BvcnQUExoPdGltZW91dF9zZWNvbmRzIAMoATABOAFCBC0xLjCjAaoBB2RlZmF1bHSyAQQtMS4wpAEUwgEjYXBwaG9zdGluZy5SZW1vdGVTb2NrZXRTZXJ2aWNlRXJyb3I="))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class ConnectReply(ProtocolBuffer.ProtocolMessage):
  has_ssl_session_ = 0
  ssl_session_ = None

  def __init__(self, contents=None):
    self.lazy_init_lock_ = thread.allocate_lock()
    if contents is not None: self.MergeFromString(contents)

  def ssl_session(self):
    if self.ssl_session_ is None:
      self.lazy_init_lock_.acquire()
      try:
        if self.ssl_session_ is None: self.ssl_session_ = SSLSession()
      finally:
        self.lazy_init_lock_.release()
    return self.ssl_session_

  def mutable_ssl_session(self): self.has_ssl_session_ = 1; return self.ssl_session()

  def clear_ssl_session(self):

    if self.has_ssl_session_:
      self.has_ssl_session_ = 0;
      if self.ssl_session_ is not None: self.ssl_session_.Clear()

  def has_ssl_session(self): return self.has_ssl_session_


  def MergeFrom(self, x):
    assert x is not self
    if (x.has_ssl_session()): self.mutable_ssl_session().MergeFrom(x.ssl_session())

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.ConnectReply', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.ConnectReply')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.ConnectReply')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.ConnectReply', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.ConnectReply', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.ConnectReply', s)


  def Equals(self, x):
    if x is self: return 1
    if self.has_ssl_session_ != x.has_ssl_session_: return 0
    if self.has_ssl_session_ and self.ssl_session_ != x.ssl_session_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    if (self.has_ssl_session_ and not self.ssl_session_.IsInitialized(debug_strs)): initialized = 0
    return initialized

  def ByteSize(self):
    n = 0
    if (self.has_ssl_session_): n += 1 + self.lengthString(self.ssl_session_.ByteSize())
    return n

  def ByteSizePartial(self):
    n = 0
    if (self.has_ssl_session_): n += 1 + self.lengthString(self.ssl_session_.ByteSizePartial())
    return n

  def Clear(self):
    self.clear_ssl_session()

  def OutputUnchecked(self, out):
    if (self.has_ssl_session_):
      out.putVarInt32(10)
      out.putVarInt32(self.ssl_session_.ByteSize())
      self.ssl_session_.OutputUnchecked(out)

  def OutputPartial(self, out):
    if (self.has_ssl_session_):
      out.putVarInt32(10)
      out.putVarInt32(self.ssl_session_.ByteSizePartial())
      self.ssl_session_.OutputPartial(out)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 10:
        length = d.getVarInt32()
        tmp = ProtocolBuffer.Decoder(d.buffer(), d.pos(), d.pos() + length)
        d.skip(length)
        self.mutable_ssl_session().TryMerge(tmp)
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    if self.has_ssl_session_:
      res+=prefix+"ssl_session <\n"
      res+=self.ssl_session_.__str__(prefix + "  ", printElemNumber)
      res+=prefix+">\n"
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  kssl_session = 1

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "ssl_session",
  }, 1)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.STRING,
  }, 1, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("WjhhcHBob3N0aW5nL2FwaS9yZW1vdGVfc29ja2V0L3JlbW90ZV9zb2NrZXRfc2VydmljZS5wcm90bwoXYXBwaG9zdGluZy5Db25uZWN0UmVwbHkTGgtzc2xfc2Vzc2lvbiABKAIwCzgBShVhcHBob3N0aW5nLlNTTFNlc3Npb24UwgEjYXBwaG9zdGluZy5SZW1vdGVTb2NrZXRTZXJ2aWNlRXJyb3I="))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class ListenRequest(ProtocolBuffer.ProtocolMessage):
  has_socket_descriptor_ = 0
  socket_descriptor_ = ""
  has_backlog_ = 0
  backlog_ = 0

  def __init__(self, contents=None):
    if contents is not None: self.MergeFromString(contents)

  def socket_descriptor(self): return self.socket_descriptor_

  def set_socket_descriptor(self, x):
    self.has_socket_descriptor_ = 1
    self.socket_descriptor_ = x

  def clear_socket_descriptor(self):
    if self.has_socket_descriptor_:
      self.has_socket_descriptor_ = 0
      self.socket_descriptor_ = ""

  def has_socket_descriptor(self): return self.has_socket_descriptor_

  def backlog(self): return self.backlog_

  def set_backlog(self, x):
    self.has_backlog_ = 1
    self.backlog_ = x

  def clear_backlog(self):
    if self.has_backlog_:
      self.has_backlog_ = 0
      self.backlog_ = 0

  def has_backlog(self): return self.has_backlog_


  def MergeFrom(self, x):
    assert x is not self
    if (x.has_socket_descriptor()): self.set_socket_descriptor(x.socket_descriptor())
    if (x.has_backlog()): self.set_backlog(x.backlog())

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.ListenRequest', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.ListenRequest')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.ListenRequest')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.ListenRequest', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.ListenRequest', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.ListenRequest', s)


  def Equals(self, x):
    if x is self: return 1
    if self.has_socket_descriptor_ != x.has_socket_descriptor_: return 0
    if self.has_socket_descriptor_ and self.socket_descriptor_ != x.socket_descriptor_: return 0
    if self.has_backlog_ != x.has_backlog_: return 0
    if self.has_backlog_ and self.backlog_ != x.backlog_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    if (not self.has_socket_descriptor_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: socket_descriptor not set.')
    if (not self.has_backlog_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: backlog not set.')
    return initialized

  def ByteSize(self):
    n = 0
    n += self.lengthString(len(self.socket_descriptor_))
    n += self.lengthVarInt64(self.backlog_)
    return n + 2

  def ByteSizePartial(self):
    n = 0
    if (self.has_socket_descriptor_):
      n += 1
      n += self.lengthString(len(self.socket_descriptor_))
    if (self.has_backlog_):
      n += 1
      n += self.lengthVarInt64(self.backlog_)
    return n

  def Clear(self):
    self.clear_socket_descriptor()
    self.clear_backlog()

  def OutputUnchecked(self, out):
    out.putVarInt32(10)
    out.putPrefixedString(self.socket_descriptor_)
    out.putVarInt32(16)
    out.putVarInt32(self.backlog_)

  def OutputPartial(self, out):
    if (self.has_socket_descriptor_):
      out.putVarInt32(10)
      out.putPrefixedString(self.socket_descriptor_)
    if (self.has_backlog_):
      out.putVarInt32(16)
      out.putVarInt32(self.backlog_)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 10:
        self.set_socket_descriptor(d.getPrefixedString())
        continue
      if tt == 16:
        self.set_backlog(d.getVarInt32())
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    if self.has_socket_descriptor_: res+=prefix+("socket_descriptor: %s\n" % self.DebugFormatString(self.socket_descriptor_))
    if self.has_backlog_: res+=prefix+("backlog: %s\n" % self.DebugFormatInt32(self.backlog_))
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  ksocket_descriptor = 1
  kbacklog = 2

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "socket_descriptor",
    2: "backlog",
  }, 2)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.STRING,
    2: ProtocolBuffer.Encoder.NUMERIC,
  }, 2, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("WjhhcHBob3N0aW5nL2FwaS9yZW1vdGVfc29ja2V0L3JlbW90ZV9zb2NrZXRfc2VydmljZS5wcm90bwoYYXBwaG9zdGluZy5MaXN0ZW5SZXF1ZXN0ExoRc29ja2V0X2Rlc2NyaXB0b3IgASgCMAk4AhQTGgdiYWNrbG9nIAIoADAFOAIUwgEjYXBwaG9zdGluZy5SZW1vdGVTb2NrZXRTZXJ2aWNlRXJyb3I="))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class ListenReply(ProtocolBuffer.ProtocolMessage):

  def __init__(self, contents=None):
    pass
    if contents is not None: self.MergeFromString(contents)


  def MergeFrom(self, x):
    assert x is not self

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.ListenReply', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.ListenReply')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.ListenReply')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.ListenReply', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.ListenReply', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.ListenReply', s)


  def Equals(self, x):
    if x is self: return 1
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    return initialized

  def ByteSize(self):
    n = 0
    return n

  def ByteSizePartial(self):
    n = 0
    return n

  def Clear(self):
    pass

  def OutputUnchecked(self, out):
    pass

  def OutputPartial(self, out):
    pass

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])


  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
  }, 0)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
  }, 0, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("WjhhcHBob3N0aW5nL2FwaS9yZW1vdGVfc29ja2V0L3JlbW90ZV9zb2NrZXRfc2VydmljZS5wcm90bwoWYXBwaG9zdGluZy5MaXN0ZW5SZXBsecIBI2FwcGhvc3RpbmcuUmVtb3RlU29ja2V0U2VydmljZUVycm9y"))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class AcceptRequest(ProtocolBuffer.ProtocolMessage):
  has_socket_descriptor_ = 0
  socket_descriptor_ = ""
  has_timeout_seconds_ = 0
  timeout_seconds_ = -1.0

  def __init__(self, contents=None):
    if contents is not None: self.MergeFromString(contents)

  def socket_descriptor(self): return self.socket_descriptor_

  def set_socket_descriptor(self, x):
    self.has_socket_descriptor_ = 1
    self.socket_descriptor_ = x

  def clear_socket_descriptor(self):
    if self.has_socket_descriptor_:
      self.has_socket_descriptor_ = 0
      self.socket_descriptor_ = ""

  def has_socket_descriptor(self): return self.has_socket_descriptor_

  def timeout_seconds(self): return self.timeout_seconds_

  def set_timeout_seconds(self, x):
    self.has_timeout_seconds_ = 1
    self.timeout_seconds_ = x

  def clear_timeout_seconds(self):
    if self.has_timeout_seconds_:
      self.has_timeout_seconds_ = 0
      self.timeout_seconds_ = -1.0

  def has_timeout_seconds(self): return self.has_timeout_seconds_


  def MergeFrom(self, x):
    assert x is not self
    if (x.has_socket_descriptor()): self.set_socket_descriptor(x.socket_descriptor())
    if (x.has_timeout_seconds()): self.set_timeout_seconds(x.timeout_seconds())

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.AcceptRequest', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.AcceptRequest')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.AcceptRequest')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.AcceptRequest', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.AcceptRequest', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.AcceptRequest', s)


  def Equals(self, x):
    if x is self: return 1
    if self.has_socket_descriptor_ != x.has_socket_descriptor_: return 0
    if self.has_socket_descriptor_ and self.socket_descriptor_ != x.socket_descriptor_: return 0
    if self.has_timeout_seconds_ != x.has_timeout_seconds_: return 0
    if self.has_timeout_seconds_ and self.timeout_seconds_ != x.timeout_seconds_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    if (not self.has_socket_descriptor_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: socket_descriptor not set.')
    return initialized

  def ByteSize(self):
    n = 0
    n += self.lengthString(len(self.socket_descriptor_))
    if (self.has_timeout_seconds_): n += 9
    return n + 1

  def ByteSizePartial(self):
    n = 0
    if (self.has_socket_descriptor_):
      n += 1
      n += self.lengthString(len(self.socket_descriptor_))
    if (self.has_timeout_seconds_): n += 9
    return n

  def Clear(self):
    self.clear_socket_descriptor()
    self.clear_timeout_seconds()

  def OutputUnchecked(self, out):
    out.putVarInt32(10)
    out.putPrefixedString(self.socket_descriptor_)
    if (self.has_timeout_seconds_):
      out.putVarInt32(17)
      out.putDouble(self.timeout_seconds_)

  def OutputPartial(self, out):
    if (self.has_socket_descriptor_):
      out.putVarInt32(10)
      out.putPrefixedString(self.socket_descriptor_)
    if (self.has_timeout_seconds_):
      out.putVarInt32(17)
      out.putDouble(self.timeout_seconds_)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 10:
        self.set_socket_descriptor(d.getPrefixedString())
        continue
      if tt == 17:
        self.set_timeout_seconds(d.getDouble())
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    if self.has_socket_descriptor_: res+=prefix+("socket_descriptor: %s\n" % self.DebugFormatString(self.socket_descriptor_))
    if self.has_timeout_seconds_: res+=prefix+("timeout_seconds: %s\n" % self.DebugFormat(self.timeout_seconds_))
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  ksocket_descriptor = 1
  ktimeout_seconds = 2

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "socket_descriptor",
    2: "timeout_seconds",
  }, 2)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.STRING,
    2: ProtocolBuffer.Encoder.DOUBLE,
  }, 2, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("WjhhcHBob3N0aW5nL2FwaS9yZW1vdGVfc29ja2V0L3JlbW90ZV9zb2NrZXRfc2VydmljZS5wcm90bwoYYXBwaG9zdGluZy5BY2NlcHRSZXF1ZXN0ExoRc29ja2V0X2Rlc2NyaXB0b3IgASgCMAk4AhQTGg90aW1lb3V0X3NlY29uZHMgAigBMAE4AUIELTEuMKMBqgEHZGVmYXVsdLIBBC0xLjCkARTCASNhcHBob3N0aW5nLlJlbW90ZVNvY2tldFNlcnZpY2VFcnJvcg=="))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class AcceptReply(ProtocolBuffer.ProtocolMessage):
  has_new_socket_descriptor_ = 0
  new_socket_descriptor_ = ""
  has_remote_address_ = 0
  remote_address_ = None

  def __init__(self, contents=None):
    self.lazy_init_lock_ = thread.allocate_lock()
    if contents is not None: self.MergeFromString(contents)

  def new_socket_descriptor(self): return self.new_socket_descriptor_

  def set_new_socket_descriptor(self, x):
    self.has_new_socket_descriptor_ = 1
    self.new_socket_descriptor_ = x

  def clear_new_socket_descriptor(self):
    if self.has_new_socket_descriptor_:
      self.has_new_socket_descriptor_ = 0
      self.new_socket_descriptor_ = ""

  def has_new_socket_descriptor(self): return self.has_new_socket_descriptor_

  def remote_address(self):
    if self.remote_address_ is None:
      self.lazy_init_lock_.acquire()
      try:
        if self.remote_address_ is None: self.remote_address_ = AddressPort()
      finally:
        self.lazy_init_lock_.release()
    return self.remote_address_

  def mutable_remote_address(self): self.has_remote_address_ = 1; return self.remote_address()

  def clear_remote_address(self):

    if self.has_remote_address_:
      self.has_remote_address_ = 0;
      if self.remote_address_ is not None: self.remote_address_.Clear()

  def has_remote_address(self): return self.has_remote_address_


  def MergeFrom(self, x):
    assert x is not self
    if (x.has_new_socket_descriptor()): self.set_new_socket_descriptor(x.new_socket_descriptor())
    if (x.has_remote_address()): self.mutable_remote_address().MergeFrom(x.remote_address())

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.AcceptReply', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.AcceptReply')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.AcceptReply')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.AcceptReply', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.AcceptReply', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.AcceptReply', s)


  def Equals(self, x):
    if x is self: return 1
    if self.has_new_socket_descriptor_ != x.has_new_socket_descriptor_: return 0
    if self.has_new_socket_descriptor_ and self.new_socket_descriptor_ != x.new_socket_descriptor_: return 0
    if self.has_remote_address_ != x.has_remote_address_: return 0
    if self.has_remote_address_ and self.remote_address_ != x.remote_address_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    if (self.has_remote_address_ and not self.remote_address_.IsInitialized(debug_strs)): initialized = 0
    return initialized

  def ByteSize(self):
    n = 0
    if (self.has_new_socket_descriptor_): n += 1 + self.lengthString(len(self.new_socket_descriptor_))
    if (self.has_remote_address_): n += 1 + self.lengthString(self.remote_address_.ByteSize())
    return n

  def ByteSizePartial(self):
    n = 0
    if (self.has_new_socket_descriptor_): n += 1 + self.lengthString(len(self.new_socket_descriptor_))
    if (self.has_remote_address_): n += 1 + self.lengthString(self.remote_address_.ByteSizePartial())
    return n

  def Clear(self):
    self.clear_new_socket_descriptor()
    self.clear_remote_address()

  def OutputUnchecked(self, out):
    if (self.has_new_socket_descriptor_):
      out.putVarInt32(18)
      out.putPrefixedString(self.new_socket_descriptor_)
    if (self.has_remote_address_):
      out.putVarInt32(26)
      out.putVarInt32(self.remote_address_.ByteSize())
      self.remote_address_.OutputUnchecked(out)

  def OutputPartial(self, out):
    if (self.has_new_socket_descriptor_):
      out.putVarInt32(18)
      out.putPrefixedString(self.new_socket_descriptor_)
    if (self.has_remote_address_):
      out.putVarInt32(26)
      out.putVarInt32(self.remote_address_.ByteSizePartial())
      self.remote_address_.OutputPartial(out)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 18:
        self.set_new_socket_descriptor(d.getPrefixedString())
        continue
      if tt == 26:
        length = d.getVarInt32()
        tmp = ProtocolBuffer.Decoder(d.buffer(), d.pos(), d.pos() + length)
        d.skip(length)
        self.mutable_remote_address().TryMerge(tmp)
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    if self.has_new_socket_descriptor_: res+=prefix+("new_socket_descriptor: %s\n" % self.DebugFormatString(self.new_socket_descriptor_))
    if self.has_remote_address_:
      res+=prefix+"remote_address <\n"
      res+=self.remote_address_.__str__(prefix + "  ", printElemNumber)
      res+=prefix+">\n"
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  knew_socket_descriptor = 2
  kremote_address = 3

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    2: "new_socket_descriptor",
    3: "remote_address",
  }, 3)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    2: ProtocolBuffer.Encoder.STRING,
    3: ProtocolBuffer.Encoder.STRING,
  }, 3, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("WjhhcHBob3N0aW5nL2FwaS9yZW1vdGVfc29ja2V0L3JlbW90ZV9zb2NrZXRfc2VydmljZS5wcm90bwoWYXBwaG9zdGluZy5BY2NlcHRSZXBseRMaFW5ld19zb2NrZXRfZGVzY3JpcHRvciACKAIwCTgBFBMaDnJlbW90ZV9hZGRyZXNzIAMoAjALOAFKFmFwcGhvc3RpbmcuQWRkcmVzc1BvcnQUwgEjYXBwaG9zdGluZy5SZW1vdGVTb2NrZXRTZXJ2aWNlRXJyb3I="))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class ShutDownRequest(ProtocolBuffer.ProtocolMessage):


  SOCKET_SHUT_RD =    1
  SOCKET_SHUT_WR =    2
  SOCKET_SHUT_RDWR =    3

  _How_NAMES = {
    1: "SOCKET_SHUT_RD",
    2: "SOCKET_SHUT_WR",
    3: "SOCKET_SHUT_RDWR",
  }

  def How_Name(cls, x): return cls._How_NAMES.get(x, "")
  How_Name = classmethod(How_Name)

  has_socket_descriptor_ = 0
  socket_descriptor_ = ""
  has_how_ = 0
  how_ = 0
  has_send_offset_ = 0
  send_offset_ = 0

  def __init__(self, contents=None):
    if contents is not None: self.MergeFromString(contents)

  def socket_descriptor(self): return self.socket_descriptor_

  def set_socket_descriptor(self, x):
    self.has_socket_descriptor_ = 1
    self.socket_descriptor_ = x

  def clear_socket_descriptor(self):
    if self.has_socket_descriptor_:
      self.has_socket_descriptor_ = 0
      self.socket_descriptor_ = ""

  def has_socket_descriptor(self): return self.has_socket_descriptor_

  def how(self): return self.how_

  def set_how(self, x):
    self.has_how_ = 1
    self.how_ = x

  def clear_how(self):
    if self.has_how_:
      self.has_how_ = 0
      self.how_ = 0

  def has_how(self): return self.has_how_

  def send_offset(self): return self.send_offset_

  def set_send_offset(self, x):
    self.has_send_offset_ = 1
    self.send_offset_ = x

  def clear_send_offset(self):
    if self.has_send_offset_:
      self.has_send_offset_ = 0
      self.send_offset_ = 0

  def has_send_offset(self): return self.has_send_offset_


  def MergeFrom(self, x):
    assert x is not self
    if (x.has_socket_descriptor()): self.set_socket_descriptor(x.socket_descriptor())
    if (x.has_how()): self.set_how(x.how())
    if (x.has_send_offset()): self.set_send_offset(x.send_offset())

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.ShutDownRequest', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.ShutDownRequest')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.ShutDownRequest')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.ShutDownRequest', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.ShutDownRequest', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.ShutDownRequest', s)


  def Equals(self, x):
    if x is self: return 1
    if self.has_socket_descriptor_ != x.has_socket_descriptor_: return 0
    if self.has_socket_descriptor_ and self.socket_descriptor_ != x.socket_descriptor_: return 0
    if self.has_how_ != x.has_how_: return 0
    if self.has_how_ and self.how_ != x.how_: return 0
    if self.has_send_offset_ != x.has_send_offset_: return 0
    if self.has_send_offset_ and self.send_offset_ != x.send_offset_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    if (not self.has_socket_descriptor_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: socket_descriptor not set.')
    if (not self.has_how_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: how not set.')
    if (not self.has_send_offset_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: send_offset not set.')
    return initialized

  def ByteSize(self):
    n = 0
    n += self.lengthString(len(self.socket_descriptor_))
    n += self.lengthVarInt64(self.how_)
    n += self.lengthVarInt64(self.send_offset_)
    return n + 3

  def ByteSizePartial(self):
    n = 0
    if (self.has_socket_descriptor_):
      n += 1
      n += self.lengthString(len(self.socket_descriptor_))
    if (self.has_how_):
      n += 1
      n += self.lengthVarInt64(self.how_)
    if (self.has_send_offset_):
      n += 1
      n += self.lengthVarInt64(self.send_offset_)
    return n

  def Clear(self):
    self.clear_socket_descriptor()
    self.clear_how()
    self.clear_send_offset()

  def OutputUnchecked(self, out):
    out.putVarInt32(10)
    out.putPrefixedString(self.socket_descriptor_)
    out.putVarInt32(16)
    out.putVarInt32(self.how_)
    out.putVarInt32(24)
    out.putVarInt64(self.send_offset_)

  def OutputPartial(self, out):
    if (self.has_socket_descriptor_):
      out.putVarInt32(10)
      out.putPrefixedString(self.socket_descriptor_)
    if (self.has_how_):
      out.putVarInt32(16)
      out.putVarInt32(self.how_)
    if (self.has_send_offset_):
      out.putVarInt32(24)
      out.putVarInt64(self.send_offset_)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 10:
        self.set_socket_descriptor(d.getPrefixedString())
        continue
      if tt == 16:
        self.set_how(d.getVarInt32())
        continue
      if tt == 24:
        self.set_send_offset(d.getVarInt64())
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    if self.has_socket_descriptor_: res+=prefix+("socket_descriptor: %s\n" % self.DebugFormatString(self.socket_descriptor_))
    if self.has_how_: res+=prefix+("how: %s\n" % self.DebugFormatInt32(self.how_))
    if self.has_send_offset_: res+=prefix+("send_offset: %s\n" % self.DebugFormatInt64(self.send_offset_))
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  ksocket_descriptor = 1
  khow = 2
  ksend_offset = 3

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "socket_descriptor",
    2: "how",
    3: "send_offset",
  }, 3)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.STRING,
    2: ProtocolBuffer.Encoder.NUMERIC,
    3: ProtocolBuffer.Encoder.NUMERIC,
  }, 3, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("WjhhcHBob3N0aW5nL2FwaS9yZW1vdGVfc29ja2V0L3JlbW90ZV9zb2NrZXRfc2VydmljZS5wcm90bwoaYXBwaG9zdGluZy5TaHV0RG93blJlcXVlc3QTGhFzb2NrZXRfZGVzY3JpcHRvciABKAIwCTgCFBMaA2hvdyACKAAwBTgCaAAUExoLc2VuZF9vZmZzZXQgAygAMAM4AhRzegNIb3eLAZIBDlNPQ0tFVF9TSFVUX1JEmAEBjAGLAZIBDlNPQ0tFVF9TSFVUX1dSmAECjAGLAZIBEFNPQ0tFVF9TSFVUX1JEV1KYAQOMAXTCASNhcHBob3N0aW5nLlJlbW90ZVNvY2tldFNlcnZpY2VFcnJvcg=="))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class ShutDownReply(ProtocolBuffer.ProtocolMessage):

  def __init__(self, contents=None):
    pass
    if contents is not None: self.MergeFromString(contents)


  def MergeFrom(self, x):
    assert x is not self

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.ShutDownReply', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.ShutDownReply')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.ShutDownReply')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.ShutDownReply', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.ShutDownReply', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.ShutDownReply', s)


  def Equals(self, x):
    if x is self: return 1
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    return initialized

  def ByteSize(self):
    n = 0
    return n

  def ByteSizePartial(self):
    n = 0
    return n

  def Clear(self):
    pass

  def OutputUnchecked(self, out):
    pass

  def OutputPartial(self, out):
    pass

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])


  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
  }, 0)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
  }, 0, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("WjhhcHBob3N0aW5nL2FwaS9yZW1vdGVfc29ja2V0L3JlbW90ZV9zb2NrZXRfc2VydmljZS5wcm90bwoYYXBwaG9zdGluZy5TaHV0RG93blJlcGx5wgEjYXBwaG9zdGluZy5SZW1vdGVTb2NrZXRTZXJ2aWNlRXJyb3I="))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class CloseRequest(ProtocolBuffer.ProtocolMessage):
  has_socket_descriptor_ = 0
  socket_descriptor_ = ""
  has_send_offset_ = 0
  send_offset_ = -1

  def __init__(self, contents=None):
    if contents is not None: self.MergeFromString(contents)

  def socket_descriptor(self): return self.socket_descriptor_

  def set_socket_descriptor(self, x):
    self.has_socket_descriptor_ = 1
    self.socket_descriptor_ = x

  def clear_socket_descriptor(self):
    if self.has_socket_descriptor_:
      self.has_socket_descriptor_ = 0
      self.socket_descriptor_ = ""

  def has_socket_descriptor(self): return self.has_socket_descriptor_

  def send_offset(self): return self.send_offset_

  def set_send_offset(self, x):
    self.has_send_offset_ = 1
    self.send_offset_ = x

  def clear_send_offset(self):
    if self.has_send_offset_:
      self.has_send_offset_ = 0
      self.send_offset_ = -1

  def has_send_offset(self): return self.has_send_offset_


  def MergeFrom(self, x):
    assert x is not self
    if (x.has_socket_descriptor()): self.set_socket_descriptor(x.socket_descriptor())
    if (x.has_send_offset()): self.set_send_offset(x.send_offset())

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.CloseRequest', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.CloseRequest')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.CloseRequest')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.CloseRequest', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.CloseRequest', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.CloseRequest', s)


  def Equals(self, x):
    if x is self: return 1
    if self.has_socket_descriptor_ != x.has_socket_descriptor_: return 0
    if self.has_socket_descriptor_ and self.socket_descriptor_ != x.socket_descriptor_: return 0
    if self.has_send_offset_ != x.has_send_offset_: return 0
    if self.has_send_offset_ and self.send_offset_ != x.send_offset_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    if (not self.has_socket_descriptor_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: socket_descriptor not set.')
    return initialized

  def ByteSize(self):
    n = 0
    n += self.lengthString(len(self.socket_descriptor_))
    if (self.has_send_offset_): n += 1 + self.lengthVarInt64(self.send_offset_)
    return n + 1

  def ByteSizePartial(self):
    n = 0
    if (self.has_socket_descriptor_):
      n += 1
      n += self.lengthString(len(self.socket_descriptor_))
    if (self.has_send_offset_): n += 1 + self.lengthVarInt64(self.send_offset_)
    return n

  def Clear(self):
    self.clear_socket_descriptor()
    self.clear_send_offset()

  def OutputUnchecked(self, out):
    out.putVarInt32(10)
    out.putPrefixedString(self.socket_descriptor_)
    if (self.has_send_offset_):
      out.putVarInt32(16)
      out.putVarInt64(self.send_offset_)

  def OutputPartial(self, out):
    if (self.has_socket_descriptor_):
      out.putVarInt32(10)
      out.putPrefixedString(self.socket_descriptor_)
    if (self.has_send_offset_):
      out.putVarInt32(16)
      out.putVarInt64(self.send_offset_)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 10:
        self.set_socket_descriptor(d.getPrefixedString())
        continue
      if tt == 16:
        self.set_send_offset(d.getVarInt64())
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    if self.has_socket_descriptor_: res+=prefix+("socket_descriptor: %s\n" % self.DebugFormatString(self.socket_descriptor_))
    if self.has_send_offset_: res+=prefix+("send_offset: %s\n" % self.DebugFormatInt64(self.send_offset_))
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  ksocket_descriptor = 1
  ksend_offset = 2

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "socket_descriptor",
    2: "send_offset",
  }, 2)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.STRING,
    2: ProtocolBuffer.Encoder.NUMERIC,
  }, 2, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("WjhhcHBob3N0aW5nL2FwaS9yZW1vdGVfc29ja2V0L3JlbW90ZV9zb2NrZXRfc2VydmljZS5wcm90bwoXYXBwaG9zdGluZy5DbG9zZVJlcXVlc3QTGhFzb2NrZXRfZGVzY3JpcHRvciABKAIwCTgCFBMaC3NlbmRfb2Zmc2V0IAIoADADOAFCAi0xowGqAQdkZWZhdWx0sgECLTGkARTCASNhcHBob3N0aW5nLlJlbW90ZVNvY2tldFNlcnZpY2VFcnJvcg=="))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class CloseReply(ProtocolBuffer.ProtocolMessage):

  def __init__(self, contents=None):
    pass
    if contents is not None: self.MergeFromString(contents)


  def MergeFrom(self, x):
    assert x is not self

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.CloseReply', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.CloseReply')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.CloseReply')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.CloseReply', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.CloseReply', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.CloseReply', s)


  def Equals(self, x):
    if x is self: return 1
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    return initialized

  def ByteSize(self):
    n = 0
    return n

  def ByteSizePartial(self):
    n = 0
    return n

  def Clear(self):
    pass

  def OutputUnchecked(self, out):
    pass

  def OutputPartial(self, out):
    pass

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])


  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
  }, 0)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
  }, 0, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("WjhhcHBob3N0aW5nL2FwaS9yZW1vdGVfc29ja2V0L3JlbW90ZV9zb2NrZXRfc2VydmljZS5wcm90bwoVYXBwaG9zdGluZy5DbG9zZVJlcGx5wgEjYXBwaG9zdGluZy5SZW1vdGVTb2NrZXRTZXJ2aWNlRXJyb3I="))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class SendRequest(ProtocolBuffer.ProtocolMessage):
  has_socket_descriptor_ = 0
  socket_descriptor_ = ""
  has_data_ = 0
  data_ = ""
  has_stream_offset_ = 0
  stream_offset_ = 0
  has_flags_ = 0
  flags_ = 0
  has_send_to_ = 0
  send_to_ = None
  has_timeout_seconds_ = 0
  timeout_seconds_ = -1.0

  def __init__(self, contents=None):
    self.lazy_init_lock_ = thread.allocate_lock()
    if contents is not None: self.MergeFromString(contents)

  def socket_descriptor(self): return self.socket_descriptor_

  def set_socket_descriptor(self, x):
    self.has_socket_descriptor_ = 1
    self.socket_descriptor_ = x

  def clear_socket_descriptor(self):
    if self.has_socket_descriptor_:
      self.has_socket_descriptor_ = 0
      self.socket_descriptor_ = ""

  def has_socket_descriptor(self): return self.has_socket_descriptor_

  def data(self): return self.data_

  def set_data(self, x):
    self.has_data_ = 1
    self.data_ = x

  def clear_data(self):
    if self.has_data_:
      self.has_data_ = 0
      self.data_ = ""

  def has_data(self): return self.has_data_

  def stream_offset(self): return self.stream_offset_

  def set_stream_offset(self, x):
    self.has_stream_offset_ = 1
    self.stream_offset_ = x

  def clear_stream_offset(self):
    if self.has_stream_offset_:
      self.has_stream_offset_ = 0
      self.stream_offset_ = 0

  def has_stream_offset(self): return self.has_stream_offset_

  def flags(self): return self.flags_

  def set_flags(self, x):
    self.has_flags_ = 1
    self.flags_ = x

  def clear_flags(self):
    if self.has_flags_:
      self.has_flags_ = 0
      self.flags_ = 0

  def has_flags(self): return self.has_flags_

  def send_to(self):
    if self.send_to_ is None:
      self.lazy_init_lock_.acquire()
      try:
        if self.send_to_ is None: self.send_to_ = AddressPort()
      finally:
        self.lazy_init_lock_.release()
    return self.send_to_

  def mutable_send_to(self): self.has_send_to_ = 1; return self.send_to()

  def clear_send_to(self):

    if self.has_send_to_:
      self.has_send_to_ = 0;
      if self.send_to_ is not None: self.send_to_.Clear()

  def has_send_to(self): return self.has_send_to_

  def timeout_seconds(self): return self.timeout_seconds_

  def set_timeout_seconds(self, x):
    self.has_timeout_seconds_ = 1
    self.timeout_seconds_ = x

  def clear_timeout_seconds(self):
    if self.has_timeout_seconds_:
      self.has_timeout_seconds_ = 0
      self.timeout_seconds_ = -1.0

  def has_timeout_seconds(self): return self.has_timeout_seconds_


  def MergeFrom(self, x):
    assert x is not self
    if (x.has_socket_descriptor()): self.set_socket_descriptor(x.socket_descriptor())
    if (x.has_data()): self.set_data(x.data())
    if (x.has_stream_offset()): self.set_stream_offset(x.stream_offset())
    if (x.has_flags()): self.set_flags(x.flags())
    if (x.has_send_to()): self.mutable_send_to().MergeFrom(x.send_to())
    if (x.has_timeout_seconds()): self.set_timeout_seconds(x.timeout_seconds())

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.SendRequest', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.SendRequest')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.SendRequest')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.SendRequest', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.SendRequest', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.SendRequest', s)


  def Equals(self, x):
    if x is self: return 1
    if self.has_socket_descriptor_ != x.has_socket_descriptor_: return 0
    if self.has_socket_descriptor_ and self.socket_descriptor_ != x.socket_descriptor_: return 0
    if self.has_data_ != x.has_data_: return 0
    if self.has_data_ and self.data_ != x.data_: return 0
    if self.has_stream_offset_ != x.has_stream_offset_: return 0
    if self.has_stream_offset_ and self.stream_offset_ != x.stream_offset_: return 0
    if self.has_flags_ != x.has_flags_: return 0
    if self.has_flags_ and self.flags_ != x.flags_: return 0
    if self.has_send_to_ != x.has_send_to_: return 0
    if self.has_send_to_ and self.send_to_ != x.send_to_: return 0
    if self.has_timeout_seconds_ != x.has_timeout_seconds_: return 0
    if self.has_timeout_seconds_ and self.timeout_seconds_ != x.timeout_seconds_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    if (not self.has_socket_descriptor_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: socket_descriptor not set.')
    if (not self.has_data_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: data not set.')
    if (not self.has_stream_offset_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: stream_offset not set.')
    if (self.has_send_to_ and not self.send_to_.IsInitialized(debug_strs)): initialized = 0
    return initialized

  def ByteSize(self):
    n = 0
    n += self.lengthString(len(self.socket_descriptor_))
    n += self.lengthString(len(self.data_))
    n += self.lengthVarInt64(self.stream_offset_)
    if (self.has_flags_): n += 1 + self.lengthVarInt64(self.flags_)
    if (self.has_send_to_): n += 1 + self.lengthString(self.send_to_.ByteSize())
    if (self.has_timeout_seconds_): n += 9
    return n + 3

  def ByteSizePartial(self):
    n = 0
    if (self.has_socket_descriptor_):
      n += 1
      n += self.lengthString(len(self.socket_descriptor_))
    if (self.has_data_):
      n += 1
      n += self.lengthString(len(self.data_))
    if (self.has_stream_offset_):
      n += 1
      n += self.lengthVarInt64(self.stream_offset_)
    if (self.has_flags_): n += 1 + self.lengthVarInt64(self.flags_)
    if (self.has_send_to_): n += 1 + self.lengthString(self.send_to_.ByteSizePartial())
    if (self.has_timeout_seconds_): n += 9
    return n

  def Clear(self):
    self.clear_socket_descriptor()
    self.clear_data()
    self.clear_stream_offset()
    self.clear_flags()
    self.clear_send_to()
    self.clear_timeout_seconds()

  def OutputUnchecked(self, out):
    out.putVarInt32(10)
    out.putPrefixedString(self.socket_descriptor_)
    out.putVarInt32(18)
    out.putPrefixedString(self.data_)
    out.putVarInt32(24)
    out.putVarInt64(self.stream_offset_)
    if (self.has_flags_):
      out.putVarInt32(32)
      out.putVarInt32(self.flags_)
    if (self.has_send_to_):
      out.putVarInt32(42)
      out.putVarInt32(self.send_to_.ByteSize())
      self.send_to_.OutputUnchecked(out)
    if (self.has_timeout_seconds_):
      out.putVarInt32(49)
      out.putDouble(self.timeout_seconds_)

  def OutputPartial(self, out):
    if (self.has_socket_descriptor_):
      out.putVarInt32(10)
      out.putPrefixedString(self.socket_descriptor_)
    if (self.has_data_):
      out.putVarInt32(18)
      out.putPrefixedString(self.data_)
    if (self.has_stream_offset_):
      out.putVarInt32(24)
      out.putVarInt64(self.stream_offset_)
    if (self.has_flags_):
      out.putVarInt32(32)
      out.putVarInt32(self.flags_)
    if (self.has_send_to_):
      out.putVarInt32(42)
      out.putVarInt32(self.send_to_.ByteSizePartial())
      self.send_to_.OutputPartial(out)
    if (self.has_timeout_seconds_):
      out.putVarInt32(49)
      out.putDouble(self.timeout_seconds_)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 10:
        self.set_socket_descriptor(d.getPrefixedString())
        continue
      if tt == 18:
        self.set_data(d.getPrefixedString())
        continue
      if tt == 24:
        self.set_stream_offset(d.getVarInt64())
        continue
      if tt == 32:
        self.set_flags(d.getVarInt32())
        continue
      if tt == 42:
        length = d.getVarInt32()
        tmp = ProtocolBuffer.Decoder(d.buffer(), d.pos(), d.pos() + length)
        d.skip(length)
        self.mutable_send_to().TryMerge(tmp)
        continue
      if tt == 49:
        self.set_timeout_seconds(d.getDouble())
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    if self.has_socket_descriptor_: res+=prefix+("socket_descriptor: %s\n" % self.DebugFormatString(self.socket_descriptor_))
    if self.has_data_: res+=prefix+("data: %s\n" % self.DebugFormatString(self.data_))
    if self.has_stream_offset_: res+=prefix+("stream_offset: %s\n" % self.DebugFormatInt64(self.stream_offset_))
    if self.has_flags_: res+=prefix+("flags: %s\n" % self.DebugFormatInt32(self.flags_))
    if self.has_send_to_:
      res+=prefix+"send_to <\n"
      res+=self.send_to_.__str__(prefix + "  ", printElemNumber)
      res+=prefix+">\n"
    if self.has_timeout_seconds_: res+=prefix+("timeout_seconds: %s\n" % self.DebugFormat(self.timeout_seconds_))
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  ksocket_descriptor = 1
  kdata = 2
  kstream_offset = 3
  kflags = 4
  ksend_to = 5
  ktimeout_seconds = 6

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "socket_descriptor",
    2: "data",
    3: "stream_offset",
    4: "flags",
    5: "send_to",
    6: "timeout_seconds",
  }, 6)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.STRING,
    2: ProtocolBuffer.Encoder.STRING,
    3: ProtocolBuffer.Encoder.NUMERIC,
    4: ProtocolBuffer.Encoder.NUMERIC,
    5: ProtocolBuffer.Encoder.STRING,
    6: ProtocolBuffer.Encoder.DOUBLE,
  }, 6, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("WjhhcHBob3N0aW5nL2FwaS9yZW1vdGVfc29ja2V0L3JlbW90ZV9zb2NrZXRfc2VydmljZS5wcm90bwoWYXBwaG9zdGluZy5TZW5kUmVxdWVzdBMaEXNvY2tldF9kZXNjcmlwdG9yIAEoAjAJOAIUExoEZGF0YSACKAIwCTgCowGqAQVjdHlwZbIBBENvcmSkARQTGg1zdHJlYW1fb2Zmc2V0IAMoADADOAIUExoFZmxhZ3MgBCgAMAU4AUIBMKMBqgEHZGVmYXVsdLIBATCkARQTGgdzZW5kX3RvIAUoAjALOAFKFmFwcGhvc3RpbmcuQWRkcmVzc1BvcnQUExoPdGltZW91dF9zZWNvbmRzIAYoATABOAFCBC0xLjCjAaoBB2RlZmF1bHSyAQQtMS4wpAEUwgEjYXBwaG9zdGluZy5SZW1vdGVTb2NrZXRTZXJ2aWNlRXJyb3I="))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class SendReply(ProtocolBuffer.ProtocolMessage):
  has_data_sent_ = 0
  data_sent_ = 0

  def __init__(self, contents=None):
    if contents is not None: self.MergeFromString(contents)

  def data_sent(self): return self.data_sent_

  def set_data_sent(self, x):
    self.has_data_sent_ = 1
    self.data_sent_ = x

  def clear_data_sent(self):
    if self.has_data_sent_:
      self.has_data_sent_ = 0
      self.data_sent_ = 0

  def has_data_sent(self): return self.has_data_sent_


  def MergeFrom(self, x):
    assert x is not self
    if (x.has_data_sent()): self.set_data_sent(x.data_sent())

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.SendReply', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.SendReply')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.SendReply')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.SendReply', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.SendReply', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.SendReply', s)


  def Equals(self, x):
    if x is self: return 1
    if self.has_data_sent_ != x.has_data_sent_: return 0
    if self.has_data_sent_ and self.data_sent_ != x.data_sent_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    return initialized

  def ByteSize(self):
    n = 0
    if (self.has_data_sent_): n += 1 + self.lengthVarInt64(self.data_sent_)
    return n

  def ByteSizePartial(self):
    n = 0
    if (self.has_data_sent_): n += 1 + self.lengthVarInt64(self.data_sent_)
    return n

  def Clear(self):
    self.clear_data_sent()

  def OutputUnchecked(self, out):
    if (self.has_data_sent_):
      out.putVarInt32(8)
      out.putVarInt32(self.data_sent_)

  def OutputPartial(self, out):
    if (self.has_data_sent_):
      out.putVarInt32(8)
      out.putVarInt32(self.data_sent_)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 8:
        self.set_data_sent(d.getVarInt32())
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    if self.has_data_sent_: res+=prefix+("data_sent: %s\n" % self.DebugFormatInt32(self.data_sent_))
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  kdata_sent = 1

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "data_sent",
  }, 1)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.NUMERIC,
  }, 1, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("WjhhcHBob3N0aW5nL2FwaS9yZW1vdGVfc29ja2V0L3JlbW90ZV9zb2NrZXRfc2VydmljZS5wcm90bwoUYXBwaG9zdGluZy5TZW5kUmVwbHkTGglkYXRhX3NlbnQgASgAMAU4ARTCASNhcHBob3N0aW5nLlJlbW90ZVNvY2tldFNlcnZpY2VFcnJvcg=="))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class ReceiveRequest(ProtocolBuffer.ProtocolMessage):
  has_socket_descriptor_ = 0
  socket_descriptor_ = ""
  has_data_size_ = 0
  data_size_ = 0
  has_flags_ = 0
  flags_ = 0
  has_receive_from_ = 0
  receive_from_ = 0
  has_timeout_seconds_ = 0
  timeout_seconds_ = -1.0

  def __init__(self, contents=None):
    if contents is not None: self.MergeFromString(contents)

  def socket_descriptor(self): return self.socket_descriptor_

  def set_socket_descriptor(self, x):
    self.has_socket_descriptor_ = 1
    self.socket_descriptor_ = x

  def clear_socket_descriptor(self):
    if self.has_socket_descriptor_:
      self.has_socket_descriptor_ = 0
      self.socket_descriptor_ = ""

  def has_socket_descriptor(self): return self.has_socket_descriptor_

  def data_size(self): return self.data_size_

  def set_data_size(self, x):
    self.has_data_size_ = 1
    self.data_size_ = x

  def clear_data_size(self):
    if self.has_data_size_:
      self.has_data_size_ = 0
      self.data_size_ = 0

  def has_data_size(self): return self.has_data_size_

  def flags(self): return self.flags_

  def set_flags(self, x):
    self.has_flags_ = 1
    self.flags_ = x

  def clear_flags(self):
    if self.has_flags_:
      self.has_flags_ = 0
      self.flags_ = 0

  def has_flags(self): return self.has_flags_

  def receive_from(self): return self.receive_from_

  def set_receive_from(self, x):
    self.has_receive_from_ = 1
    self.receive_from_ = x

  def clear_receive_from(self):
    if self.has_receive_from_:
      self.has_receive_from_ = 0
      self.receive_from_ = 0

  def has_receive_from(self): return self.has_receive_from_

  def timeout_seconds(self): return self.timeout_seconds_

  def set_timeout_seconds(self, x):
    self.has_timeout_seconds_ = 1
    self.timeout_seconds_ = x

  def clear_timeout_seconds(self):
    if self.has_timeout_seconds_:
      self.has_timeout_seconds_ = 0
      self.timeout_seconds_ = -1.0

  def has_timeout_seconds(self): return self.has_timeout_seconds_


  def MergeFrom(self, x):
    assert x is not self
    if (x.has_socket_descriptor()): self.set_socket_descriptor(x.socket_descriptor())
    if (x.has_data_size()): self.set_data_size(x.data_size())
    if (x.has_flags()): self.set_flags(x.flags())
    if (x.has_receive_from()): self.set_receive_from(x.receive_from())
    if (x.has_timeout_seconds()): self.set_timeout_seconds(x.timeout_seconds())

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.ReceiveRequest', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.ReceiveRequest')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.ReceiveRequest')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.ReceiveRequest', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.ReceiveRequest', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.ReceiveRequest', s)


  def Equals(self, x):
    if x is self: return 1
    if self.has_socket_descriptor_ != x.has_socket_descriptor_: return 0
    if self.has_socket_descriptor_ and self.socket_descriptor_ != x.socket_descriptor_: return 0
    if self.has_data_size_ != x.has_data_size_: return 0
    if self.has_data_size_ and self.data_size_ != x.data_size_: return 0
    if self.has_flags_ != x.has_flags_: return 0
    if self.has_flags_ and self.flags_ != x.flags_: return 0
    if self.has_receive_from_ != x.has_receive_from_: return 0
    if self.has_receive_from_ and self.receive_from_ != x.receive_from_: return 0
    if self.has_timeout_seconds_ != x.has_timeout_seconds_: return 0
    if self.has_timeout_seconds_ and self.timeout_seconds_ != x.timeout_seconds_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    if (not self.has_socket_descriptor_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: socket_descriptor not set.')
    if (not self.has_data_size_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: data_size not set.')
    return initialized

  def ByteSize(self):
    n = 0
    n += self.lengthString(len(self.socket_descriptor_))
    n += self.lengthVarInt64(self.data_size_)
    if (self.has_flags_): n += 1 + self.lengthVarInt64(self.flags_)
    if (self.has_receive_from_): n += 2
    if (self.has_timeout_seconds_): n += 9
    return n + 2

  def ByteSizePartial(self):
    n = 0
    if (self.has_socket_descriptor_):
      n += 1
      n += self.lengthString(len(self.socket_descriptor_))
    if (self.has_data_size_):
      n += 1
      n += self.lengthVarInt64(self.data_size_)
    if (self.has_flags_): n += 1 + self.lengthVarInt64(self.flags_)
    if (self.has_receive_from_): n += 2
    if (self.has_timeout_seconds_): n += 9
    return n

  def Clear(self):
    self.clear_socket_descriptor()
    self.clear_data_size()
    self.clear_flags()
    self.clear_receive_from()
    self.clear_timeout_seconds()

  def OutputUnchecked(self, out):
    out.putVarInt32(10)
    out.putPrefixedString(self.socket_descriptor_)
    out.putVarInt32(16)
    out.putVarInt32(self.data_size_)
    if (self.has_flags_):
      out.putVarInt32(24)
      out.putVarInt32(self.flags_)
    if (self.has_receive_from_):
      out.putVarInt32(32)
      out.putBoolean(self.receive_from_)
    if (self.has_timeout_seconds_):
      out.putVarInt32(41)
      out.putDouble(self.timeout_seconds_)

  def OutputPartial(self, out):
    if (self.has_socket_descriptor_):
      out.putVarInt32(10)
      out.putPrefixedString(self.socket_descriptor_)
    if (self.has_data_size_):
      out.putVarInt32(16)
      out.putVarInt32(self.data_size_)
    if (self.has_flags_):
      out.putVarInt32(24)
      out.putVarInt32(self.flags_)
    if (self.has_receive_from_):
      out.putVarInt32(32)
      out.putBoolean(self.receive_from_)
    if (self.has_timeout_seconds_):
      out.putVarInt32(41)
      out.putDouble(self.timeout_seconds_)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 10:
        self.set_socket_descriptor(d.getPrefixedString())
        continue
      if tt == 16:
        self.set_data_size(d.getVarInt32())
        continue
      if tt == 24:
        self.set_flags(d.getVarInt32())
        continue
      if tt == 32:
        self.set_receive_from(d.getBoolean())
        continue
      if tt == 41:
        self.set_timeout_seconds(d.getDouble())
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    if self.has_socket_descriptor_: res+=prefix+("socket_descriptor: %s\n" % self.DebugFormatString(self.socket_descriptor_))
    if self.has_data_size_: res+=prefix+("data_size: %s\n" % self.DebugFormatInt32(self.data_size_))
    if self.has_flags_: res+=prefix+("flags: %s\n" % self.DebugFormatInt32(self.flags_))
    if self.has_receive_from_: res+=prefix+("receive_from: %s\n" % self.DebugFormatBool(self.receive_from_))
    if self.has_timeout_seconds_: res+=prefix+("timeout_seconds: %s\n" % self.DebugFormat(self.timeout_seconds_))
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  ksocket_descriptor = 1
  kdata_size = 2
  kflags = 3
  kreceive_from = 4
  ktimeout_seconds = 5

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "socket_descriptor",
    2: "data_size",
    3: "flags",
    4: "receive_from",
    5: "timeout_seconds",
  }, 5)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.STRING,
    2: ProtocolBuffer.Encoder.NUMERIC,
    3: ProtocolBuffer.Encoder.NUMERIC,
    4: ProtocolBuffer.Encoder.NUMERIC,
    5: ProtocolBuffer.Encoder.DOUBLE,
  }, 5, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("WjhhcHBob3N0aW5nL2FwaS9yZW1vdGVfc29ja2V0L3JlbW90ZV9zb2NrZXRfc2VydmljZS5wcm90bwoZYXBwaG9zdGluZy5SZWNlaXZlUmVxdWVzdBMaEXNvY2tldF9kZXNjcmlwdG9yIAEoAjAJOAIUExoJZGF0YV9zaXplIAIoADAFOAIUExoFZmxhZ3MgAygAMAU4AUIBMKMBqgEHZGVmYXVsdLIBATCkARQTGgxyZWNlaXZlX2Zyb20gBCgAMAg4ARQTGg90aW1lb3V0X3NlY29uZHMgBSgBMAE4AUIELTEuMKMBqgEHZGVmYXVsdLIBBC0xLjCkARTCASNhcHBob3N0aW5nLlJlbW90ZVNvY2tldFNlcnZpY2VFcnJvcg=="))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class ReceiveReply(ProtocolBuffer.ProtocolMessage):
  has_stream_offset_ = 0
  stream_offset_ = 0
  has_data_ = 0
  data_ = ""
  has_received_from_ = 0
  received_from_ = None

  def __init__(self, contents=None):
    self.lazy_init_lock_ = thread.allocate_lock()
    if contents is not None: self.MergeFromString(contents)

  def stream_offset(self): return self.stream_offset_

  def set_stream_offset(self, x):
    self.has_stream_offset_ = 1
    self.stream_offset_ = x

  def clear_stream_offset(self):
    if self.has_stream_offset_:
      self.has_stream_offset_ = 0
      self.stream_offset_ = 0

  def has_stream_offset(self): return self.has_stream_offset_

  def data(self): return self.data_

  def set_data(self, x):
    self.has_data_ = 1
    self.data_ = x

  def clear_data(self):
    if self.has_data_:
      self.has_data_ = 0
      self.data_ = ""

  def has_data(self): return self.has_data_

  def received_from(self):
    if self.received_from_ is None:
      self.lazy_init_lock_.acquire()
      try:
        if self.received_from_ is None: self.received_from_ = AddressPort()
      finally:
        self.lazy_init_lock_.release()
    return self.received_from_

  def mutable_received_from(self): self.has_received_from_ = 1; return self.received_from()

  def clear_received_from(self):

    if self.has_received_from_:
      self.has_received_from_ = 0;
      if self.received_from_ is not None: self.received_from_.Clear()

  def has_received_from(self): return self.has_received_from_


  def MergeFrom(self, x):
    assert x is not self
    if (x.has_stream_offset()): self.set_stream_offset(x.stream_offset())
    if (x.has_data()): self.set_data(x.data())
    if (x.has_received_from()): self.mutable_received_from().MergeFrom(x.received_from())

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.ReceiveReply', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.ReceiveReply')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.ReceiveReply')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.ReceiveReply', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.ReceiveReply', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.ReceiveReply', s)


  def Equals(self, x):
    if x is self: return 1
    if self.has_stream_offset_ != x.has_stream_offset_: return 0
    if self.has_stream_offset_ and self.stream_offset_ != x.stream_offset_: return 0
    if self.has_data_ != x.has_data_: return 0
    if self.has_data_ and self.data_ != x.data_: return 0
    if self.has_received_from_ != x.has_received_from_: return 0
    if self.has_received_from_ and self.received_from_ != x.received_from_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    if (self.has_received_from_ and not self.received_from_.IsInitialized(debug_strs)): initialized = 0
    return initialized

  def ByteSize(self):
    n = 0
    if (self.has_stream_offset_): n += 1 + self.lengthVarInt64(self.stream_offset_)
    if (self.has_data_): n += 1 + self.lengthString(len(self.data_))
    if (self.has_received_from_): n += 1 + self.lengthString(self.received_from_.ByteSize())
    return n

  def ByteSizePartial(self):
    n = 0
    if (self.has_stream_offset_): n += 1 + self.lengthVarInt64(self.stream_offset_)
    if (self.has_data_): n += 1 + self.lengthString(len(self.data_))
    if (self.has_received_from_): n += 1 + self.lengthString(self.received_from_.ByteSizePartial())
    return n

  def Clear(self):
    self.clear_stream_offset()
    self.clear_data()
    self.clear_received_from()

  def OutputUnchecked(self, out):
    if (self.has_stream_offset_):
      out.putVarInt32(16)
      out.putVarInt64(self.stream_offset_)
    if (self.has_data_):
      out.putVarInt32(26)
      out.putPrefixedString(self.data_)
    if (self.has_received_from_):
      out.putVarInt32(34)
      out.putVarInt32(self.received_from_.ByteSize())
      self.received_from_.OutputUnchecked(out)

  def OutputPartial(self, out):
    if (self.has_stream_offset_):
      out.putVarInt32(16)
      out.putVarInt64(self.stream_offset_)
    if (self.has_data_):
      out.putVarInt32(26)
      out.putPrefixedString(self.data_)
    if (self.has_received_from_):
      out.putVarInt32(34)
      out.putVarInt32(self.received_from_.ByteSizePartial())
      self.received_from_.OutputPartial(out)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 16:
        self.set_stream_offset(d.getVarInt64())
        continue
      if tt == 26:
        self.set_data(d.getPrefixedString())
        continue
      if tt == 34:
        length = d.getVarInt32()
        tmp = ProtocolBuffer.Decoder(d.buffer(), d.pos(), d.pos() + length)
        d.skip(length)
        self.mutable_received_from().TryMerge(tmp)
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    if self.has_stream_offset_: res+=prefix+("stream_offset: %s\n" % self.DebugFormatInt64(self.stream_offset_))
    if self.has_data_: res+=prefix+("data: %s\n" % self.DebugFormatString(self.data_))
    if self.has_received_from_:
      res+=prefix+"received_from <\n"
      res+=self.received_from_.__str__(prefix + "  ", printElemNumber)
      res+=prefix+">\n"
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  kstream_offset = 2
  kdata = 3
  kreceived_from = 4

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    2: "stream_offset",
    3: "data",
    4: "received_from",
  }, 4)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    2: ProtocolBuffer.Encoder.NUMERIC,
    3: ProtocolBuffer.Encoder.STRING,
    4: ProtocolBuffer.Encoder.STRING,
  }, 4, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("WjhhcHBob3N0aW5nL2FwaS9yZW1vdGVfc29ja2V0L3JlbW90ZV9zb2NrZXRfc2VydmljZS5wcm90bwoXYXBwaG9zdGluZy5SZWNlaXZlUmVwbHkTGg1zdHJlYW1fb2Zmc2V0IAIoADADOAEUExoEZGF0YSADKAIwCTgBowGqAQVjdHlwZbIBBENvcmSkARQTGg1yZWNlaXZlZF9mcm9tIAQoAjALOAFKFmFwcGhvc3RpbmcuQWRkcmVzc1BvcnQUwgEjYXBwaG9zdGluZy5SZW1vdGVTb2NrZXRTZXJ2aWNlRXJyb3I="))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class PollEvent(ProtocolBuffer.ProtocolMessage):


  SOCKET_POLLNONE =    0
  SOCKET_POLLIN =    1
  SOCKET_POLLPRI =    2
  SOCKET_POLLOUT =    4
  SOCKET_POLLERR =    8
  SOCKET_POLLHUP =   16
  SOCKET_POLLNVAL =   32
  SOCKET_POLLRDNORM =   64
  SOCKET_POLLRDBAND =  128
  SOCKET_POLLWRNORM =  256
  SOCKET_POLLWRBAND =  512
  SOCKET_POLLMSG = 1024
  SOCKET_POLLREMOVE = 4096
  SOCKET_POLLRDHUP = 8192

  _PollEventFlag_NAMES = {
    0: "SOCKET_POLLNONE",
    1: "SOCKET_POLLIN",
    2: "SOCKET_POLLPRI",
    4: "SOCKET_POLLOUT",
    8: "SOCKET_POLLERR",
    16: "SOCKET_POLLHUP",
    32: "SOCKET_POLLNVAL",
    64: "SOCKET_POLLRDNORM",
    128: "SOCKET_POLLRDBAND",
    256: "SOCKET_POLLWRNORM",
    512: "SOCKET_POLLWRBAND",
    1024: "SOCKET_POLLMSG",
    4096: "SOCKET_POLLREMOVE",
    8192: "SOCKET_POLLRDHUP",
  }

  def PollEventFlag_Name(cls, x): return cls._PollEventFlag_NAMES.get(x, "")
  PollEventFlag_Name = classmethod(PollEventFlag_Name)

  has_socket_descriptor_ = 0
  socket_descriptor_ = ""
  has_requested_events_ = 0
  requested_events_ = 0
  has_observed_events_ = 0
  observed_events_ = 0

  def __init__(self, contents=None):
    if contents is not None: self.MergeFromString(contents)

  def socket_descriptor(self): return self.socket_descriptor_

  def set_socket_descriptor(self, x):
    self.has_socket_descriptor_ = 1
    self.socket_descriptor_ = x

  def clear_socket_descriptor(self):
    if self.has_socket_descriptor_:
      self.has_socket_descriptor_ = 0
      self.socket_descriptor_ = ""

  def has_socket_descriptor(self): return self.has_socket_descriptor_

  def requested_events(self): return self.requested_events_

  def set_requested_events(self, x):
    self.has_requested_events_ = 1
    self.requested_events_ = x

  def clear_requested_events(self):
    if self.has_requested_events_:
      self.has_requested_events_ = 0
      self.requested_events_ = 0

  def has_requested_events(self): return self.has_requested_events_

  def observed_events(self): return self.observed_events_

  def set_observed_events(self, x):
    self.has_observed_events_ = 1
    self.observed_events_ = x

  def clear_observed_events(self):
    if self.has_observed_events_:
      self.has_observed_events_ = 0
      self.observed_events_ = 0

  def has_observed_events(self): return self.has_observed_events_


  def MergeFrom(self, x):
    assert x is not self
    if (x.has_socket_descriptor()): self.set_socket_descriptor(x.socket_descriptor())
    if (x.has_requested_events()): self.set_requested_events(x.requested_events())
    if (x.has_observed_events()): self.set_observed_events(x.observed_events())

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.PollEvent', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.PollEvent')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.PollEvent')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.PollEvent', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.PollEvent', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.PollEvent', s)


  def Equals(self, x):
    if x is self: return 1
    if self.has_socket_descriptor_ != x.has_socket_descriptor_: return 0
    if self.has_socket_descriptor_ and self.socket_descriptor_ != x.socket_descriptor_: return 0
    if self.has_requested_events_ != x.has_requested_events_: return 0
    if self.has_requested_events_ and self.requested_events_ != x.requested_events_: return 0
    if self.has_observed_events_ != x.has_observed_events_: return 0
    if self.has_observed_events_ and self.observed_events_ != x.observed_events_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    if (not self.has_socket_descriptor_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: socket_descriptor not set.')
    if (not self.has_requested_events_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: requested_events not set.')
    if (not self.has_observed_events_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: observed_events not set.')
    return initialized

  def ByteSize(self):
    n = 0
    n += self.lengthString(len(self.socket_descriptor_))
    n += self.lengthVarInt64(self.requested_events_)
    n += self.lengthVarInt64(self.observed_events_)
    return n + 3

  def ByteSizePartial(self):
    n = 0
    if (self.has_socket_descriptor_):
      n += 1
      n += self.lengthString(len(self.socket_descriptor_))
    if (self.has_requested_events_):
      n += 1
      n += self.lengthVarInt64(self.requested_events_)
    if (self.has_observed_events_):
      n += 1
      n += self.lengthVarInt64(self.observed_events_)
    return n

  def Clear(self):
    self.clear_socket_descriptor()
    self.clear_requested_events()
    self.clear_observed_events()

  def OutputUnchecked(self, out):
    out.putVarInt32(10)
    out.putPrefixedString(self.socket_descriptor_)
    out.putVarInt32(16)
    out.putVarInt32(self.requested_events_)
    out.putVarInt32(24)
    out.putVarInt32(self.observed_events_)

  def OutputPartial(self, out):
    if (self.has_socket_descriptor_):
      out.putVarInt32(10)
      out.putPrefixedString(self.socket_descriptor_)
    if (self.has_requested_events_):
      out.putVarInt32(16)
      out.putVarInt32(self.requested_events_)
    if (self.has_observed_events_):
      out.putVarInt32(24)
      out.putVarInt32(self.observed_events_)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 10:
        self.set_socket_descriptor(d.getPrefixedString())
        continue
      if tt == 16:
        self.set_requested_events(d.getVarInt32())
        continue
      if tt == 24:
        self.set_observed_events(d.getVarInt32())
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    if self.has_socket_descriptor_: res+=prefix+("socket_descriptor: %s\n" % self.DebugFormatString(self.socket_descriptor_))
    if self.has_requested_events_: res+=prefix+("requested_events: %s\n" % self.DebugFormatInt32(self.requested_events_))
    if self.has_observed_events_: res+=prefix+("observed_events: %s\n" % self.DebugFormatInt32(self.observed_events_))
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  ksocket_descriptor = 1
  krequested_events = 2
  kobserved_events = 3

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "socket_descriptor",
    2: "requested_events",
    3: "observed_events",
  }, 3)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.STRING,
    2: ProtocolBuffer.Encoder.NUMERIC,
    3: ProtocolBuffer.Encoder.NUMERIC,
  }, 3, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("WjhhcHBob3N0aW5nL2FwaS9yZW1vdGVfc29ja2V0L3JlbW90ZV9zb2NrZXRfc2VydmljZS5wcm90bwoUYXBwaG9zdGluZy5Qb2xsRXZlbnQTGhFzb2NrZXRfZGVzY3JpcHRvciABKAIwCTgCFBMaEHJlcXVlc3RlZF9ldmVudHMgAigAMAU4AkIBMGgAowGqAQdkZWZhdWx0sgEPU09DS0VUX1BPTExOT05FpAEUExoPb2JzZXJ2ZWRfZXZlbnRzIAMoADAFOAJCATBoAKMBqgEHZGVmYXVsdLIBD1NPQ0tFVF9QT0xMTk9ORaQBFHN6DVBvbGxFdmVudEZsYWeLAZIBD1NPQ0tFVF9QT0xMTk9ORZgBAIwBiwGSAQ1TT0NLRVRfUE9MTElOmAEBjAGLAZIBDlNPQ0tFVF9QT0xMUFJJmAECjAGLAZIBDlNPQ0tFVF9QT0xMT1VUmAEEjAGLAZIBDlNPQ0tFVF9QT0xMRVJSmAEIjAGLAZIBDlNPQ0tFVF9QT0xMSFVQmAEQjAGLAZIBD1NPQ0tFVF9QT0xMTlZBTJgBIIwBiwGSARFTT0NLRVRfUE9MTFJETk9STZgBQIwBiwGSARFTT0NLRVRfUE9MTFJEQkFORJgBgAGMAYsBkgERU09DS0VUX1BPTExXUk5PUk2YAYACjAGLAZIBEVNPQ0tFVF9QT0xMV1JCQU5EmAGABIwBiwGSAQ5TT0NLRVRfUE9MTE1TR5gBgAiMAYsBkgERU09DS0VUX1BPTExSRU1PVkWYAYAgjAGLAZIBEFNPQ0tFVF9QT0xMUkRIVVCYAYBAjAF0wgEjYXBwaG9zdGluZy5SZW1vdGVTb2NrZXRTZXJ2aWNlRXJyb3I="))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class PollRequest(ProtocolBuffer.ProtocolMessage):
  has_timeout_seconds_ = 0
  timeout_seconds_ = -1.0

  def __init__(self, contents=None):
    self.events_ = []
    if contents is not None: self.MergeFromString(contents)

  def events_size(self): return len(self.events_)
  def events_list(self): return self.events_

  def events(self, i):
    return self.events_[i]

  def mutable_events(self, i):
    return self.events_[i]

  def add_events(self):
    x = PollEvent()
    self.events_.append(x)
    return x

  def clear_events(self):
    self.events_ = []
  def timeout_seconds(self): return self.timeout_seconds_

  def set_timeout_seconds(self, x):
    self.has_timeout_seconds_ = 1
    self.timeout_seconds_ = x

  def clear_timeout_seconds(self):
    if self.has_timeout_seconds_:
      self.has_timeout_seconds_ = 0
      self.timeout_seconds_ = -1.0

  def has_timeout_seconds(self): return self.has_timeout_seconds_


  def MergeFrom(self, x):
    assert x is not self
    for i in xrange(x.events_size()): self.add_events().CopyFrom(x.events(i))
    if (x.has_timeout_seconds()): self.set_timeout_seconds(x.timeout_seconds())

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.PollRequest', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.PollRequest')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.PollRequest')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.PollRequest', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.PollRequest', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.PollRequest', s)


  def Equals(self, x):
    if x is self: return 1
    if len(self.events_) != len(x.events_): return 0
    for e1, e2 in zip(self.events_, x.events_):
      if e1 != e2: return 0
    if self.has_timeout_seconds_ != x.has_timeout_seconds_: return 0
    if self.has_timeout_seconds_ and self.timeout_seconds_ != x.timeout_seconds_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    for p in self.events_:
      if not p.IsInitialized(debug_strs): initialized=0
    return initialized

  def ByteSize(self):
    n = 0
    n += 1 * len(self.events_)
    for i in xrange(len(self.events_)): n += self.lengthString(self.events_[i].ByteSize())
    if (self.has_timeout_seconds_): n += 9
    return n

  def ByteSizePartial(self):
    n = 0
    n += 1 * len(self.events_)
    for i in xrange(len(self.events_)): n += self.lengthString(self.events_[i].ByteSizePartial())
    if (self.has_timeout_seconds_): n += 9
    return n

  def Clear(self):
    self.clear_events()
    self.clear_timeout_seconds()

  def OutputUnchecked(self, out):
    for i in xrange(len(self.events_)):
      out.putVarInt32(10)
      out.putVarInt32(self.events_[i].ByteSize())
      self.events_[i].OutputUnchecked(out)
    if (self.has_timeout_seconds_):
      out.putVarInt32(17)
      out.putDouble(self.timeout_seconds_)

  def OutputPartial(self, out):
    for i in xrange(len(self.events_)):
      out.putVarInt32(10)
      out.putVarInt32(self.events_[i].ByteSizePartial())
      self.events_[i].OutputPartial(out)
    if (self.has_timeout_seconds_):
      out.putVarInt32(17)
      out.putDouble(self.timeout_seconds_)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 10:
        length = d.getVarInt32()
        tmp = ProtocolBuffer.Decoder(d.buffer(), d.pos(), d.pos() + length)
        d.skip(length)
        self.add_events().TryMerge(tmp)
        continue
      if tt == 17:
        self.set_timeout_seconds(d.getDouble())
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    cnt=0
    for e in self.events_:
      elm=""
      if printElemNumber: elm="(%d)" % cnt
      res+=prefix+("events%s <\n" % elm)
      res+=e.__str__(prefix + "  ", printElemNumber)
      res+=prefix+">\n"
      cnt+=1
    if self.has_timeout_seconds_: res+=prefix+("timeout_seconds: %s\n" % self.DebugFormat(self.timeout_seconds_))
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  kevents = 1
  ktimeout_seconds = 2

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "events",
    2: "timeout_seconds",
  }, 2)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.STRING,
    2: ProtocolBuffer.Encoder.DOUBLE,
  }, 2, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("WjhhcHBob3N0aW5nL2FwaS9yZW1vdGVfc29ja2V0L3JlbW90ZV9zb2NrZXRfc2VydmljZS5wcm90bwoWYXBwaG9zdGluZy5Qb2xsUmVxdWVzdBMaBmV2ZW50cyABKAIwCzgDShRhcHBob3N0aW5nLlBvbGxFdmVudBQTGg90aW1lb3V0X3NlY29uZHMgAigBMAE4AUIELTEuMKMBqgEHZGVmYXVsdLIBBC0xLjCkARTCASNhcHBob3N0aW5nLlJlbW90ZVNvY2tldFNlcnZpY2VFcnJvcg=="))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class PollReply(ProtocolBuffer.ProtocolMessage):

  def __init__(self, contents=None):
    self.events_ = []
    if contents is not None: self.MergeFromString(contents)

  def events_size(self): return len(self.events_)
  def events_list(self): return self.events_

  def events(self, i):
    return self.events_[i]

  def mutable_events(self, i):
    return self.events_[i]

  def add_events(self):
    x = PollEvent()
    self.events_.append(x)
    return x

  def clear_events(self):
    self.events_ = []

  def MergeFrom(self, x):
    assert x is not self
    for i in xrange(x.events_size()): self.add_events().CopyFrom(x.events(i))

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.PollReply', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.PollReply')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.PollReply')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.PollReply', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.PollReply', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.PollReply', s)


  def Equals(self, x):
    if x is self: return 1
    if len(self.events_) != len(x.events_): return 0
    for e1, e2 in zip(self.events_, x.events_):
      if e1 != e2: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    for p in self.events_:
      if not p.IsInitialized(debug_strs): initialized=0
    return initialized

  def ByteSize(self):
    n = 0
    n += 1 * len(self.events_)
    for i in xrange(len(self.events_)): n += self.lengthString(self.events_[i].ByteSize())
    return n

  def ByteSizePartial(self):
    n = 0
    n += 1 * len(self.events_)
    for i in xrange(len(self.events_)): n += self.lengthString(self.events_[i].ByteSizePartial())
    return n

  def Clear(self):
    self.clear_events()

  def OutputUnchecked(self, out):
    for i in xrange(len(self.events_)):
      out.putVarInt32(18)
      out.putVarInt32(self.events_[i].ByteSize())
      self.events_[i].OutputUnchecked(out)

  def OutputPartial(self, out):
    for i in xrange(len(self.events_)):
      out.putVarInt32(18)
      out.putVarInt32(self.events_[i].ByteSizePartial())
      self.events_[i].OutputPartial(out)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 18:
        length = d.getVarInt32()
        tmp = ProtocolBuffer.Decoder(d.buffer(), d.pos(), d.pos() + length)
        d.skip(length)
        self.add_events().TryMerge(tmp)
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    cnt=0
    for e in self.events_:
      elm=""
      if printElemNumber: elm="(%d)" % cnt
      res+=prefix+("events%s <\n" % elm)
      res+=e.__str__(prefix + "  ", printElemNumber)
      res+=prefix+">\n"
      cnt+=1
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  kevents = 2

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    2: "events",
  }, 2)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    2: ProtocolBuffer.Encoder.STRING,
  }, 2, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("WjhhcHBob3N0aW5nL2FwaS9yZW1vdGVfc29ja2V0L3JlbW90ZV9zb2NrZXRfc2VydmljZS5wcm90bwoUYXBwaG9zdGluZy5Qb2xsUmVwbHkTGgZldmVudHMgAigCMAs4A0oUYXBwaG9zdGluZy5Qb2xsRXZlbnQUwgEjYXBwaG9zdGluZy5SZW1vdGVTb2NrZXRTZXJ2aWNlRXJyb3I="))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class UpdateSessionRequest(ProtocolBuffer.ProtocolMessage):
  has_timeout_seconds_ = 0
  timeout_seconds_ = 120.0

  def __init__(self, contents=None):
    self.socket_descriptor_ = []
    if contents is not None: self.MergeFromString(contents)

  def socket_descriptor_size(self): return len(self.socket_descriptor_)
  def socket_descriptor_list(self): return self.socket_descriptor_

  def socket_descriptor(self, i):
    return self.socket_descriptor_[i]

  def set_socket_descriptor(self, i, x):
    self.socket_descriptor_[i] = x

  def add_socket_descriptor(self, x):
    self.socket_descriptor_.append(x)

  def clear_socket_descriptor(self):
    self.socket_descriptor_ = []

  def timeout_seconds(self): return self.timeout_seconds_

  def set_timeout_seconds(self, x):
    self.has_timeout_seconds_ = 1
    self.timeout_seconds_ = x

  def clear_timeout_seconds(self):
    if self.has_timeout_seconds_:
      self.has_timeout_seconds_ = 0
      self.timeout_seconds_ = 120.0

  def has_timeout_seconds(self): return self.has_timeout_seconds_


  def MergeFrom(self, x):
    assert x is not self
    for i in xrange(x.socket_descriptor_size()): self.add_socket_descriptor(x.socket_descriptor(i))
    if (x.has_timeout_seconds()): self.set_timeout_seconds(x.timeout_seconds())

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.UpdateSessionRequest', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.UpdateSessionRequest')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.UpdateSessionRequest')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.UpdateSessionRequest', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.UpdateSessionRequest', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.UpdateSessionRequest', s)


  def Equals(self, x):
    if x is self: return 1
    if len(self.socket_descriptor_) != len(x.socket_descriptor_): return 0
    for e1, e2 in zip(self.socket_descriptor_, x.socket_descriptor_):
      if e1 != e2: return 0
    if self.has_timeout_seconds_ != x.has_timeout_seconds_: return 0
    if self.has_timeout_seconds_ and self.timeout_seconds_ != x.timeout_seconds_: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    return initialized

  def ByteSize(self):
    n = 0
    n += 1 * len(self.socket_descriptor_)
    for i in xrange(len(self.socket_descriptor_)): n += self.lengthString(len(self.socket_descriptor_[i]))
    if (self.has_timeout_seconds_): n += 9
    return n

  def ByteSizePartial(self):
    n = 0
    n += 1 * len(self.socket_descriptor_)
    for i in xrange(len(self.socket_descriptor_)): n += self.lengthString(len(self.socket_descriptor_[i]))
    if (self.has_timeout_seconds_): n += 9
    return n

  def Clear(self):
    self.clear_socket_descriptor()
    self.clear_timeout_seconds()

  def OutputUnchecked(self, out):
    for i in xrange(len(self.socket_descriptor_)):
      out.putVarInt32(10)
      out.putPrefixedString(self.socket_descriptor_[i])
    if (self.has_timeout_seconds_):
      out.putVarInt32(17)
      out.putDouble(self.timeout_seconds_)

  def OutputPartial(self, out):
    for i in xrange(len(self.socket_descriptor_)):
      out.putVarInt32(10)
      out.putPrefixedString(self.socket_descriptor_[i])
    if (self.has_timeout_seconds_):
      out.putVarInt32(17)
      out.putDouble(self.timeout_seconds_)

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 10:
        self.add_socket_descriptor(d.getPrefixedString())
        continue
      if tt == 17:
        self.set_timeout_seconds(d.getDouble())
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    cnt=0
    for e in self.socket_descriptor_:
      elm=""
      if printElemNumber: elm="(%d)" % cnt
      res+=prefix+("socket_descriptor%s: %s\n" % (elm, self.DebugFormatString(e)))
      cnt+=1
    if self.has_timeout_seconds_: res+=prefix+("timeout_seconds: %s\n" % self.DebugFormat(self.timeout_seconds_))
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  ksocket_descriptor = 1
  ktimeout_seconds = 2

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "socket_descriptor",
    2: "timeout_seconds",
  }, 2)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.STRING,
    2: ProtocolBuffer.Encoder.DOUBLE,
  }, 2, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("WjhhcHBob3N0aW5nL2FwaS9yZW1vdGVfc29ja2V0L3JlbW90ZV9zb2NrZXRfc2VydmljZS5wcm90bwofYXBwaG9zdGluZy5VcGRhdGVTZXNzaW9uUmVxdWVzdBMaEXNvY2tldF9kZXNjcmlwdG9yIAEoAjAJOAMUExoPdGltZW91dF9zZWNvbmRzIAIoATABOAFCBTEyMC4wowGqAQdkZWZhdWx0sgEFMTIwLjCkARTCASNhcHBob3N0aW5nLlJlbW90ZVNvY2tldFNlcnZpY2VFcnJvcg=="))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class UpdateSessionReply(ProtocolBuffer.ProtocolMessage):

  def __init__(self, contents=None):
    pass
    if contents is not None: self.MergeFromString(contents)


  def MergeFrom(self, x):
    assert x is not self

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.UpdateSessionReply', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.UpdateSessionReply')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.UpdateSessionReply')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.UpdateSessionReply', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.UpdateSessionReply', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.UpdateSessionReply', s)


  def Equals(self, x):
    if x is self: return 1
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    return initialized

  def ByteSize(self):
    n = 0
    return n

  def ByteSizePartial(self):
    n = 0
    return n

  def Clear(self):
    pass

  def OutputUnchecked(self, out):
    pass

  def OutputPartial(self, out):
    pass

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])


  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
  }, 0)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
  }, 0, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("WjhhcHBob3N0aW5nL2FwaS9yZW1vdGVfc29ja2V0L3JlbW90ZV9zb2NrZXRfc2VydmljZS5wcm90bwodYXBwaG9zdGluZy5VcGRhdGVTZXNzaW9uUmVwbHnCASNhcHBob3N0aW5nLlJlbW90ZVNvY2tldFNlcnZpY2VFcnJvcg=="))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class ResolveRequest(ProtocolBuffer.ProtocolMessage):
  has_name_ = 0
  name_ = ""

  def __init__(self, contents=None):
    self.address_families_ = []
    if contents is not None: self.MergeFromString(contents)

  def name(self): return self.name_

  def set_name(self, x):
    self.has_name_ = 1
    self.name_ = x

  def clear_name(self):
    if self.has_name_:
      self.has_name_ = 0
      self.name_ = ""

  def has_name(self): return self.has_name_

  def address_families_size(self): return len(self.address_families_)
  def address_families_list(self): return self.address_families_

  def address_families(self, i):
    return self.address_families_[i]

  def set_address_families(self, i, x):
    self.address_families_[i] = x

  def add_address_families(self, x):
    self.address_families_.append(x)

  def clear_address_families(self):
    self.address_families_ = []


  def MergeFrom(self, x):
    assert x is not self
    if (x.has_name()): self.set_name(x.name())
    for i in xrange(x.address_families_size()): self.add_address_families(x.address_families(i))

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.ResolveRequest', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.ResolveRequest')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.ResolveRequest')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.ResolveRequest', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.ResolveRequest', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.ResolveRequest', s)


  def Equals(self, x):
    if x is self: return 1
    if self.has_name_ != x.has_name_: return 0
    if self.has_name_ and self.name_ != x.name_: return 0
    if len(self.address_families_) != len(x.address_families_): return 0
    for e1, e2 in zip(self.address_families_, x.address_families_):
      if e1 != e2: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    if (not self.has_name_):
      initialized = 0
      if debug_strs is not None:
        debug_strs.append('Required field: name not set.')
    return initialized

  def ByteSize(self):
    n = 0
    n += self.lengthString(len(self.name_))
    n += 1 * len(self.address_families_)
    for i in xrange(len(self.address_families_)): n += self.lengthVarInt64(self.address_families_[i])
    return n + 1

  def ByteSizePartial(self):
    n = 0
    if (self.has_name_):
      n += 1
      n += self.lengthString(len(self.name_))
    n += 1 * len(self.address_families_)
    for i in xrange(len(self.address_families_)): n += self.lengthVarInt64(self.address_families_[i])
    return n

  def Clear(self):
    self.clear_name()
    self.clear_address_families()

  def OutputUnchecked(self, out):
    out.putVarInt32(10)
    out.putPrefixedString(self.name_)
    for i in xrange(len(self.address_families_)):
      out.putVarInt32(16)
      out.putVarInt32(self.address_families_[i])

  def OutputPartial(self, out):
    if (self.has_name_):
      out.putVarInt32(10)
      out.putPrefixedString(self.name_)
    for i in xrange(len(self.address_families_)):
      out.putVarInt32(16)
      out.putVarInt32(self.address_families_[i])

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 10:
        self.set_name(d.getPrefixedString())
        continue
      if tt == 16:
        self.add_address_families(d.getVarInt32())
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    if self.has_name_: res+=prefix+("name: %s\n" % self.DebugFormatString(self.name_))
    cnt=0
    for e in self.address_families_:
      elm=""
      if printElemNumber: elm="(%d)" % cnt
      res+=prefix+("address_families%s: %s\n" % (elm, self.DebugFormatInt32(e)))
      cnt+=1
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  kname = 1
  kaddress_families = 2

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    1: "name",
    2: "address_families",
  }, 2)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    1: ProtocolBuffer.Encoder.STRING,
    2: ProtocolBuffer.Encoder.NUMERIC,
  }, 2, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("WjhhcHBob3N0aW5nL2FwaS9yZW1vdGVfc29ja2V0L3JlbW90ZV9zb2NrZXRfc2VydmljZS5wcm90bwoZYXBwaG9zdGluZy5SZXNvbHZlUmVxdWVzdBMaBG5hbWUgASgCMAk4AhQTGhBhZGRyZXNzX2ZhbWlsaWVzIAIoADAFOAMUwgEjYXBwaG9zdGluZy5SZW1vdGVTb2NrZXRTZXJ2aWNlRXJyb3I="))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())

class ResolveReply(ProtocolBuffer.ProtocolMessage):


  SOCKET_EAI_ADDRFAMILY =    1
  SOCKET_EAI_AGAIN =    2
  SOCKET_EAI_BADFLAGS =    3
  SOCKET_EAI_FAIL =    4
  SOCKET_EAI_FAMILY =    5
  SOCKET_EAI_MEMORY =    6
  SOCKET_EAI_NODATA =    7
  SOCKET_EAI_NONAME =    8
  SOCKET_EAI_SERVICE =    9
  SOCKET_EAI_SOCKTYPE =   10
  SOCKET_EAI_SYSTEM =   11
  SOCKET_EAI_BADHINTS =   12
  SOCKET_EAI_PROTOCOL =   13
  SOCKET_EAI_OVERFLOW =   14
  SOCKET_EAI_MAX =   15

  _ErrorCode_NAMES = {
    1: "SOCKET_EAI_ADDRFAMILY",
    2: "SOCKET_EAI_AGAIN",
    3: "SOCKET_EAI_BADFLAGS",
    4: "SOCKET_EAI_FAIL",
    5: "SOCKET_EAI_FAMILY",
    6: "SOCKET_EAI_MEMORY",
    7: "SOCKET_EAI_NODATA",
    8: "SOCKET_EAI_NONAME",
    9: "SOCKET_EAI_SERVICE",
    10: "SOCKET_EAI_SOCKTYPE",
    11: "SOCKET_EAI_SYSTEM",
    12: "SOCKET_EAI_BADHINTS",
    13: "SOCKET_EAI_PROTOCOL",
    14: "SOCKET_EAI_OVERFLOW",
    15: "SOCKET_EAI_MAX",
  }

  def ErrorCode_Name(cls, x): return cls._ErrorCode_NAMES.get(x, "")
  ErrorCode_Name = classmethod(ErrorCode_Name)

  has_canonical_name_ = 0
  canonical_name_ = ""

  def __init__(self, contents=None):
    self.packed_address_ = []
    self.aliases_ = []
    if contents is not None: self.MergeFromString(contents)

  def packed_address_size(self): return len(self.packed_address_)
  def packed_address_list(self): return self.packed_address_

  def packed_address(self, i):
    return self.packed_address_[i]

  def set_packed_address(self, i, x):
    self.packed_address_[i] = x

  def add_packed_address(self, x):
    self.packed_address_.append(x)

  def clear_packed_address(self):
    self.packed_address_ = []

  def canonical_name(self): return self.canonical_name_

  def set_canonical_name(self, x):
    self.has_canonical_name_ = 1
    self.canonical_name_ = x

  def clear_canonical_name(self):
    if self.has_canonical_name_:
      self.has_canonical_name_ = 0
      self.canonical_name_ = ""

  def has_canonical_name(self): return self.has_canonical_name_

  def aliases_size(self): return len(self.aliases_)
  def aliases_list(self): return self.aliases_

  def aliases(self, i):
    return self.aliases_[i]

  def set_aliases(self, i, x):
    self.aliases_[i] = x

  def add_aliases(self, x):
    self.aliases_.append(x)

  def clear_aliases(self):
    self.aliases_ = []


  def MergeFrom(self, x):
    assert x is not self
    for i in xrange(x.packed_address_size()): self.add_packed_address(x.packed_address(i))
    if (x.has_canonical_name()): self.set_canonical_name(x.canonical_name())
    for i in xrange(x.aliases_size()): self.add_aliases(x.aliases(i))

  if _net_proto___parse__python is not None:
    def _CMergeFromString(self, s):
      _net_proto___parse__python.MergeFromString(self, 'apphosting.ResolveReply', s)

  if _net_proto___parse__python is not None:
    def _CEncode(self):
      return _net_proto___parse__python.Encode(self, 'apphosting.ResolveReply')

  if _net_proto___parse__python is not None:
    def _CEncodePartial(self):
      return _net_proto___parse__python.EncodePartial(self, 'apphosting.ResolveReply')

  if _net_proto___parse__python is not None:
    def _CToASCII(self, output_format):
      return _net_proto___parse__python.ToASCII(self, 'apphosting.ResolveReply', output_format)


  if _net_proto___parse__python is not None:
    def ParseASCII(self, s):
      _net_proto___parse__python.ParseASCII(self, 'apphosting.ResolveReply', s)


  if _net_proto___parse__python is not None:
    def ParseASCIIIgnoreUnknown(self, s):
      _net_proto___parse__python.ParseASCIIIgnoreUnknown(self, 'apphosting.ResolveReply', s)


  def Equals(self, x):
    if x is self: return 1
    if len(self.packed_address_) != len(x.packed_address_): return 0
    for e1, e2 in zip(self.packed_address_, x.packed_address_):
      if e1 != e2: return 0
    if self.has_canonical_name_ != x.has_canonical_name_: return 0
    if self.has_canonical_name_ and self.canonical_name_ != x.canonical_name_: return 0
    if len(self.aliases_) != len(x.aliases_): return 0
    for e1, e2 in zip(self.aliases_, x.aliases_):
      if e1 != e2: return 0
    return 1

  def IsInitialized(self, debug_strs=None):
    initialized = 1
    return initialized

  def ByteSize(self):
    n = 0
    n += 1 * len(self.packed_address_)
    for i in xrange(len(self.packed_address_)): n += self.lengthString(len(self.packed_address_[i]))
    if (self.has_canonical_name_): n += 1 + self.lengthString(len(self.canonical_name_))
    n += 1 * len(self.aliases_)
    for i in xrange(len(self.aliases_)): n += self.lengthString(len(self.aliases_[i]))
    return n

  def ByteSizePartial(self):
    n = 0
    n += 1 * len(self.packed_address_)
    for i in xrange(len(self.packed_address_)): n += self.lengthString(len(self.packed_address_[i]))
    if (self.has_canonical_name_): n += 1 + self.lengthString(len(self.canonical_name_))
    n += 1 * len(self.aliases_)
    for i in xrange(len(self.aliases_)): n += self.lengthString(len(self.aliases_[i]))
    return n

  def Clear(self):
    self.clear_packed_address()
    self.clear_canonical_name()
    self.clear_aliases()

  def OutputUnchecked(self, out):
    for i in xrange(len(self.packed_address_)):
      out.putVarInt32(18)
      out.putPrefixedString(self.packed_address_[i])
    if (self.has_canonical_name_):
      out.putVarInt32(26)
      out.putPrefixedString(self.canonical_name_)
    for i in xrange(len(self.aliases_)):
      out.putVarInt32(34)
      out.putPrefixedString(self.aliases_[i])

  def OutputPartial(self, out):
    for i in xrange(len(self.packed_address_)):
      out.putVarInt32(18)
      out.putPrefixedString(self.packed_address_[i])
    if (self.has_canonical_name_):
      out.putVarInt32(26)
      out.putPrefixedString(self.canonical_name_)
    for i in xrange(len(self.aliases_)):
      out.putVarInt32(34)
      out.putPrefixedString(self.aliases_[i])

  def TryMerge(self, d):
    while d.avail() > 0:
      tt = d.getVarInt32()
      if tt == 18:
        self.add_packed_address(d.getPrefixedString())
        continue
      if tt == 26:
        self.set_canonical_name(d.getPrefixedString())
        continue
      if tt == 34:
        self.add_aliases(d.getPrefixedString())
        continue


      if (tt == 0): raise ProtocolBuffer.ProtocolBufferDecodeError
      d.skipData(tt)


  def __str__(self, prefix="", printElemNumber=0):
    res=""
    cnt=0
    for e in self.packed_address_:
      elm=""
      if printElemNumber: elm="(%d)" % cnt
      res+=prefix+("packed_address%s: %s\n" % (elm, self.DebugFormatString(e)))
      cnt+=1
    if self.has_canonical_name_: res+=prefix+("canonical_name: %s\n" % self.DebugFormatString(self.canonical_name_))
    cnt=0
    for e in self.aliases_:
      elm=""
      if printElemNumber: elm="(%d)" % cnt
      res+=prefix+("aliases%s: %s\n" % (elm, self.DebugFormatString(e)))
      cnt+=1
    return res


  def _BuildTagLookupTable(sparse, maxtag, default=None):
    return tuple([sparse.get(i, default) for i in xrange(0, 1+maxtag)])

  kpacked_address = 2
  kcanonical_name = 3
  kaliases = 4

  _TEXT = _BuildTagLookupTable({
    0: "ErrorCode",
    2: "packed_address",
    3: "canonical_name",
    4: "aliases",
  }, 4)

  _TYPES = _BuildTagLookupTable({
    0: ProtocolBuffer.Encoder.NUMERIC,
    2: ProtocolBuffer.Encoder.STRING,
    3: ProtocolBuffer.Encoder.STRING,
    4: ProtocolBuffer.Encoder.STRING,
  }, 4, ProtocolBuffer.Encoder.MAX_TYPE)


  _STYLE = """"""
  _STYLE_CONTENT_TYPE = """"""
  _SERIALIZED_DESCRIPTOR = array.array('B')
  _SERIALIZED_DESCRIPTOR.fromstring(base64.decodestring("WjhhcHBob3N0aW5nL2FwaS9yZW1vdGVfc29ja2V0L3JlbW90ZV9zb2NrZXRfc2VydmljZS5wcm90bwoXYXBwaG9zdGluZy5SZXNvbHZlUmVwbHkTGg5wYWNrZWRfYWRkcmVzcyACKAIwCTgDFBMaDmNhbm9uaWNhbF9uYW1lIAMoAjAJOAEUExoHYWxpYXNlcyAEKAIwCTgDFHN6CUVycm9yQ29kZYsBkgEVU09DS0VUX0VBSV9BRERSRkFNSUxZmAEBjAGLAZIBEFNPQ0tFVF9FQUlfQUdBSU6YAQKMAYsBkgETU09DS0VUX0VBSV9CQURGTEFHU5gBA4wBiwGSAQ9TT0NLRVRfRUFJX0ZBSUyYAQSMAYsBkgERU09DS0VUX0VBSV9GQU1JTFmYAQWMAYsBkgERU09DS0VUX0VBSV9NRU1PUlmYAQaMAYsBkgERU09DS0VUX0VBSV9OT0RBVEGYAQeMAYsBkgERU09DS0VUX0VBSV9OT05BTUWYAQiMAYsBkgESU09DS0VUX0VBSV9TRVJWSUNFmAEJjAGLAZIBE1NPQ0tFVF9FQUlfU09DS1RZUEWYAQqMAYsBkgERU09DS0VUX0VBSV9TWVNURU2YAQuMAYsBkgETU09DS0VUX0VBSV9CQURISU5UU5gBDIwBiwGSARNTT0NLRVRfRUFJX1BST1RPQ09MmAENjAGLAZIBE1NPQ0tFVF9FQUlfT1ZFUkZMT1eYAQ6MAYsBkgEOU09DS0VUX0VBSV9NQViYAQ+MAXTCASNhcHBob3N0aW5nLlJlbW90ZVNvY2tldFNlcnZpY2VFcnJvcg=="))
  if _net_proto___parse__python is not None:
    _net_proto___parse__python.RegisterType(
        _SERIALIZED_DESCRIPTOR.tostring())



class _RemoteSocketService_ClientBaseStub(_client_stub_base_class):
  """Makes Stubby RPC calls to a RemoteSocketService server."""

  __slots__ = (
      '_protorpc_CreateSocket', '_full_name_CreateSocket',
      '_protorpc_Bind', '_full_name_Bind',
      '_protorpc_GetSocketName', '_full_name_GetSocketName',
      '_protorpc_GetPeerName', '_full_name_GetPeerName',
      '_protorpc_SetSocketOptions', '_full_name_SetSocketOptions',
      '_protorpc_GetSocketOptions', '_full_name_GetSocketOptions',
      '_protorpc_Connect', '_full_name_Connect',
      '_protorpc_Listen', '_full_name_Listen',
      '_protorpc_Accept', '_full_name_Accept',
      '_protorpc_ShutDown', '_full_name_ShutDown',
      '_protorpc_Close', '_full_name_Close',
      '_protorpc_Send', '_full_name_Send',
      '_protorpc_Receive', '_full_name_Receive',
      '_protorpc_Poll', '_full_name_Poll',
      '_protorpc_UpdateSession', '_full_name_UpdateSession',
      '_protorpc_Resolve', '_full_name_Resolve',
  )

  def __init__(self, rpc_stub):
    self._stub = rpc_stub

    self._protorpc_CreateSocket = pywraprpc.RPC()
    self._full_name_CreateSocket = self._stub.GetFullMethodName(
        'CreateSocket')

    self._protorpc_Bind = pywraprpc.RPC()
    self._full_name_Bind = self._stub.GetFullMethodName(
        'Bind')

    self._protorpc_GetSocketName = pywraprpc.RPC()
    self._full_name_GetSocketName = self._stub.GetFullMethodName(
        'GetSocketName')

    self._protorpc_GetPeerName = pywraprpc.RPC()
    self._full_name_GetPeerName = self._stub.GetFullMethodName(
        'GetPeerName')

    self._protorpc_SetSocketOptions = pywraprpc.RPC()
    self._full_name_SetSocketOptions = self._stub.GetFullMethodName(
        'SetSocketOptions')

    self._protorpc_GetSocketOptions = pywraprpc.RPC()
    self._full_name_GetSocketOptions = self._stub.GetFullMethodName(
        'GetSocketOptions')

    self._protorpc_Connect = pywraprpc.RPC()
    self._full_name_Connect = self._stub.GetFullMethodName(
        'Connect')

    self._protorpc_Listen = pywraprpc.RPC()
    self._full_name_Listen = self._stub.GetFullMethodName(
        'Listen')

    self._protorpc_Accept = pywraprpc.RPC()
    self._full_name_Accept = self._stub.GetFullMethodName(
        'Accept')

    self._protorpc_ShutDown = pywraprpc.RPC()
    self._full_name_ShutDown = self._stub.GetFullMethodName(
        'ShutDown')

    self._protorpc_Close = pywraprpc.RPC()
    self._full_name_Close = self._stub.GetFullMethodName(
        'Close')

    self._protorpc_Send = pywraprpc.RPC()
    self._full_name_Send = self._stub.GetFullMethodName(
        'Send')

    self._protorpc_Receive = pywraprpc.RPC()
    self._full_name_Receive = self._stub.GetFullMethodName(
        'Receive')

    self._protorpc_Poll = pywraprpc.RPC()
    self._full_name_Poll = self._stub.GetFullMethodName(
        'Poll')

    self._protorpc_UpdateSession = pywraprpc.RPC()
    self._full_name_UpdateSession = self._stub.GetFullMethodName(
        'UpdateSession')

    self._protorpc_Resolve = pywraprpc.RPC()
    self._full_name_Resolve = self._stub.GetFullMethodName(
        'Resolve')

  def CreateSocket(self, request, rpc=None, callback=None, response=None):
    """Make a CreateSocket RPC call.

    Args:
      request: a CreateSocketRequest instance.
      rpc: Optional RPC instance to use for the call.
      callback: Optional final callback. Will be called as
          callback(rpc, result) when the rpc completes. If None, the
          call is synchronous.
      response: Optional ProtocolMessage to be filled in with response.

    Returns:
      The CreateSocketReply if callback is None. Otherwise, returns None.
    """

    if response is None:
      response = CreateSocketReply
    return self._MakeCall(rpc,
                          self._full_name_CreateSocket,
                          'CreateSocket',
                          request,
                          response,
                          callback,
                          self._protorpc_CreateSocket)

  def Bind(self, request, rpc=None, callback=None, response=None):
    """Make a Bind RPC call.

    Args:
      request: a BindRequest instance.
      rpc: Optional RPC instance to use for the call.
      callback: Optional final callback. Will be called as
          callback(rpc, result) when the rpc completes. If None, the
          call is synchronous.
      response: Optional ProtocolMessage to be filled in with response.

    Returns:
      The BindReply if callback is None. Otherwise, returns None.
    """

    if response is None:
      response = BindReply
    return self._MakeCall(rpc,
                          self._full_name_Bind,
                          'Bind',
                          request,
                          response,
                          callback,
                          self._protorpc_Bind)

  def GetSocketName(self, request, rpc=None, callback=None, response=None):
    """Make a GetSocketName RPC call.

    Args:
      request: a GetSocketNameRequest instance.
      rpc: Optional RPC instance to use for the call.
      callback: Optional final callback. Will be called as
          callback(rpc, result) when the rpc completes. If None, the
          call is synchronous.
      response: Optional ProtocolMessage to be filled in with response.

    Returns:
      The GetSocketNameReply if callback is None. Otherwise, returns None.
    """

    if response is None:
      response = GetSocketNameReply
    return self._MakeCall(rpc,
                          self._full_name_GetSocketName,
                          'GetSocketName',
                          request,
                          response,
                          callback,
                          self._protorpc_GetSocketName)

  def GetPeerName(self, request, rpc=None, callback=None, response=None):
    """Make a GetPeerName RPC call.

    Args:
      request: a GetPeerNameRequest instance.
      rpc: Optional RPC instance to use for the call.
      callback: Optional final callback. Will be called as
          callback(rpc, result) when the rpc completes. If None, the
          call is synchronous.
      response: Optional ProtocolMessage to be filled in with response.

    Returns:
      The GetPeerNameReply if callback is None. Otherwise, returns None.
    """

    if response is None:
      response = GetPeerNameReply
    return self._MakeCall(rpc,
                          self._full_name_GetPeerName,
                          'GetPeerName',
                          request,
                          response,
                          callback,
                          self._protorpc_GetPeerName)

  def SetSocketOptions(self, request, rpc=None, callback=None, response=None):
    """Make a SetSocketOptions RPC call.

    Args:
      request: a SetSocketOptionsRequest instance.
      rpc: Optional RPC instance to use for the call.
      callback: Optional final callback. Will be called as
          callback(rpc, result) when the rpc completes. If None, the
          call is synchronous.
      response: Optional ProtocolMessage to be filled in with response.

    Returns:
      The SetSocketOptionsReply if callback is None. Otherwise, returns None.
    """

    if response is None:
      response = SetSocketOptionsReply
    return self._MakeCall(rpc,
                          self._full_name_SetSocketOptions,
                          'SetSocketOptions',
                          request,
                          response,
                          callback,
                          self._protorpc_SetSocketOptions)

  def GetSocketOptions(self, request, rpc=None, callback=None, response=None):
    """Make a GetSocketOptions RPC call.

    Args:
      request: a GetSocketOptionsRequest instance.
      rpc: Optional RPC instance to use for the call.
      callback: Optional final callback. Will be called as
          callback(rpc, result) when the rpc completes. If None, the
          call is synchronous.
      response: Optional ProtocolMessage to be filled in with response.

    Returns:
      The GetSocketOptionsReply if callback is None. Otherwise, returns None.
    """

    if response is None:
      response = GetSocketOptionsReply
    return self._MakeCall(rpc,
                          self._full_name_GetSocketOptions,
                          'GetSocketOptions',
                          request,
                          response,
                          callback,
                          self._protorpc_GetSocketOptions)

  def Connect(self, request, rpc=None, callback=None, response=None):
    """Make a Connect RPC call.

    Args:
      request: a ConnectRequest instance.
      rpc: Optional RPC instance to use for the call.
      callback: Optional final callback. Will be called as
          callback(rpc, result) when the rpc completes. If None, the
          call is synchronous.
      response: Optional ProtocolMessage to be filled in with response.

    Returns:
      The ConnectReply if callback is None. Otherwise, returns None.
    """

    if response is None:
      response = ConnectReply
    return self._MakeCall(rpc,
                          self._full_name_Connect,
                          'Connect',
                          request,
                          response,
                          callback,
                          self._protorpc_Connect)

  def Listen(self, request, rpc=None, callback=None, response=None):
    """Make a Listen RPC call.

    Args:
      request: a ListenRequest instance.
      rpc: Optional RPC instance to use for the call.
      callback: Optional final callback. Will be called as
          callback(rpc, result) when the rpc completes. If None, the
          call is synchronous.
      response: Optional ProtocolMessage to be filled in with response.

    Returns:
      The ListenReply if callback is None. Otherwise, returns None.
    """

    if response is None:
      response = ListenReply
    return self._MakeCall(rpc,
                          self._full_name_Listen,
                          'Listen',
                          request,
                          response,
                          callback,
                          self._protorpc_Listen)

  def Accept(self, request, rpc=None, callback=None, response=None):
    """Make a Accept RPC call.

    Args:
      request: a AcceptRequest instance.
      rpc: Optional RPC instance to use for the call.
      callback: Optional final callback. Will be called as
          callback(rpc, result) when the rpc completes. If None, the
          call is synchronous.
      response: Optional ProtocolMessage to be filled in with response.

    Returns:
      The AcceptReply if callback is None. Otherwise, returns None.
    """

    if response is None:
      response = AcceptReply
    return self._MakeCall(rpc,
                          self._full_name_Accept,
                          'Accept',
                          request,
                          response,
                          callback,
                          self._protorpc_Accept)

  def ShutDown(self, request, rpc=None, callback=None, response=None):
    """Make a ShutDown RPC call.

    Args:
      request: a ShutDownRequest instance.
      rpc: Optional RPC instance to use for the call.
      callback: Optional final callback. Will be called as
          callback(rpc, result) when the rpc completes. If None, the
          call is synchronous.
      response: Optional ProtocolMessage to be filled in with response.

    Returns:
      The ShutDownReply if callback is None. Otherwise, returns None.
    """

    if response is None:
      response = ShutDownReply
    return self._MakeCall(rpc,
                          self._full_name_ShutDown,
                          'ShutDown',
                          request,
                          response,
                          callback,
                          self._protorpc_ShutDown)

  def Close(self, request, rpc=None, callback=None, response=None):
    """Make a Close RPC call.

    Args:
      request: a CloseRequest instance.
      rpc: Optional RPC instance to use for the call.
      callback: Optional final callback. Will be called as
          callback(rpc, result) when the rpc completes. If None, the
          call is synchronous.
      response: Optional ProtocolMessage to be filled in with response.

    Returns:
      The CloseReply if callback is None. Otherwise, returns None.
    """

    if response is None:
      response = CloseReply
    return self._MakeCall(rpc,
                          self._full_name_Close,
                          'Close',
                          request,
                          response,
                          callback,
                          self._protorpc_Close)

  def Send(self, request, rpc=None, callback=None, response=None):
    """Make a Send RPC call.

    Args:
      request: a SendRequest instance.
      rpc: Optional RPC instance to use for the call.
      callback: Optional final callback. Will be called as
          callback(rpc, result) when the rpc completes. If None, the
          call is synchronous.
      response: Optional ProtocolMessage to be filled in with response.

    Returns:
      The SendReply if callback is None. Otherwise, returns None.
    """

    if response is None:
      response = SendReply
    return self._MakeCall(rpc,
                          self._full_name_Send,
                          'Send',
                          request,
                          response,
                          callback,
                          self._protorpc_Send)

  def Receive(self, request, rpc=None, callback=None, response=None):
    """Make a Receive RPC call.

    Args:
      request: a ReceiveRequest instance.
      rpc: Optional RPC instance to use for the call.
      callback: Optional final callback. Will be called as
          callback(rpc, result) when the rpc completes. If None, the
          call is synchronous.
      response: Optional ProtocolMessage to be filled in with response.

    Returns:
      The ReceiveReply if callback is None. Otherwise, returns None.
    """

    if response is None:
      response = ReceiveReply
    return self._MakeCall(rpc,
                          self._full_name_Receive,
                          'Receive',
                          request,
                          response,
                          callback,
                          self._protorpc_Receive)

  def Poll(self, request, rpc=None, callback=None, response=None):
    """Make a Poll RPC call.

    Args:
      request: a PollRequest instance.
      rpc: Optional RPC instance to use for the call.
      callback: Optional final callback. Will be called as
          callback(rpc, result) when the rpc completes. If None, the
          call is synchronous.
      response: Optional ProtocolMessage to be filled in with response.

    Returns:
      The PollReply if callback is None. Otherwise, returns None.
    """

    if response is None:
      response = PollReply
    return self._MakeCall(rpc,
                          self._full_name_Poll,
                          'Poll',
                          request,
                          response,
                          callback,
                          self._protorpc_Poll)

  def UpdateSession(self, request, rpc=None, callback=None, response=None):
    """Make a UpdateSession RPC call.

    Args:
      request: a UpdateSessionRequest instance.
      rpc: Optional RPC instance to use for the call.
      callback: Optional final callback. Will be called as
          callback(rpc, result) when the rpc completes. If None, the
          call is synchronous.
      response: Optional ProtocolMessage to be filled in with response.

    Returns:
      The UpdateSessionReply if callback is None. Otherwise, returns None.
    """

    if response is None:
      response = UpdateSessionReply
    return self._MakeCall(rpc,
                          self._full_name_UpdateSession,
                          'UpdateSession',
                          request,
                          response,
                          callback,
                          self._protorpc_UpdateSession)

  def Resolve(self, request, rpc=None, callback=None, response=None):
    """Make a Resolve RPC call.

    Args:
      request: a ResolveRequest instance.
      rpc: Optional RPC instance to use for the call.
      callback: Optional final callback. Will be called as
          callback(rpc, result) when the rpc completes. If None, the
          call is synchronous.
      response: Optional ProtocolMessage to be filled in with response.

    Returns:
      The ResolveReply if callback is None. Otherwise, returns None.
    """

    if response is None:
      response = ResolveReply
    return self._MakeCall(rpc,
                          self._full_name_Resolve,
                          'Resolve',
                          request,
                          response,
                          callback,
                          self._protorpc_Resolve)


class _RemoteSocketService_ClientStub(_RemoteSocketService_ClientBaseStub):
  def __init__(self, rpc_stub_parameters, service_name):
    if service_name is None:
      service_name = 'RemoteSocketService'
    _RemoteSocketService_ClientBaseStub.__init__(self, pywraprpc.RPC_GenericStub(service_name, rpc_stub_parameters))
    self._params = rpc_stub_parameters


class _RemoteSocketService_RPC2ClientStub(_RemoteSocketService_ClientBaseStub):
  def __init__(self, server, channel, service_name):
    if service_name is None:
      service_name = 'RemoteSocketService'
    if channel is not None:
      if channel.version() == 1:
        raise RuntimeError('Expecting an RPC2 channel to create the stub')
      _RemoteSocketService_ClientBaseStub.__init__(self, pywraprpc.RPC_GenericStub(service_name, channel))
    elif server is not None:
      _RemoteSocketService_ClientBaseStub.__init__(self, pywraprpc.RPC_GenericStub(service_name, pywraprpc.NewClientChannel(server)))
    else:
      raise RuntimeError('Invalid argument combination to create a stub')


class RemoteSocketService(_server_stub_base_class):
  """Base class for RemoteSocketService Stubby servers."""

  def __init__(self, *args, **kwargs):
    """Creates a Stubby RPC server.

    See BaseRpcServer.__init__ in rpcserver.py for detail on arguments.
    """
    if _server_stub_base_class is object:
      raise NotImplementedError('Add //net/rpc/python:rpcserver as a '
                                'dependency for Stubby server support.')
    _server_stub_base_class.__init__(self, 'apphosting.RemoteSocketService', *args, **kwargs)

  @staticmethod
  def NewStub(rpc_stub_parameters, service_name=None):
    """Creates a new RemoteSocketService Stubby client stub.

    Args:
      rpc_stub_parameters: an RPC_StubParameter instance.
      service_name: the service name used by the Stubby server.
    """

    if _client_stub_base_class is object:
      raise RuntimeError('Add //net/rpc/python as a dependency to use Stubby')
    return _RemoteSocketService_ClientStub(rpc_stub_parameters, service_name)

  @staticmethod
  def NewRPC2Stub(server=None, channel=None, service_name=None):
    """Creates a new RemoteSocketService Stubby2 client stub.

    Args:
      server: host:port or bns address.
      channel: directly use a channel to create a stub. Will ignore server
          argument if this is specified.
      service_name: the service name used by the Stubby server.
    """

    if _client_stub_base_class is object:
      raise RuntimeError('Add //net/rpc/python as a dependency to use Stubby')
    return _RemoteSocketService_RPC2ClientStub(server, channel, service_name)

  def CreateSocket(self, rpc, request, response):
    """Handles a CreateSocket RPC call. You should override this.

    Args:
      rpc: a Stubby RPC object
      request: a CreateSocketRequest that contains the client request
      response: a CreateSocketReply that should be modified to send the response
    """
    raise NotImplementedError


  def Bind(self, rpc, request, response):
    """Handles a Bind RPC call. You should override this.

    Args:
      rpc: a Stubby RPC object
      request: a BindRequest that contains the client request
      response: a BindReply that should be modified to send the response
    """
    raise NotImplementedError


  def GetSocketName(self, rpc, request, response):
    """Handles a GetSocketName RPC call. You should override this.

    Args:
      rpc: a Stubby RPC object
      request: a GetSocketNameRequest that contains the client request
      response: a GetSocketNameReply that should be modified to send the response
    """
    raise NotImplementedError


  def GetPeerName(self, rpc, request, response):
    """Handles a GetPeerName RPC call. You should override this.

    Args:
      rpc: a Stubby RPC object
      request: a GetPeerNameRequest that contains the client request
      response: a GetPeerNameReply that should be modified to send the response
    """
    raise NotImplementedError


  def SetSocketOptions(self, rpc, request, response):
    """Handles a SetSocketOptions RPC call. You should override this.

    Args:
      rpc: a Stubby RPC object
      request: a SetSocketOptionsRequest that contains the client request
      response: a SetSocketOptionsReply that should be modified to send the response
    """
    raise NotImplementedError


  def GetSocketOptions(self, rpc, request, response):
    """Handles a GetSocketOptions RPC call. You should override this.

    Args:
      rpc: a Stubby RPC object
      request: a GetSocketOptionsRequest that contains the client request
      response: a GetSocketOptionsReply that should be modified to send the response
    """
    raise NotImplementedError


  def Connect(self, rpc, request, response):
    """Handles a Connect RPC call. You should override this.

    Args:
      rpc: a Stubby RPC object
      request: a ConnectRequest that contains the client request
      response: a ConnectReply that should be modified to send the response
    """
    raise NotImplementedError


  def Listen(self, rpc, request, response):
    """Handles a Listen RPC call. You should override this.

    Args:
      rpc: a Stubby RPC object
      request: a ListenRequest that contains the client request
      response: a ListenReply that should be modified to send the response
    """
    raise NotImplementedError


  def Accept(self, rpc, request, response):
    """Handles a Accept RPC call. You should override this.

    Args:
      rpc: a Stubby RPC object
      request: a AcceptRequest that contains the client request
      response: a AcceptReply that should be modified to send the response
    """
    raise NotImplementedError


  def ShutDown(self, rpc, request, response):
    """Handles a ShutDown RPC call. You should override this.

    Args:
      rpc: a Stubby RPC object
      request: a ShutDownRequest that contains the client request
      response: a ShutDownReply that should be modified to send the response
    """
    raise NotImplementedError


  def Close(self, rpc, request, response):
    """Handles a Close RPC call. You should override this.

    Args:
      rpc: a Stubby RPC object
      request: a CloseRequest that contains the client request
      response: a CloseReply that should be modified to send the response
    """
    raise NotImplementedError


  def Send(self, rpc, request, response):
    """Handles a Send RPC call. You should override this.

    Args:
      rpc: a Stubby RPC object
      request: a SendRequest that contains the client request
      response: a SendReply that should be modified to send the response
    """
    raise NotImplementedError


  def Receive(self, rpc, request, response):
    """Handles a Receive RPC call. You should override this.

    Args:
      rpc: a Stubby RPC object
      request: a ReceiveRequest that contains the client request
      response: a ReceiveReply that should be modified to send the response
    """
    raise NotImplementedError


  def Poll(self, rpc, request, response):
    """Handles a Poll RPC call. You should override this.

    Args:
      rpc: a Stubby RPC object
      request: a PollRequest that contains the client request
      response: a PollReply that should be modified to send the response
    """
    raise NotImplementedError


  def UpdateSession(self, rpc, request, response):
    """Handles a UpdateSession RPC call. You should override this.

    Args:
      rpc: a Stubby RPC object
      request: a UpdateSessionRequest that contains the client request
      response: a UpdateSessionReply that should be modified to send the response
    """
    raise NotImplementedError


  def Resolve(self, rpc, request, response):
    """Handles a Resolve RPC call. You should override this.

    Args:
      rpc: a Stubby RPC object
      request: a ResolveRequest that contains the client request
      response: a ResolveReply that should be modified to send the response
    """
    raise NotImplementedError

  def _AddMethodAttributes(self):
    """Sets attributes on Python RPC handlers.

    See BaseRpcServer in rpcserver.py for details.
    """
    rpcserver._GetHandlerDecorator(
        self.CreateSocket.im_func,
        CreateSocketRequest,
        CreateSocketReply,
        None,
        'none')
    rpcserver._GetHandlerDecorator(
        self.Bind.im_func,
        BindRequest,
        BindReply,
        None,
        'none')
    rpcserver._GetHandlerDecorator(
        self.GetSocketName.im_func,
        GetSocketNameRequest,
        GetSocketNameReply,
        None,
        'none')
    rpcserver._GetHandlerDecorator(
        self.GetPeerName.im_func,
        GetPeerNameRequest,
        GetPeerNameReply,
        None,
        'none')
    rpcserver._GetHandlerDecorator(
        self.SetSocketOptions.im_func,
        SetSocketOptionsRequest,
        SetSocketOptionsReply,
        None,
        'none')
    rpcserver._GetHandlerDecorator(
        self.GetSocketOptions.im_func,
        GetSocketOptionsRequest,
        GetSocketOptionsReply,
        None,
        'none')
    rpcserver._GetHandlerDecorator(
        self.Connect.im_func,
        ConnectRequest,
        ConnectReply,
        None,
        'none')
    rpcserver._GetHandlerDecorator(
        self.Listen.im_func,
        ListenRequest,
        ListenReply,
        None,
        'none')
    rpcserver._GetHandlerDecorator(
        self.Accept.im_func,
        AcceptRequest,
        AcceptReply,
        None,
        'none')
    rpcserver._GetHandlerDecorator(
        self.ShutDown.im_func,
        ShutDownRequest,
        ShutDownReply,
        None,
        'none')
    rpcserver._GetHandlerDecorator(
        self.Close.im_func,
        CloseRequest,
        CloseReply,
        None,
        'none')
    rpcserver._GetHandlerDecorator(
        self.Send.im_func,
        SendRequest,
        SendReply,
        None,
        'none')
    rpcserver._GetHandlerDecorator(
        self.Receive.im_func,
        ReceiveRequest,
        ReceiveReply,
        None,
        'none')
    rpcserver._GetHandlerDecorator(
        self.Poll.im_func,
        PollRequest,
        PollReply,
        None,
        'none')
    rpcserver._GetHandlerDecorator(
        self.UpdateSession.im_func,
        UpdateSessionRequest,
        UpdateSessionReply,
        None,
        'none')
    rpcserver._GetHandlerDecorator(
        self.Resolve.im_func,
        ResolveRequest,
        ResolveReply,
        None,
        'none')


__all__ = ['RemoteSocketServiceError','AddressPort','SSLContext','SSLSession','CreateSocketRequest','CreateSocketReply','BindRequest','BindReply','GetSocketNameRequest','GetSocketNameReply','GetPeerNameRequest','GetPeerNameReply','SocketOption','SetSocketOptionsRequest','SetSocketOptionsReply','GetSocketOptionsRequest','GetSocketOptionsReply','ConnectRequest','ConnectReply','ListenRequest','ListenReply','AcceptRequest','AcceptReply','ShutDownRequest','ShutDownReply','CloseRequest','CloseReply','SendRequest','SendReply','ReceiveRequest','ReceiveReply','PollEvent','PollRequest','PollReply','UpdateSessionRequest','UpdateSessionReply','ResolveRequest','ResolveReply','RemoteSocketService']
